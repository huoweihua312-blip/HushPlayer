﻿import os
import hashlib
import json
import random
import re
import shutil
import time
from pathlib import Path

import requests
from mutagen import File as MutagenFile
from PySide6.QtCore import QEasingCurve, QEvent, QObject, QPointF, QPropertyAnimation, Qt, QThread, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QKeySequence, QPainter, QPainterPath, QPen, QPixmap, QShortcut, QTextLayout, QTextOption
from PySide6.QtMultimedia import QAudioOutput, QMediaDevices, QMediaPlayer
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QFileDialog,
    QFrame,
    QGraphicsBlurEffect,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QProgressDialog,
    QScrollArea,
    QSizePolicy,
    QSlider,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)


AUDIO_EXTENSIONS = {
    ".mp3",
    ".flac",
    ".wav",
    ".m4a",
    ".aac",
    ".ogg",
}


class NavButton(QPushButton):
    def __init__(self, text: str, active: bool = False) -> None:
        super().__init__(text)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setProperty("active", active)


class ElidedLabel(QLabel):
    def __init__(self, text: str = "") -> None:
        super().__init__()
        self.full_text = ""
        self.setMinimumWidth(0)
        self.setText(text)

    def setText(self, text: str) -> None:
        self.full_text = text or ""
        self.setToolTip(self.full_text)
        self.update_elided_text()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self.update_elided_text()

    def update_elided_text(self) -> None:
        if not self.full_text:
            QLabel.setText(self, "")
            return

        available_width = max(20, self.width() - 4)
        metrics = QFontMetrics(self.font())
        elided_text = metrics.elidedText(
            self.full_text,
            Qt.TextElideMode.ElideRight,
            available_width,
        )
        QLabel.setText(self, elided_text)


class LyricsView(QScrollArea):
    def __init__(self) -> None:
        super().__init__()

        self.setObjectName("lyricsView")
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.content = QWidget()
        self.content.setObjectName("lyricsContent")

        self.lyrics_layout = QVBoxLayout(self.content)
        self.lyrics_layout.setContentsMargins(0, 120, 0, 120)
        self.lyrics_layout.setSpacing(14)

        self.setWidget(self.content)

        self.labels: list[QLabel] = []
        self.current_index = -1

        self.scroll_animation = QPropertyAnimation(self.verticalScrollBar(), b"value", self)
        self.scroll_animation.setDuration(520)
        self.scroll_animation.setEasingCurve(QEasingCurve.Type.OutCubic)

        self.set_placeholder("这里会显示歌词", "支持本地 .lrc 歌词滚动")

    def clear_content(self) -> None:
        while self.lyrics_layout.count():
            item = self.lyrics_layout.takeAt(0)
            widget = item.widget()

            if widget:
                widget.deleteLater()

        self.labels = []
        self.current_index = -1

    def set_placeholder(self, title: str, subtitle: str = "") -> None:
        self.clear_content()

        self.lyrics_layout.setContentsMargins(0, 80, 0, 80)
        self.lyrics_layout.addStretch()

        title_label = QLabel(title)
        title_label.setObjectName("lyricPlaceholderTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setWordWrap(True)

        self.lyrics_layout.addWidget(title_label)

        if subtitle:
            subtitle_label = QLabel(subtitle)
            subtitle_label.setObjectName("lyricPlaceholderSubtitle")
            subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            subtitle_label.setWordWrap(True)

            self.lyrics_layout.addWidget(subtitle_label)

        self.lyrics_layout.addStretch()
        self.verticalScrollBar().setValue(0)

    def set_lyrics(self, lyrics: list[tuple[int, str]]) -> None:
        self.clear_content()

        if not lyrics:
            self.set_placeholder("鏈壘鍒版瓕璇?, "鎶婂悓鍚?.lrc 鏂囦欢鏀惧湪姝屾洸鏃佽竟鍗冲彲鏄剧ず")
            return

        self.lyrics_layout.setContentsMargins(0, 135, 0, 135)
        self.lyrics_layout.setSpacing(12)

        for _, text in lyrics:
            label = QLabel(text)
            label.setObjectName("lyricLine")
            label.setProperty("lyricState", "normal")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setWordWrap(True)
            label.setSizePolicy(
                QSizePolicy.Policy.Expanding,
                QSizePolicy.Policy.Minimum,
            )

            self.lyrics_layout.addWidget(label)
            self.labels.append(label)

        self.current_index = -1
        self.verticalScrollBar().setValue(0)

    def update_by_position(self, position: int, lyrics: list[tuple[int, str]]) -> None:
        if not lyrics or not self.labels:
            return

        new_index = -1

        for index, (timestamp, _) in enumerate(lyrics):
            if position >= timestamp:
                new_index = index
            else:
                break

        if new_index == self.current_index:
            return

        self.set_current_index(new_index)

    def set_current_index(self, index: int) -> None:
        self.current_index = index

        for label_index, label in enumerate(self.labels):
            if label_index == index:
                state = "current"
            elif abs(label_index - index) == 1:
                state = "near"
            else:
                state = "normal"

            label.setProperty("lyricState", state)
            label.style().unpolish(label)
            label.style().polish(label)
            label.update()

        if index < 0 or index >= len(self.labels):
            return

        self.content.layout().activate()

        current_label = self.labels[index]
        label_center_y = current_label.y() + current_label.height() // 2
        target_value = label_center_y - self.viewport().height() // 2

        target_value = max(0, min(target_value, self.verticalScrollBar().maximum()))

        self.scroll_animation.stop()
        self.scroll_animation.setStartValue(self.verticalScrollBar().value())
        self.scroll_animation.setEndValue(target_value)
        self.scroll_animation.start()


class CoverSearchWorker(QObject):
    status_changed = Signal(str, str)
    finished = Signal(str, object)

    MISSING_CACHE_SECONDS = 7 * 24 * 60 * 60

    def __init__(
        self,
        request_id: str,
        file_path: str,
        title: str,
        artist: str,
        album: str,
        cover_cache_dir: str,
        http_headers: dict,
    ) -> None:
        super().__init__()

        self.request_id = request_id
        self.file_path = file_path
        self.title = title
        self.artist = artist
        self.album = album
        self.cover_cache_dir = Path(cover_cache_dir)
        self.http_headers = dict(http_headers)
        self.last_musicbrainz_request_time = 0.0

    def emit_status(self, message: str) -> None:
        self.status_changed.emit(self.request_id, message)

    def run(self) -> None:
        try:
            result = self.search_cover()
            self.finished.emit(self.request_id, result)
        except Exception as error:
            self.finished.emit(
                self.request_id,
                {
                    "ok": False,
                    "source": "error",
                    "message": str(error),
                    "song_path": self.file_path,
                },
            )

    def search_cover(self) -> dict:
        if not self.file_path:
            return {
                "ok": False,
                "source": "empty",
                "message": "娌℃湁姝屾洸璺緞",
                "song_path": self.file_path,
            }

        music_path = Path(self.file_path)
        cache_path = self.get_cover_cache_path(music_path)
        missing_path = cache_path.with_suffix(".missing")

        if cache_path.exists():
            self.emit_status("宸插姞杞界紦瀛樺皝闈?)
            return {
                "ok": True,
                "source": "cache",
                "cover_path": str(cache_path),
                "song_path": self.file_path,
            }

        if self.is_missing_cache_valid(missing_path):
            self.emit_status("灏侀潰缂撳瓨璁板綍锛氫笂娆℃湭鎵惧埌")
            return {
                "ok": False,
                "source": "missing_cache",
                "message": "杩戞湡宸茬粡鎼滅储杩囷紝鏈壘鍒板皝闈?,
                "song_path": self.file_path,
            }

        self.emit_status("姝ｅ湪璇诲彇鍐呭祵灏侀潰")
        cover_data = self.extract_album_cover(music_path)

        if cover_data:
            self.cover_cache_dir.mkdir(parents=True, exist_ok=True)
            cache_path.write_bytes(cover_data)
            self.remove_missing_cache(missing_path)

            return {
                "ok": True,
                "source": "embedded",
                "cover_path": str(cache_path),
                "song_path": self.file_path,
            }

        self.emit_status("姝ｅ湪鏌ユ壘鏂囦欢澶瑰皝闈?)
        folder_cover = self.find_folder_cover(music_path)

        if folder_cover:
            self.cover_cache_dir.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(folder_cover, cache_path)
            self.remove_missing_cache(missing_path)

            return {
                "ok": True,
                "source": "folder",
                "cover_path": str(cache_path),
                "song_path": self.file_path,
            }

        self.emit_status("姝ｅ湪鑱旂綉鎼滅储灏侀潰")
        online_cover = self.fetch_online_cover(self.title, self.artist, self.album)

        if online_cover:
            self.cover_cache_dir.mkdir(parents=True, exist_ok=True)
            cache_path.write_bytes(online_cover)
            self.remove_missing_cache(missing_path)

            return {
                "ok": True,
                "source": "online",
                "cover_path": str(cache_path),
                "song_path": self.file_path,
            }

        self.write_missing_cache(missing_path, "cover not found")
        self.emit_status("鏈壘鍒板皝闈紝宸茶褰曠紦瀛?)
        return {
            "ok": False,
            "source": "not_found",
            "message": "鏈壘鍒板皝闈?,
            "song_path": self.file_path,
        }

    def get_cover_cache_path(self, path: Path) -> Path:
        normalized_path = str(path.resolve()).lower()
        digest = hashlib.sha1(normalized_path.encode("utf-8")).hexdigest()
        return self.cover_cache_dir / f"{digest}.jpg"

    def is_missing_cache_valid(self, missing_path: Path) -> bool:
        if not missing_path.exists():
            return False

        try:
            age = time.time() - missing_path.stat().st_mtime
            return age < self.MISSING_CACHE_SECONDS
        except Exception:
            return False

    def write_missing_cache(self, missing_path: Path, message: str) -> None:
        try:
            missing_path.parent.mkdir(parents=True, exist_ok=True)
            missing_path.write_text(message, encoding="utf-8")
        except Exception:
            pass

    def remove_missing_cache(self, missing_path: Path) -> None:
        try:
            if missing_path.exists():
                missing_path.unlink()
        except Exception:
            pass

    def extract_album_cover(self, path: Path) -> bytes | None:
        try:
            audio = MutagenFile(path)

            if audio is None:
                return None

            if hasattr(audio, "pictures") and audio.pictures:
                return audio.pictures[0].data

            if audio.tags is None:
                return None

            for key in audio.tags.keys():
                if str(key).startswith("APIC"):
                    tag = audio.tags[key]

                    if hasattr(tag, "data"):
                        return tag.data

            mp4_cover = audio.tags.get("covr")

            if mp4_cover:
                return bytes(mp4_cover[0])

        except Exception as error:
            print("鍚庡彴璇诲彇鍐呭祵灏侀潰澶辫触锛?, path)
            print(error)

        return None

    def find_folder_cover(self, music_path: Path) -> Path | None:
        folder = music_path.parent

        possible_names = [
            "cover.jpg",
            "cover.jpeg",
            "cover.png",
            "folder.jpg",
            "folder.jpeg",
            "folder.png",
            "front.jpg",
            "front.jpeg",
            "front.png",
            "album.jpg",
            "album.jpeg",
            "album.png",
        ]

        for name in possible_names:
            candidate = folder / name

            if candidate.exists():
                return candidate

        return None

    def clean_search_text(self, text: str) -> str:
        text = str(text).strip()

        if text in {"鏈煡姝屾洸", "鏈煡鑹烘湳瀹?, "鏈煡涓撹緫"}:
            return ""

        return text

    def wait_for_musicbrainz_rate_limit(self) -> None:
        now = time.time()
        elapsed = now - self.last_musicbrainz_request_time

        if elapsed < 1.1:
            time.sleep(1.1 - elapsed)

        self.last_musicbrainz_request_time = time.time()

    def fetch_online_cover(self, title: str, artist: str, album: str) -> bytes | None:
        cleaned_title = self.clean_search_text(title)
        cleaned_artist = self.clean_search_text(artist)
        cleaned_album = self.clean_search_text(album)

        if not cleaned_artist:
            return None

        if cleaned_album and cleaned_album not in {"鏈煡涓撹緫", "unknown album"}:
            queries = [
                f'release:"{cleaned_album}" AND artist:"{cleaned_artist}"',
                f'{cleaned_album} {cleaned_artist}',
            ]
        else:
            queries = [
                f'recording:"{cleaned_title}" AND artist:"{cleaned_artist}"',
                f'{cleaned_title} {cleaned_artist}',
            ]

        for query in queries:
            release_ids = self.search_musicbrainz_release_ids(query)

            for release_id in release_ids:
                cover_data = self.fetch_cover_art_archive(release_id)

                if cover_data:
                    return cover_data

        return None

    def search_musicbrainz_release_ids(self, query: str) -> list[str]:
        try:
            self.wait_for_musicbrainz_rate_limit()

            response = requests.get(
                "https://musicbrainz.org/ws/2/release/",
                params={
                    "query": query,
                    "fmt": "json",
                    "limit": 5,
                },
                headers=self.http_headers,
                timeout=10,
            )

            response.raise_for_status()
            data = response.json()

        except Exception as error:
            print("鍚庡彴 MusicBrainz 鎼滅储澶辫触锛?, error)
            return []

        releases = data.get("releases", [])
        release_ids = []

        for release in releases:
            release_id = release.get("id")

            if release_id:
                release_ids.append(release_id)

        return release_ids

    def fetch_cover_art_archive(self, release_id: str) -> bytes | None:
        url = f"https://coverartarchive.org/release/{release_id}/front-500"

        try:
            response = requests.get(
                url,
                headers={
                    "User-Agent": self.http_headers.get("User-Agent", "HushPlayer"),
                    "Accept": "image/*",
                },
                timeout=15,
                allow_redirects=True,
            )

            if response.status_code != 200:
                return None

            content_type = response.headers.get("Content-Type", "")

            if "image" not in content_type.lower():
                return None

            return response.content

        except Exception as error:
            print("鍚庡彴 Cover Art Archive 鑾峰彇澶辫触锛?, error)
            return None


class LyricsSearchWorker(QObject):
    status_changed = Signal(str, str)
    finished = Signal(str, object)

    MISSING_CACHE_SECONDS = 7 * 24 * 60 * 60

    def __init__(
        self,
        request_id: str,
        file_path: str,
        title: str,
        artist: str,
        album: str,
        lyrics_cache_dir: str,
        http_headers: dict,
    ) -> None:
        super().__init__()

        self.request_id = request_id
        self.file_path = file_path
        self.title = title
        self.artist = artist
        self.album = album
        self.lyrics_cache_dir = Path(lyrics_cache_dir)
        self.http_headers = dict(http_headers)

    def emit_status(self, message: str) -> None:
        self.status_changed.emit(self.request_id, message)

    def run(self) -> None:
        try:
            result = self.search_lyrics()
            self.finished.emit(self.request_id, result)
        except Exception as error:
            self.finished.emit(
                self.request_id,
                {
                    "ok": False,
                    "source": "error",
                    "message": str(error),
                    "song_path": self.file_path,
                },
            )

    def search_lyrics(self) -> dict:
        if not self.file_path:
            return {
                "ok": False,
                "source": "empty",
                "message": "娌℃湁姝屾洸璺緞",
                "song_path": self.file_path,
            }

        music_path = Path(self.file_path)
        cache_path = self.get_lyrics_cache_path(music_path)
        missing_path = cache_path.with_suffix(".missing")

        self.emit_status("姝ｅ湪鏌ユ壘鏈湴姝岃瘝")
        local_lrc = self.find_lrc_file(music_path, self.title, self.artist)

        if local_lrc:
            self.remove_missing_cache(missing_path)
            return {
                "ok": True,
                "source": "local",
                "lyrics_path": str(local_lrc),
                "song_path": self.file_path,
            }

        self.emit_status("姝ｅ湪鏌ユ壘缂撳瓨姝岃瘝")

        if cache_path.exists():
            return {
                "ok": True,
                "source": "cache",
                "lyrics_path": str(cache_path),
                "song_path": self.file_path,
            }

        if self.is_missing_cache_valid(missing_path):
            self.emit_status("姝岃瘝缂撳瓨璁板綍锛氫笂娆℃湭鎵惧埌")
            return {
                "ok": False,
                "source": "missing_cache",
                "message": "杩戞湡宸茬粡鎼滅储杩囷紝鏈壘鍒板悓姝ユ瓕璇?,
                "song_path": self.file_path,
            }

        self.emit_status("姝ｅ湪鑱旂綉鎼滅储 LRCLIB")
        duration_seconds = self.get_audio_duration_seconds(music_path)

        synced_lyrics = self.search_lrclib_synced_lyrics(
            title=self.title,
            artist=self.artist,
            album=self.album,
            duration_seconds=duration_seconds,
        )

        if not synced_lyrics:
            self.write_missing_cache(missing_path, "lyrics not found")
            self.emit_status("鏈壘鍒版瓕璇嶏紝宸茶褰曠紦瀛?)
            return {
                "ok": False,
                "source": "not_found",
                "message": "鏈壘鍒板悓姝ユ瓕璇?,
                "song_path": self.file_path,
            }

        self.lyrics_cache_dir.mkdir(parents=True, exist_ok=True)
        cache_path.write_text(synced_lyrics, encoding="utf-8")
        self.remove_missing_cache(missing_path)

        return {
            "ok": True,
            "source": "online",
            "lyrics_path": str(cache_path),
            "song_path": self.file_path,
        }

    def get_lyrics_cache_path(self, path: Path) -> Path:
        normalized_path = str(path.resolve()).lower()
        digest = hashlib.sha1(normalized_path.encode("utf-8")).hexdigest()
        return self.lyrics_cache_dir / f"{digest}.lrc"

    def is_missing_cache_valid(self, missing_path: Path) -> bool:
        if not missing_path.exists():
            return False

        try:
            age = time.time() - missing_path.stat().st_mtime
            return age < self.MISSING_CACHE_SECONDS
        except Exception:
            return False

    def write_missing_cache(self, missing_path: Path, message: str) -> None:
        try:
            missing_path.parent.mkdir(parents=True, exist_ok=True)
            missing_path.write_text(message, encoding="utf-8")
        except Exception:
            pass

    def remove_missing_cache(self, missing_path: Path) -> None:
        try:
            if missing_path.exists():
                missing_path.unlink()
        except Exception:
            pass

    def find_lrc_file(self, music_path: Path, title: str, artist: str) -> Path | None:
        folder = music_path.parent

        candidates = [
            music_path.with_suffix(".lrc"),
            folder / f"{music_path.stem}.lrc",
            folder / f"{title}.lrc",
            folder / f"{artist} - {title}.lrc",
            folder / f"{title} - {artist}.lrc",
        ]

        seen = set()

        for candidate in candidates:
            normalized = str(candidate).lower()

            if normalized in seen:
                continue

            seen.add(normalized)

            if candidate.exists():
                return candidate

        for candidate in folder.glob("*.lrc"):
            if candidate.stem.lower() == music_path.stem.lower():
                return candidate

        return None

    def get_audio_duration_seconds(self, path: Path) -> int:
        try:
            audio = MutagenFile(path)

            if audio is None:
                return 0

            info = getattr(audio, "info", None)

            if info is None:
                return 0

            length = getattr(info, "length", 0)

            if not length:
                return 0

            return int(round(float(length)))

        except Exception as error:
            print("鍚庡彴璇诲彇姝屾洸鏃堕暱澶辫触锛?, path)
            print(error)
            return 0

    def clean_search_text(self, text: str) -> str:
        text = str(text).strip()

        if text in {"鏈煡姝屾洸", "鏈煡鑹烘湳瀹?, "鏈煡涓撹緫"}:
            return ""

        return text

    def normalize_match_text(self, text: str) -> str:
        text = self.clean_search_text(text).lower()
        text = re.sub(r"[\s\-_.,锛屻€?锛?锛?锛?锛?\"鈥溾€濃€樷€?)\[\]{}銆愩€?>銆娿€?\\\\]+", "", text)
        return text

    def calculate_lyrics_result_score(
        self,
        result: dict,
        title: str,
        artist: str,
        album: str,
        duration_seconds: int,
    ) -> int:
        score = 0

        synced_lyrics = result.get("syncedLyrics")

        if not synced_lyrics:
            return -9999

        result_title = str(result.get("trackName", ""))
        result_artist = str(result.get("artistName", ""))
        result_album = str(result.get("albumName", ""))

        target_title = self.normalize_match_text(title)
        target_artist = self.normalize_match_text(artist)
        target_album = self.normalize_match_text(album)

        matched_title = self.normalize_match_text(result_title)
        matched_artist = self.normalize_match_text(result_artist)
        matched_album = self.normalize_match_text(result_album)

        if target_title and matched_title:
            if target_title == matched_title:
                score += 80
            elif target_title in matched_title or matched_title in target_title:
                score += 45

        if target_artist and matched_artist:
            if target_artist == matched_artist:
                score += 60
            elif target_artist in matched_artist or matched_artist in target_artist:
                score += 30

        if target_album and matched_album:
            if target_album == matched_album:
                score += 20
            elif target_album in matched_album or matched_album in target_album:
                score += 8

        result_duration = int(result.get("duration", 0) or 0)

        if duration_seconds > 0 and result_duration > 0:
            diff = abs(duration_seconds - result_duration)

            if diff <= 2:
                score += 30
            elif diff <= 5:
                score += 18
            elif diff <= 10:
                score += 8

        score += 40
        return score

    def search_lrclib_synced_lyrics(
        self,
        title: str,
        artist: str,
        album: str,
        duration_seconds: int,
    ) -> str | None:
        cleaned_title = self.clean_search_text(title)
        cleaned_artist = self.clean_search_text(artist)
        cleaned_album = self.clean_search_text(album)

        if not cleaned_title:
            return None

        search_requests = []

        first_params = {
            "track_name": cleaned_title,
        }

        if cleaned_artist:
            first_params["artist_name"] = cleaned_artist

        if cleaned_album:
            first_params["album_name"] = cleaned_album

        search_requests.append(first_params)

        if cleaned_artist:
            search_requests.append(
                {
                    "q": f"{cleaned_title} {cleaned_artist}",
                }
            )

        search_requests.append(
            {
                "q": cleaned_title,
            }
        )

        best_result = None
        best_score = -9999

        for params in search_requests:
            try:
                response = requests.get(
                    "https://lrclib.net/api/search",
                    params=params,
                    headers=self.http_headers,
                    timeout=12,
                )

                response.raise_for_status()
                results = response.json()

                if not isinstance(results, list):
                    continue

            except Exception as error:
                print("鍚庡彴 LRCLIB 鎼滅储澶辫触锛?, error)
                continue

            for result in results:
                if not isinstance(result, dict):
                    continue

                score = self.calculate_lyrics_result_score(
                    result=result,
                    title=title,
                    artist=artist,
                    album=album,
                    duration_seconds=duration_seconds,
                )

                if score > best_score:
                    best_score = score
                    best_result = result

            if best_result and best_score >= 110:
                break

        if not best_result:
            return None

        synced_lyrics = best_result.get("syncedLyrics")

        if not synced_lyrics:
            return None

        if best_score < 80:
            return None

        return str(synced_lyrics).strip()

class FloatingLyricsLabel(QLabel):
    def __init__(self, text: str = "") -> None:
        super().__init__(text)
        self.text_color = QColor(255, 255, 255, 255)
        self.outline_enabled = True
        self.outline_color = QColor(0, 0, 0, 230)
        self.outline_width = 4
        self.shadow_enabled = True
        self.font_size = 42
        self.setWordWrap(True)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

    def set_visual_options(
        self,
        text_color: QColor,
        font_size: int,
        outline_enabled: bool,
        outline_color: QColor,
        outline_width: int,
        shadow_enabled: bool,
    ) -> None:
        self.text_color = QColor(text_color)
        self.font_size = int(font_size)
        self.outline_enabled = bool(outline_enabled)
        self.outline_color = QColor(outline_color)
        self.outline_width = int(outline_width)
        self.shadow_enabled = bool(shadow_enabled)
        self.update()

    def paintEvent(self, event) -> None:
        text = self.text() or ""

        if not text:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

        rect = self.contentsRect()
        font = QFont(self.font())
        font.setPixelSize(self.font_size)
        font.setWeight(QFont.Weight.Black)

        text_option = QTextOption()
        text_option.setAlignment(Qt.AlignmentFlag.AlignCenter)
        text_option.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)

        layout = QTextLayout(text, font)
        layout.setTextOption(text_option)
        layout.beginLayout()

        lines = []
        total_height = 0.0
        line_width = max(1, rect.width())

        while True:
            line = layout.createLine()

            if not line.isValid():
                break

            line.setLineWidth(line_width)
            line.setPosition(QPointF(0, total_height))
            lines.append(line)
            total_height += line.height()

        layout.endLayout()

        start_y = rect.y() + max(0.0, (rect.height() - total_height) / 2)

        for line in lines:
            start = line.textStart()
            length = line.textLength()
            line_text = text[start : start + length].strip()

            if not line_text:
                continue

            x = rect.x() + max(0.0, (rect.width() - line.naturalTextWidth()) / 2)
            baseline = start_y + line.y() + line.ascent()
            path = QPainterPath()
            path.addText(QPointF(x, baseline), font, line_text)

            if self.shadow_enabled:
                shadow_color = QColor(0, 0, 0, 150)
                shadow_path = QPainterPath()
                shadow_path.addText(QPointF(x + 3, baseline + 3), font, line_text)
                painter.fillPath(shadow_path, shadow_color)

            if self.outline_enabled and self.outline_width > 0:
                pen = QPen(self.outline_color)
                pen.setWidth(self.outline_width)
                pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
                painter.strokePath(path, pen)

            painter.fillPath(path, self.text_color)


class FloatingLyricsWindow(QWidget):
    def __init__(self, main_window) -> None:
        super().__init__()

        self.main_window = main_window
        self.locked = False
        self.drag_offset = None

        self.font_size = int(main_window.get_user_setting("floating_lyrics_font_size", 42))
        self.text_alpha = int(main_window.get_user_setting("floating_lyrics_opacity", 100))
        self.text_color_name = str(main_window.get_user_setting("floating_lyrics_color", "white"))
        self.window_width = int(main_window.get_user_setting("floating_lyrics_width", 980))
        self.outline_enabled = bool(main_window.get_user_setting("floating_lyrics_outline_enabled", True))
        self.outline_color_name = str(main_window.get_user_setting("floating_lyrics_outline_color", "black"))
        self.outline_strength = str(main_window.get_user_setting("floating_lyrics_outline_strength", "medium"))
        self.shadow_enabled = bool(main_window.get_user_setting("floating_lyrics_shadow_enabled", True))

        self.color_map = {
            "white": ("鐧借壊", 255, 255, 255),
            "black": ("榛戣壊", 0, 0, 0),
            "yellow": ("榛勮壊", 255, 226, 96),
            "blue": ("钃濊壊", 105, 173, 255),
            "green": ("缁胯壊", 120, 235, 166),
            "pink": ("绮夎壊", 255, 130, 190),
            "purple": ("绱壊", 190, 145, 255),
        }

        self.setWindowTitle("HushPlayer 妗岄潰姝岃瘝")
        self.outline_color_map = {
            "black": ("榛戣壊", 0, 0, 0),
            "white": ("鐧借壊", 255, 255, 255),
        }
        self.outline_strength_map = {
            "weak": ("寮?, 2),
            "medium": ("涓?, 4),
            "strong": ("寮?, 7),
        }

        self.setObjectName("floatingLyricsWindow")
        self.setMinimumSize(420, 80)
        self.resize(self.window_width, 135)

        self.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
        self.setWindowFlag(Qt.WindowType.Tool, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 10, 16, 10)
        layout.setSpacing(0)

        self.current_label = QLabel("妗岄潰姝岃瘝宸插紑鍚?)
        self.current_label.setObjectName("floatingLyricCurrent")
        self.current_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.current_label.setWordWrap(True)
        self.current_label.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        self.current_label = FloatingLyricsLabel(self.current_label.text())
        self.current_label.setObjectName("floatingLyricCurrent")
        self.current_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.current_label.setWordWrap(True)
        self.current_label.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        layout.addWidget(self.current_label, 1)

        self.apply_style()

    def get_rgba_color(self) -> str:
        color_key = self.text_color_name

        if color_key not in self.color_map:
            color_key = "white"

        _, red, green, blue = self.color_map[color_key]
        alpha = max(25, min(255, int(self.text_alpha / 100 * 255)))

        return f"rgba({red}, {green}, {blue}, {alpha})"

    def get_text_color(self) -> QColor:
        color_key = self.text_color_name

        if color_key not in self.color_map:
            color_key = "white"

        _, red, green, blue = self.color_map[color_key]
        alpha = max(25, min(255, int(self.text_alpha / 100 * 255)))
        return QColor(red, green, blue, alpha)

    def get_outline_color(self) -> QColor:
        color_key = self.outline_color_name

        if color_key not in self.outline_color_map:
            color_key = "black"

        _, red, green, blue = self.outline_color_map[color_key]
        return QColor(red, green, blue, 235)

    def get_outline_width(self) -> int:
        if self.outline_strength not in self.outline_strength_map:
            self.outline_strength = "medium"

        return self.outline_strength_map[self.outline_strength][1]

    def apply_style(self) -> None:
        self.setStyleSheet(
            "QWidget#floatingLyricsWindow { background: transparent; font-family: 'Microsoft YaHei UI'; }"
            f"QLabel#floatingLyricCurrent {{ color: {self.get_rgba_color()}; background: transparent; font-size: {self.font_size}px; font-weight: 950; padding: 0px; }}"
        )
        self.current_label.set_visual_options(
            text_color=self.get_text_color(),
            font_size=self.font_size,
            outline_enabled=self.outline_enabled,
            outline_color=self.get_outline_color(),
            outline_width=self.get_outline_width(),
            shadow_enabled=self.shadow_enabled,
        )

    def save_preferences(self) -> None:
        self.main_window.save_hush_settings(
            {
                "floating_lyrics_font_size": int(self.font_size),
                "floating_lyrics_opacity": int(self.text_alpha),
                "floating_lyrics_color": self.text_color_name,
                "floating_lyrics_width": int(self.width()),
                "floating_lyrics_outline_enabled": bool(self.outline_enabled),
                "floating_lyrics_outline_color": self.outline_color_name,
                "floating_lyrics_outline_strength": self.outline_strength,
                "floating_lyrics_shadow_enabled": bool(self.shadow_enabled),
            }
        )

    def set_lines(self, previous_line: str, current_line: str, next_line: str) -> None:
        self.current_label.setText(current_line or "鏆傛棤姝岃瘝")

    def adjust_font_size(self, step: int) -> None:
        self.font_size = max(22, min(84, self.font_size + step))
        self.apply_style()
        self.save_preferences()

    def adjust_window_width(self, step: int) -> None:
        new_width = max(420, min(1600, self.width() + step))
        self.resize(new_width, self.height())
        self.save_preferences()

    def reset_size(self) -> None:
        self.font_size = 42
        self.resize(980, 135)
        self.apply_style()
        self.save_preferences()

    def contextMenuEvent(self, event) -> None:
        menu = QMenu(self)

        if self.locked:
            lock_action = menu.addAction("瑙ｉ攣浣嶇疆")
        else:
            lock_action = menu.addAction("閿佸畾浣嶇疆")

        bigger_action = menu.addAction("鏀惧ぇ姝岃瘝")
        smaller_action = menu.addAction("缂╁皬姝岃瘝")
        wider_action = menu.addAction("鍔犲鏄剧ず鍖哄煙")
        narrower_action = menu.addAction("缂╃獎鏄剧ず鍖哄煙")
        reset_size_action = menu.addAction("閲嶇疆澶у皬")

        menu.addSeparator()

        opacity_up_action = menu.addAction("鎻愰珮涓嶉€忔槑搴?)
        opacity_down_action = menu.addAction("闄嶄綆涓嶉€忔槑搴?)

        menu.addSeparator()

        color_menu = menu.addMenu("姝岃瘝棰滆壊")
        color_actions = {}

        for color_key, (color_label, _, _, _) in self.color_map.items():
            action = color_menu.addAction(color_label)
            action.setCheckable(True)
            action.setChecked(color_key == self.text_color_name)
            color_actions[action] = color_key

        menu.addSeparator()

        close_action = menu.addAction("鍏抽棴妗岄潰姝岃瘝")

        outline_action = menu.addAction("鍏抽棴鎻忚竟" if self.outline_enabled else "寮€鍚弿杈?)
        outline_action.setCheckable(True)
        outline_action.setChecked(self.outline_enabled)

        outline_color_menu = menu.addMenu("鎻忚竟棰滆壊")
        outline_color_actions = {}

        for color_key, (color_label, _, _, _) in self.outline_color_map.items():
            action = outline_color_menu.addAction(color_label)
            action.setCheckable(True)
            action.setChecked(color_key == self.outline_color_name)
            outline_color_actions[action] = color_key

        outline_strength_menu = menu.addMenu("鎻忚竟寮哄害")
        outline_strength_actions = {}

        for strength_key, (strength_label, _) in self.outline_strength_map.items():
            action = outline_strength_menu.addAction(strength_label)
            action.setCheckable(True)
            action.setChecked(strength_key == self.outline_strength)
            outline_strength_actions[action] = strength_key

        shadow_action = menu.addAction("鍏抽棴闃村奖" if self.shadow_enabled else "寮€鍚槾褰?)
        shadow_action.setCheckable(True)
        shadow_action.setChecked(self.shadow_enabled)

        menu.addSeparator()

        action = menu.exec(event.globalPos())

        if action == lock_action:
            self.locked = not self.locked
        elif action == bigger_action:
            self.adjust_font_size(3)
        elif action == smaller_action:
            self.adjust_font_size(-3)
        elif action == wider_action:
            self.adjust_window_width(100)
        elif action == narrower_action:
            self.adjust_window_width(-100)
        elif action == reset_size_action:
            self.reset_size()
        elif action == opacity_up_action:
            self.text_alpha = min(100, self.text_alpha + 10)
            self.apply_style()
            self.save_preferences()
        elif action == opacity_down_action:
            self.text_alpha = max(20, self.text_alpha - 10)
            self.apply_style()
            self.save_preferences()
        elif action in color_actions:
            self.text_color_name = color_actions[action]
            self.apply_style()
            self.save_preferences()
        elif action == outline_action:
            self.outline_enabled = not self.outline_enabled
            self.apply_style()
            self.save_preferences()
        elif action in outline_color_actions:
            self.outline_color_name = outline_color_actions[action]
            self.apply_style()
            self.save_preferences()
        elif action in outline_strength_actions:
            self.outline_strength = outline_strength_actions[action]
            self.apply_style()
            self.save_preferences()
        elif action == shadow_action:
            self.shadow_enabled = not self.shadow_enabled
            self.apply_style()
            self.save_preferences()
        elif action == close_action:
            self.close()

    def wheelEvent(self, event) -> None:
        delta = event.angleDelta().y()

        if delta == 0:
            return

        if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            if delta > 0:
                self.adjust_window_width(80)
            else:
                self.adjust_window_width(-80)
        else:
            if delta > 0:
                self.adjust_font_size(2)
            else:
                self.adjust_font_size(-2)

        event.accept()

    def mousePressEvent(self, event) -> None:
        if self.locked:
            return

        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
            return

        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        if self.locked:
            return

        if self.drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_offset)
            event.accept()
            return

        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        self.drag_offset = None
        super().mouseReleaseEvent(event)

    def closeEvent(self, event) -> None:
        if getattr(self.main_window, "floating_lyrics_window", None) is self:
            self.main_window.floating_lyrics_window = None

        try:
            self.main_window.update_floating_lyrics_button_state()
        except Exception:
            pass

        super().closeEvent(event)

class MetadataMatchDialog(QDialog):
    def __init__(self, song_data: dict, candidates: list[dict], parent=None) -> None:
        super().__init__(parent)
        self.candidates = candidates
        self.selected_candidate: dict | None = None

        self.setWindowTitle("鑱旂綉鍖归厤姝屾洸淇℃伅")
        self.setObjectName("metadataMatchDialog")
        self.setMinimumSize(720, 460)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(14)

        title = QLabel("閫夋嫨鍖归厤缁撴灉")
        title.setObjectName("playQueueDialogTitle")

        current_title = song_data.get("title", "")
        current_artist = song_data.get("artist", "")
        current_album = song_data.get("album", "")
        subtitle = QLabel(f"褰撳墠锛歿current_title} / {current_artist} / {current_album}")
        subtitle.setObjectName("playQueueDialogSubtitle")
        subtitle.setWordWrap(True)

        self.candidate_list = QListWidget()
        self.candidate_list.setObjectName("playQueueList")
        self.candidate_list.itemDoubleClicked.connect(self.apply_selected_candidate)

        for candidate in candidates:
            item = QListWidgetItem(self.format_candidate_text(candidate))
            item.setData(Qt.ItemDataRole.UserRole, candidate)
            self.candidate_list.addItem(item)

        if self.candidate_list.count() > 0:
            self.candidate_list.setCurrentRow(0)

        buttons = QHBoxLayout()
        buttons.setContentsMargins(0, 0, 0, 0)
        buttons.setSpacing(10)

        buttons.addStretch()

        cancel_btn = QPushButton("鍙栨秷")
        cancel_btn.setObjectName("queueSecondaryButton")
        cancel_btn.clicked.connect(self.reject)

        apply_btn = QPushButton("搴旂敤")
        apply_btn.setObjectName("queuePrimaryButton")
        apply_btn.clicked.connect(self.apply_selected_candidate)

        buttons.addWidget(cancel_btn)
        buttons.addWidget(apply_btn)

        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addWidget(self.candidate_list, 1)
        layout.addLayout(buttons)

        self.apply_style()

    def format_candidate_text(self, candidate: dict) -> str:
        title = candidate.get("title", "鏈煡姝屾洸")
        artist = candidate.get("artist", "鏈煡鑹烘湳瀹?)
        album = candidate.get("album", "鏈煡涓撹緫")
        date = candidate.get("release_date", "")
        score = candidate.get("score", "")
        score_text = f"score {score}" if score != "" else "score ?"
        date_text = str(date) if date else "鏃ユ湡鏈煡"
        return f"{title}    璺?   {artist}    璺?   {album}    璺?   {date_text}    璺?   {score_text}"

    def apply_selected_candidate(self) -> None:
        item = self.candidate_list.currentItem()

        if item is None:
            QMessageBox.information(self, "鑱旂綉鍖归厤姝屾洸淇℃伅", "璇峰厛閫夋嫨涓€涓€欓€夌粨鏋溿€?)
            return

        candidate = item.data(Qt.ItemDataRole.UserRole)

        if not isinstance(candidate, dict):
            QMessageBox.information(self, "鑱旂綉鍖归厤姝屾洸淇℃伅", "杩欎釜鍊欓€夌粨鏋滀笉鍙敤銆?)
            return

        self.selected_candidate = candidate
        self.accept()

    def apply_style(self) -> None:
        self.setStyleSheet(
            "QDialog#metadataMatchDialog { background: #101217; color: #e8ecf5; font-family: 'Microsoft YaHei UI'; }"
            "QLabel#playQueueDialogTitle { color: #ffffff; font-size: 24px; font-weight: 900; }"
            "QLabel#playQueueDialogSubtitle { color: #9ca5b5; font-size: 13px; }"
            "QListWidget#playQueueList { background: #171a22; color: #e8ecf5; border: 1px solid #252a35; border-radius: 16px; padding: 8px; outline: none; }"
            "QListWidget#playQueueList::item { padding: 12px 10px; border-radius: 10px; }"
            "QListWidget#playQueueList::item:hover { background: #232936; }"
            "QListWidget#playQueueList::item:selected { background: #2f68d8; color: #ffffff; }"
            "QPushButton#queuePrimaryButton { background: #2f68d8; color: #ffffff; border: none; border-radius: 12px; padding: 10px 16px; font-size: 13px; font-weight: 700; }"
            "QPushButton#queuePrimaryButton:hover { background: #3d7af0; }"
            "QPushButton#queueSecondaryButton { background: #232833; color: #dfe4ee; border: none; border-radius: 12px; padding: 10px 16px; font-size: 13px; }"
            "QPushButton#queueSecondaryButton:hover { background: #303747; }"
        )


class PlayQueueDialog(QDialog):
    def __init__(self, main_window) -> None:
        super().__init__(main_window)

        self.main_window = main_window
        self.setWindowTitle("鎾斁闃熷垪")
        self.setObjectName("playQueueDialog")
        self.setMinimumSize(620, 520)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(14)

        title = QLabel("鎾斁闃熷垪")
        title.setObjectName("playQueueDialogTitle")

        subtitle = QLabel("杩欓噷鏄剧ず鎺ヤ笅鏉ヤ細浼樺厛鎾斁鐨勬瓕鏇层€傞槦鍒楅噷鐨勬瓕浼氬厛浜庡垪琛ㄥ惊鐜?/ 闅忔満鎾斁銆?)
        subtitle.setObjectName("playQueueDialogSubtitle")
        subtitle.setWordWrap(True)

        self.queue_list = QListWidget()
        self.queue_list.setObjectName("playQueueList")
        self.queue_list.itemDoubleClicked.connect(self.play_selected_song)

        main_buttons = QHBoxLayout()
        main_buttons.setContentsMargins(0, 0, 0, 0)
        main_buttons.setSpacing(10)

        self.play_btn = QPushButton("绔嬪嵆鎾斁")
        self.play_btn.setObjectName("queuePrimaryButton")
        self.play_btn.clicked.connect(self.play_selected_song)

        self.remove_btn = QPushButton("绉婚櫎")
        self.remove_btn.setObjectName("queueSecondaryButton")
        self.remove_btn.clicked.connect(self.remove_selected_song)

        self.move_up_btn = QPushButton("涓婄Щ")
        self.move_up_btn.setObjectName("queueSecondaryButton")
        self.move_up_btn.clicked.connect(self.move_selected_song_up)

        self.move_down_btn = QPushButton("涓嬬Щ")
        self.move_down_btn.setObjectName("queueSecondaryButton")
        self.move_down_btn.clicked.connect(self.move_selected_song_down)

        self.clear_btn = QPushButton("娓呯┖闃熷垪")
        self.clear_btn.setObjectName("queueDangerButton")
        self.clear_btn.clicked.connect(self.clear_queue)

        self.close_btn = QPushButton("鍏抽棴")
        self.close_btn.setObjectName("queueSecondaryButton")
        self.close_btn.clicked.connect(self.accept)

        main_buttons.addWidget(self.play_btn)
        main_buttons.addWidget(self.remove_btn)
        main_buttons.addWidget(self.move_up_btn)
        main_buttons.addWidget(self.move_down_btn)
        main_buttons.addStretch(1)
        main_buttons.addWidget(self.clear_btn)
        main_buttons.addWidget(self.close_btn)

        self.hint_label = QLabel("鍙屽嚮闃熷垪閲岀殑姝屾洸鍙互绔嬪嵆鎾斁銆?)
        self.hint_label.setObjectName("playQueueHint")

        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addWidget(self.queue_list, 1)
        layout.addLayout(main_buttons)
        layout.addWidget(self.hint_label)

        self.apply_style()
        self.refresh_queue_list()

    def apply_style(self) -> None:
        self.setStyleSheet(
            "QDialog#playQueueDialog { background: #101217; color: #e8ecf5; font-family: 'Microsoft YaHei UI'; }"
            "QLabel#playQueueDialogTitle { color: #ffffff; font-size: 26px; font-weight: 900; }"
            "QLabel#playQueueDialogSubtitle { color: #9ca5b5; font-size: 13px; }"
            "QLabel#playQueueHint { color: #8f98a8; font-size: 12px; }"
            "QListWidget#playQueueList { background: #171a22; color: #e8ecf5; border: 1px solid #252a35; border-radius: 16px; padding: 8px; outline: none; }"
            "QListWidget#playQueueList::item { padding: 12px 10px; border-radius: 10px; }"
            "QListWidget#playQueueList::item:hover { background: #232936; }"
            "QListWidget#playQueueList::item:selected { background: #2f68d8; color: #ffffff; }"
            "QPushButton#queuePrimaryButton { background: #2f68d8; color: #ffffff; border: none; border-radius: 12px; padding: 10px 16px; font-size: 13px; font-weight: 700; }"
            "QPushButton#queuePrimaryButton:hover { background: #3d7af0; }"
            "QPushButton#queueSecondaryButton { background: #232833; color: #dfe4ee; border: none; border-radius: 12px; padding: 10px 16px; font-size: 13px; }"
            "QPushButton#queueSecondaryButton:hover { background: #303747; }"
            "QPushButton#queueDangerButton { background: #3a2024; color: #ffd7dd; border: none; border-radius: 12px; padding: 10px 16px; font-size: 13px; }"
            "QPushButton#queueDangerButton:hover { background: #71303a; color: #ffffff; }"
        )

    def refresh_queue_list(self) -> None:
        if not hasattr(self.main_window, "play_queue"):
            self.main_window.play_queue = []

        valid_queue = []

        for song_path in self.main_window.play_queue:
            normalized_path = self.main_window.normalize_song_path(song_path)

            if normalized_path and Path(normalized_path).exists():
                valid_queue.append(normalized_path)

        if valid_queue != self.main_window.play_queue:
            self.main_window.play_queue = valid_queue
            self.main_window.save_play_queue()

        self.queue_list.clear()

        for index, song_path in enumerate(self.main_window.play_queue, start=1):
            song_title = self.main_window.get_song_title_for_queue(song_path)
            item = QListWidgetItem(f"{index}. {song_title}")
            item.setData(Qt.ItemDataRole.UserRole, song_path)
            self.queue_list.addItem(item)

        if self.queue_list.count() > 0 and self.queue_list.currentRow() < 0:
            self.queue_list.setCurrentRow(0)

        self.update_hint()

    def update_hint(self) -> None:
        count = self.queue_list.count()

        if count == 0:
            self.hint_label.setText("鎾斁闃熷垪鏄┖鐨勩€傚彲浠ュ湪闊充箰搴撻噷鍙抽敭姝屾洸锛岄€夋嫨鈥滀笅涓€棣栨挱鏀锯€濇垨鈥滃姞鍏ユ挱鏀鹃槦鍒椻€濄€?)
        else:
            self.hint_label.setText(f"闃熷垪閲屾湁 {count} 棣栨瓕銆傚弻鍑绘瓕鏇插彲浠ョ珛鍗虫挱鏀俱€?)

    def get_selected_index(self) -> int:
        row = self.queue_list.currentRow()

        if row < 0 or row >= len(self.main_window.play_queue):
            QMessageBox.information(self, "鎾斁闃熷垪", "璇峰厛閫夋嫨闃熷垪閲岀殑涓€棣栨瓕銆?)
            return -1

        return row

    def play_selected_song(self) -> None:
        row = self.get_selected_index()

        if row < 0:
            return

        song_path = self.main_window.play_queue.pop(row)
        self.main_window.save_play_queue()

        if self.main_window.play_song_from_queue_path(song_path):
            self.refresh_queue_list()
            self.accept()
        else:
            QMessageBox.information(self, "鎾斁闃熷垪", "杩欓姝屾棤娉曟挱鏀撅紝鍙兘鏂囦欢宸茬粡涓嶅瓨鍦ㄣ€?)
            self.refresh_queue_list()

    def remove_selected_song(self) -> None:
        row = self.get_selected_index()

        if row < 0:
            return

        self.main_window.play_queue.pop(row)
        self.main_window.save_play_queue()
        self.refresh_queue_list()

        if self.queue_list.count() > 0:
            self.queue_list.setCurrentRow(min(row, self.queue_list.count() - 1))

    def move_selected_song_up(self) -> None:
        row = self.get_selected_index()

        if row <= 0:
            return

        queue = self.main_window.play_queue
        queue[row - 1], queue[row] = queue[row], queue[row - 1]
        self.main_window.save_play_queue()
        self.refresh_queue_list()
        self.queue_list.setCurrentRow(row - 1)

    def move_selected_song_down(self) -> None:
        row = self.get_selected_index()

        if row < 0 or row >= len(self.main_window.play_queue) - 1:
            return

        queue = self.main_window.play_queue
        queue[row + 1], queue[row] = queue[row], queue[row + 1]
        self.main_window.save_play_queue()
        self.refresh_queue_list()
        self.queue_list.setCurrentRow(row + 1)

    def clear_queue(self) -> None:
        if not self.main_window.play_queue:
            QMessageBox.information(self, "鎾斁闃熷垪", "鎾斁闃熷垪宸茬粡鏄┖鐨勩€?)
            return

        reply = QMessageBox.question(
            self,
            "娓呯┖鎾斁闃熷垪",
            "纭畾瑕佹竻绌哄綋鍓嶆挱鏀鹃槦鍒楀悧锛?,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )

        if reply != QMessageBox.StandardButton.Yes:
            return

        self.main_window.play_queue.clear()
        self.main_window.save_play_queue()
        self.refresh_queue_list()

class SettingsDialog(QDialog):
    def __init__(self, main_window) -> None:
        super().__init__(main_window)

        self.main_window = main_window
        self.setWindowTitle("HushPlayer 璁剧疆")
        self.setObjectName("settingsDialog")
        self.setMinimumWidth(520)

        settings = self.main_window.get_hush_settings()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 22)
        layout.setSpacing(18)

        title = QLabel("璁剧疆")
        title.setObjectName("settingsDialogTitle")

        subtitle = QLabel("鍏堟妸甯哥敤璁剧疆鏀惰繘鏉ワ紝鍚庨潰鎴戜滑鍐嶆參鎱㈠仛鎴愬畬鏁磋缃〉銆?)
        subtitle.setObjectName("settingsDialogSubtitle")
        subtitle.setWordWrap(True)

        layout.addWidget(title)
        layout.addWidget(subtitle)

        playback_card = QFrame()
        playback_card.setObjectName("settingsCard")
        playback_layout = QVBoxLayout(playback_card)
        playback_layout.setContentsMargins(18, 16, 18, 16)
        playback_layout.setSpacing(12)

        playback_title = QLabel("鎾斁")
        playback_title.setObjectName("settingsCardTitle")

        self.restore_checkbox = QCheckBox("鍚姩鏃舵仮澶嶄笂娆℃挱鏀剧殑姝屾洸鍜岃繘搴?)
        self.restore_checkbox.setChecked(bool(settings.get("restore_last_playback", True)))

        playback_layout.addWidget(playback_title)
        playback_layout.addWidget(self.restore_checkbox)

        immersive_card = QFrame()
        immersive_card.setObjectName("settingsCard")
        immersive_layout = QVBoxLayout(immersive_card)
        immersive_layout.setContentsMargins(18, 16, 18, 16)
        immersive_layout.setSpacing(12)

        immersive_title = QLabel("娌夋蹈姝岃瘝")
        immersive_title.setObjectName("settingsCardTitle")

        self.cover_background_checkbox = QCheckBox("榛樿浣跨敤灏侀潰妯＄硦鑳屾櫙")
        self.cover_background_checkbox.setChecked(bool(settings.get("immersive_cover_background_enabled", True)))

        self.auto_hide_checkbox = QCheckBox("榛樿鑷姩闅愯棌娌夋蹈姝岃瘝 UI")
        self.auto_hide_checkbox.setChecked(bool(settings.get("immersive_auto_hide_ui", True)))

        alpha_row = QHBoxLayout()
        alpha_row.setContentsMargins(0, 0, 0, 0)
        alpha_row.setSpacing(12)

        self.alpha_label = QLabel()
        self.alpha_label.setObjectName("settingsValueLabel")

        self.alpha_slider = QSlider(Qt.Orientation.Horizontal)
        self.alpha_slider.setRange(35, 100)
        self.alpha_slider.setValue(int(settings.get("immersive_background_alpha", 68)))
        self.alpha_slider.valueChanged.connect(self.update_alpha_label)

        alpha_row.addWidget(QLabel("閬僵涓嶉€忔槑搴?))
        alpha_row.addWidget(self.alpha_slider, 1)
        alpha_row.addWidget(self.alpha_label)

        self.update_alpha_label(self.alpha_slider.value())

        immersive_layout.addWidget(immersive_title)
        immersive_layout.addWidget(self.cover_background_checkbox)
        immersive_layout.addWidget(self.auto_hide_checkbox)
        immersive_layout.addLayout(alpha_row)

        cache_card = QFrame()
        cache_card.setObjectName("settingsCard")
        cache_layout = QVBoxLayout(cache_card)
        cache_layout.setContentsMargins(18, 16, 18, 16)
        cache_layout.setSpacing(12)

        cache_title = QLabel("缂撳瓨")
        cache_title.setObjectName("settingsCardTitle")

        cache_hint = QLabel("濡傛灉涔嬪墠鏌愪簺姝屽皝闈㈡垨姝岃瘝鎼滀笉鍒帮紝娓呯悊澶辫触缂撳瓨鍚庡彲浠ュ彸閿瓕鏇查噸鏂版悳绱€?)
        cache_hint.setObjectName("settingsHint")
        cache_hint.setWordWrap(True)

        clear_missing_btn = QPushButton("娓呯悊灏侀潰 / 姝岃瘝澶辫触缂撳瓨")
        clear_missing_btn.setObjectName("settingsSecondaryButton")
        clear_missing_btn.clicked.connect(self.clear_missing_cache)

        cache_layout.addWidget(cache_title)
        cache_layout.addWidget(cache_hint)
        cache_layout.addWidget(clear_missing_btn)

        layout.addWidget(playback_card)
        layout.addWidget(immersive_card)
        layout.addWidget(cache_card)

        button_row = QHBoxLayout()
        button_row.setContentsMargins(0, 4, 0, 0)
        button_row.setSpacing(12)

        save_btn = QPushButton("淇濆瓨璁剧疆")
        save_btn.setObjectName("settingsPrimaryButton")
        save_btn.clicked.connect(self.save_settings)

        cancel_btn = QPushButton("鍙栨秷")
        cancel_btn.setObjectName("settingsSecondaryButton")
        cancel_btn.clicked.connect(self.reject)

        button_row.addStretch(1)
        button_row.addWidget(cancel_btn)
        button_row.addWidget(save_btn)

        layout.addLayout(button_row)

        self.apply_style()

    def apply_style(self) -> None:
        self.setStyleSheet(
            "QDialog#settingsDialog { background: #101217; color: #e8ecf5; font-family: 'Microsoft YaHei UI'; }"
            "QLabel#settingsDialogTitle { color: #ffffff; font-size: 26px; font-weight: 900; }"
            "QLabel#settingsDialogSubtitle { color: #9ca5b5; font-size: 13px; }"
            "QFrame#settingsCard { background: #171a22; border: 1px solid #252a35; border-radius: 18px; }"
            "QLabel#settingsCardTitle { color: #ffffff; font-size: 16px; font-weight: 800; }"
            "QLabel#settingsHint { color: #9ca5b5; font-size: 12px; }"
            "QLabel#settingsValueLabel { color: #d9deea; font-size: 12px; min-width: 42px; }"
            "QCheckBox { color: #dfe4ee; font-size: 13px; spacing: 9px; }"
            "QCheckBox::indicator { width: 18px; height: 18px; border-radius: 5px; border: 1px solid #3c4352; background: #0f1218; }"
            "QCheckBox::indicator:checked { background: #2f68d8; border: 1px solid #2f68d8; }"
            "QPushButton#settingsPrimaryButton { background: #2f68d8; color: #ffffff; border: none; border-radius: 12px; padding: 10px 18px; font-size: 13px; font-weight: 700; }"
            "QPushButton#settingsPrimaryButton:hover { background: #3d7af0; }"
            "QPushButton#settingsSecondaryButton { background: #232833; color: #dfe4ee; border: none; border-radius: 12px; padding: 10px 16px; font-size: 13px; }"
            "QPushButton#settingsSecondaryButton:hover { background: #303747; }"
            "QSlider::groove:horizontal { height: 5px; background: #303747; border-radius: 3px; }"
            "QSlider::handle:horizontal { width: 16px; height: 16px; margin: -6px 0; background: #ffffff; border-radius: 8px; }"
            "QSlider::sub-page:horizontal { background: #2f68d8; border-radius: 3px; }"
        )

    def update_alpha_label(self, value: int) -> None:
        self.alpha_label.setText(f"{int(value)}%")

    def save_settings(self) -> None:
        updates = {
            "restore_last_playback": self.restore_checkbox.isChecked(),
            "immersive_cover_background_enabled": self.cover_background_checkbox.isChecked(),
            "immersive_auto_hide_ui": self.auto_hide_checkbox.isChecked(),
            "immersive_background_alpha": int(self.alpha_slider.value()),
        }

        self.main_window.save_hush_settings(updates)
        self.main_window.apply_runtime_settings()
        QMessageBox.information(self, "璁剧疆", "璁剧疆宸蹭繚瀛樸€?)
        self.accept()

    def clear_missing_cache(self) -> None:
        removed_count = self.main_window.clear_missing_cache_files()
        QMessageBox.information(self, "缂撳瓨", f"宸叉竻鐞?{removed_count} 涓け璐ョ紦瀛樻枃浠躲€?)

class ImmersiveLyricsWindow(QWidget):
    def __init__(self, main_window) -> None:
        super().__init__()

        self.main_window = main_window
        self.transparent_mode = True
        self.cover_background_enabled = bool(
            main_window.get_user_setting("immersive_cover_background_enabled", True)
        )
        self.background_alpha = int(
            main_window.get_user_setting("immersive_background_alpha", 68)
        )
        self.cover_background_pixmap = None
        self.ui_visible = True
        self.auto_hide_enabled = bool(
            main_window.get_user_setting("immersive_auto_hide_ui", True)
        )

        self.setWindowTitle("HushPlayer 娌夋蹈姝岃瘝")
        self.setObjectName("immersiveLyricsWindow")
        self.setMinimumSize(1000, 700)
        self.setMouseTracking(True)

        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
        self.setWindowOpacity(1.0)

        self.hide_ui_timer = QTimer(self)
        self.hide_ui_timer.setSingleShot(True)
        self.hide_ui_timer.timeout.connect(self.hide_controls_if_needed)

        self.cover_background_label = QLabel(self)
        self.cover_background_label.setObjectName("immersiveCoverBackground")
        self.cover_background_label.setScaledContents(True)
        self.cover_background_label.hide()

        self.cover_blur_effect = QGraphicsBlurEffect(self.cover_background_label)
        self.cover_blur_effect.setBlurRadius(42)
        self.cover_background_label.setGraphicsEffect(self.cover_blur_effect)

        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(0)

        self.background_panel = QFrame()
        self.background_panel.setObjectName("immersiveBackgroundPanel")
        self.background_panel.setMouseTracking(True)
        self.background_panel.installEventFilter(self)

        outer_layout.addWidget(self.background_panel)

        layout = QVBoxLayout(self.background_panel)
        layout.setContentsMargins(46, 34, 46, 34)
        layout.setSpacing(22)

        self.control_header = QFrame()
        self.control_header.setObjectName("immersiveControlHeader")
        self.control_header.setMouseTracking(True)
        self.control_header.installEventFilter(self)

        header = QHBoxLayout(self.control_header)
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(18)

        title_box = QVBoxLayout()
        title_box.setContentsMargins(0, 0, 0, 0)
        title_box.setSpacing(7)

        self.song_title = ElidedLabel("杩樻病鏈夋挱鏀鹃煶涔?)
        self.song_title.setObjectName("immersiveSongTitle")
        self.song_title.setMinimumWidth(520)

        self.song_artist = ElidedLabel("鍙屽嚮姝屾洸鎴栧彸閿挱鏀惧悗鎵撳紑娌夋蹈姝岃瘝")
        self.song_artist.setObjectName("immersiveSongArtist")
        self.song_artist.setMinimumWidth(520)

        self.status_label = QLabel("绛夊緟鎾斁姝屾洸")
        self.status_label.setObjectName("immersiveStatus")

        title_box.addWidget(self.song_title)
        title_box.addWidget(self.song_artist)
        title_box.addWidget(self.status_label)

        self.fullscreen_btn = QPushButton("鍓睆鍏ㄥ睆")
        self.fullscreen_btn.setObjectName("immersiveButton")
        self.fullscreen_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.fullscreen_btn.clicked.connect(self.show_on_best_screen)

        self.window_btn = QPushButton("绐楀彛妯″紡")
        self.window_btn.setObjectName("immersiveButton")
        self.window_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.window_btn.clicked.connect(self.show_windowed)

        self.transparent_btn = QPushButton("鍒囨崲绾粦")
        self.transparent_btn.setObjectName("immersiveButton")
        self.transparent_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.transparent_btn.clicked.connect(self.toggle_transparent_mode)

        self.cover_bg_btn = QPushButton("鍒囨崲绾壊")
        self.cover_bg_btn.setObjectName("immersiveButton")
        self.cover_bg_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.cover_bg_btn.clicked.connect(self.toggle_cover_background)

        self.auto_hide_btn = QPushButton("甯告樉 UI")
        self.auto_hide_btn.setObjectName("immersiveButton")
        self.auto_hide_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.auto_hide_btn.clicked.connect(self.toggle_auto_hide)

        self.close_btn = QPushButton("閫€鍑烘矇娴?)
        self.close_btn.setObjectName("immersiveButton")
        self.close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.close_btn.clicked.connect(self.close)

        button_box = QHBoxLayout()
        button_box.setContentsMargins(0, 0, 0, 0)
        button_box.setSpacing(10)
        button_box.addWidget(self.fullscreen_btn)
        button_box.addWidget(self.window_btn)
        button_box.addWidget(self.transparent_btn)
        button_box.addWidget(self.cover_bg_btn)
        button_box.addWidget(self.auto_hide_btn)
        button_box.addWidget(self.close_btn)

        alpha_box = QHBoxLayout()
        alpha_box.setContentsMargins(0, 0, 0, 0)
        alpha_box.setSpacing(10)

        self.alpha_label = QLabel("閬僵涓嶉€忔槑搴?68%")
        self.alpha_label.setObjectName("immersiveOpacityLabel")

        self.alpha_slider = QSlider(Qt.Orientation.Horizontal)
        self.alpha_slider.setObjectName("immersiveOpacitySlider")
        self.alpha_slider.setRange(35, 100)
        self.alpha_slider.setValue(self.background_alpha)
        self.alpha_slider.setFixedWidth(240)
        self.alpha_slider.valueChanged.connect(self.change_background_alpha)

        alpha_box.addWidget(self.alpha_label)
        alpha_box.addWidget(self.alpha_slider)

        control_box = QVBoxLayout()
        control_box.setContentsMargins(0, 0, 0, 0)
        control_box.setSpacing(10)
        control_box.addLayout(button_box)
        control_box.addLayout(alpha_box)

        header.addLayout(title_box, 1)
        header.addLayout(control_box)

        self.lyrics_view = LyricsView()
        self.lyrics_view.setObjectName("immersiveLyricsView")
        self.lyrics_view.setMouseTracking(True)
        self.lyrics_view.installEventFilter(self)

        if self.lyrics_view.viewport():
            self.lyrics_view.viewport().setMouseTracking(True)
            self.lyrics_view.viewport().installEventFilter(self)

        self.lyrics_view.set_placeholder(
            "杩樻病鏈夋鍦ㄦ挱鏀剧殑姝岃瘝",
            "鎾斁涓€棣栨瓕鍚庯紝杩欓噷浼氭樉绀烘矇娴告瓕璇?,
        )

        self.footer = QLabel("绉诲姩榧犳爣鏄剧ず鎺у埗鏍?路 Esc 閫€鍑烘矇娴?路 褰撳墠锛氬皝闈㈡ā绯婅儗鏅?)
        self.footer.setObjectName("immersiveFooter")
        self.footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.footer.setMouseTracking(True)
        self.footer.installEventFilter(self)

        layout.addWidget(self.control_header)
        layout.addWidget(self.lyrics_view, 1)
        layout.addWidget(self.footer)

        self.apply_immersive_style()
        self.show_controls_temporarily()

    def eventFilter(self, watched, event) -> bool:
        if event.type() in (
            QEvent.Type.MouseMove,
            QEvent.Type.Enter,
            QEvent.Type.MouseButtonPress,
        ):
            self.show_controls_temporarily()

        return super().eventFilter(watched, event)

    def mouseMoveEvent(self, event) -> None:
        self.show_controls_temporarily()
        super().mouseMoveEvent(event)

    def show_controls_temporarily(self) -> None:
        self.setCursor(Qt.CursorShape.ArrowCursor)

        if not self.ui_visible:
            self.control_header.show()
            self.footer.show()
            self.ui_visible = True

        if self.auto_hide_enabled:
            self.hide_ui_timer.start(2200)

    def hide_controls_if_needed(self) -> None:
        if not self.auto_hide_enabled:
            return

        if not self.isVisible():
            return

        self.control_header.hide()
        self.footer.hide()
        self.ui_visible = False
        self.setCursor(Qt.CursorShape.BlankCursor)

    def toggle_auto_hide(self) -> None:
        self.auto_hide_enabled = not self.auto_hide_enabled

        if self.auto_hide_enabled:
            self.auto_hide_btn.setText("甯告樉 UI")
            self.show_controls_temporarily()
        else:
            self.hide_ui_timer.stop()
            self.control_header.show()
            self.footer.show()
            self.ui_visible = True
            self.setCursor(Qt.CursorShape.ArrowCursor)
            self.auto_hide_btn.setText("闅愯棌 UI")

        self.apply_immersive_style()

    def apply_immersive_style(self) -> None:
        self.setWindowOpacity(1.0)

        if self.transparent_mode:
            alpha = max(0, min(255, int(self.background_alpha / 100 * 255)))
            background = f"rgba(5, 6, 9, {alpha})"
            button_background = "rgba(31, 35, 44, 190)"
            mode_name = "灏侀潰妯＄硦鑳屾櫙" if self.cover_background_enabled else "鍗婇€忔槑绾壊鑳屾櫙"
            footer_text = f"绉诲姩榧犳爣鏄剧ず鎺у埗鏍?路 Esc 閫€鍑烘矇娴?路 褰撳墠锛歿mode_name} 路 閬僵涓嶉€忔槑搴?{self.background_alpha}%"
            button_text = "鍒囨崲绾粦"
            slider_enabled = True
        else:
            background = "#050609"
            button_background = "#1f232c"
            footer_text = "绉诲姩榧犳爣鏄剧ず鎺у埗鏍?路 Esc 閫€鍑烘矇娴?路 褰撳墠锛氱函榛戣儗鏅?
            button_text = "鍒囨崲鍗婇€忔槑"
            slider_enabled = False

        if self.cover_background_enabled:
            cover_button_text = "鍒囨崲绾壊"
        else:
            cover_button_text = "鍒囨崲灏侀潰"

        if self.auto_hide_enabled:
            auto_hide_text = "甯告樉 UI"
        else:
            auto_hide_text = "闅愯棌 UI"

        self.footer.setText(footer_text)
        self.transparent_btn.setText(button_text)
        self.cover_bg_btn.setText(cover_button_text)
        self.auto_hide_btn.setText(auto_hide_text)
        self.alpha_label.setText(f"閬僵涓嶉€忔槑搴?{self.background_alpha}%")
        self.alpha_slider.setEnabled(slider_enabled)

        self.setStyleSheet(
            "QWidget#immersiveLyricsWindow { background: transparent; color: #ffffff; font-family: 'Microsoft YaHei UI'; }"
            f"QFrame#immersiveBackgroundPanel {{ background: {background}; }}"
            "QFrame#immersiveControlHeader { background: transparent; }"
            "QLabel#immersiveSongTitle { color: #ffffff; font-size: 30px; font-weight: 900; }"
            "QLabel#immersiveSongArtist { color: #d0d5df; font-size: 15px; }"
            "QLabel#immersiveStatus { color: #9aa3b2; font-size: 12px; }"
            "QLabel#immersiveFooter { color: #8e96a5; font-size: 12px; }"
            "QLabel#immersiveOpacityLabel { color: #c7ceda; font-size: 12px; }"
            f"QPushButton#immersiveButton {{ background: {button_background}; color: #dfe3ec; border: none; border-radius: 12px; padding: 10px 14px; font-size: 13px; }}"
            "QPushButton#immersiveButton:hover { background: #2f68d8; color: #ffffff; }"
            "QSlider#immersiveOpacitySlider::groove:horizontal { height: 5px; background: rgba(255,255,255,55); border-radius: 3px; }"
            "QSlider#immersiveOpacitySlider::handle:horizontal { width: 16px; height: 16px; margin: -6px 0; background: #ffffff; border-radius: 8px; }"
            "QSlider#immersiveOpacitySlider::sub-page:horizontal { background: #2f68d8; border-radius: 3px; }"
            "QSlider#immersiveOpacitySlider:disabled::handle:horizontal { background: #6f7786; }"
            "QScrollArea#immersiveLyricsView, QScrollArea#lyricsView { background: transparent; border: none; }"
            "QWidget#lyricsContent { background: transparent; }"
            "QLabel#lyricPlaceholderTitle { color: #ffffff; font-size: 28px; font-weight: 900; }"
            "QLabel#lyricPlaceholderSubtitle { color: #c1c7d2; font-size: 15px; }"
            "QLabel#lyricLine { color: rgba(215,222,235,90); font-size: 24px; font-weight: 600; padding: 42px 10px; }"
            "QLabel#lyricLine[lyricState='near'] { color: rgba(236,240,248,155); font-size: 44px; font-weight: 800; padding: 70px 10px; }"
            "QLabel#lyricLine[lyricState='current'] { color: #ffffff; font-size: 118px; font-weight: 950; padding: 104px 10px; }"
        )

        self.refresh_cover_background()

    def change_background_alpha(self, value: int) -> None:
        self.background_alpha = int(value)
        self.apply_immersive_style()

    def toggle_transparent_mode(self) -> None:
        self.transparent_mode = not self.transparent_mode
        self.apply_immersive_style()
        self.show_controls_temporarily()

    def toggle_cover_background(self) -> None:
        self.cover_background_enabled = not self.cover_background_enabled
        self.apply_immersive_style()
        self.show_controls_temporarily()

    def update_background_cover(self, pixmap) -> None:
        if pixmap is None or pixmap.isNull():
            self.cover_background_pixmap = None
        else:
            self.cover_background_pixmap = pixmap.copy()

        self.refresh_cover_background()

    def refresh_cover_background(self) -> None:
        if not hasattr(self, "cover_background_label"):
            return

        if (
            not self.transparent_mode
            or not self.cover_background_enabled
            or self.cover_background_pixmap is None
            or self.cover_background_pixmap.isNull()
        ):
            self.cover_background_label.hide()
            return

        target_size = self.size()

        if target_size.width() <= 0 or target_size.height() <= 0:
            self.cover_background_label.hide()
            return

        scaled = self.cover_background_pixmap.scaled(
            target_size,
            Qt.AspectRatioMode.KeepAspectRatioByExpanding,
            Qt.TransformationMode.SmoothTransformation,
        )

        crop_x = max(0, (scaled.width() - target_size.width()) // 2)
        crop_y = max(0, (scaled.height() - target_size.height()) // 2)

        cropped = scaled.copy(
            crop_x,
            crop_y,
            target_size.width(),
            target_size.height(),
        )

        self.cover_background_label.setGeometry(self.rect())
        self.cover_background_label.setPixmap(cropped)
        self.cover_background_label.show()
        self.cover_background_label.lower()
        self.background_panel.raise_()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self.refresh_cover_background()

    def show_on_best_screen(self) -> None:
        screens = QApplication.screens()
        target_screen = None

        if len(screens) >= 2:
            target_screen = screens[1]
        elif screens:
            target_screen = screens[0]

        if target_screen:
            self.setGeometry(target_screen.availableGeometry())

        self.showFullScreen()
        self.raise_()
        self.activateWindow()
        self.show_controls_temporarily()

    def show_windowed(self) -> None:
        self.showNormal()
        self.resize(1100, 720)
        self.raise_()
        self.activateWindow()
        self.show_controls_temporarily()

    def update_song_info(self, title: str, artist_album: str, status: str) -> None:
        self.song_title.setText(title)
        self.song_artist.setText(artist_album)
        self.status_label.setText(status)

    def set_lyrics(self, lyrics: list[tuple[int, str]]) -> None:
        if lyrics:
            self.lyrics_view.set_lyrics(lyrics)
        else:
            self.lyrics_view.set_placeholder(
                "褰撳墠姝屾洸鏆傛棤姝岃瘝",
                "鍙互鍙抽敭姝屾洸鎵嬪姩缁戝畾姝岃瘝锛屾垨鑰呴噸鏂版悳绱㈡瓕璇?,
            )

    def update_position(self, position: int, lyrics: list[tuple[int, str]]) -> None:
        self.lyrics_view.update_by_position(position, lyrics)

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key.Key_Escape:
            self.close()
            return

        if event.key() == Qt.Key.Key_Space:
            self.toggle_auto_hide()
            return

        super().keyPressEvent(event)

    def showEvent(self, event) -> None:
        super().showEvent(event)

        if getattr(self, "restored_playback_session", False):
            return

        QTimer.singleShot(500, self.restore_playback_session)

    def closeEvent(self, event) -> None:
        self.setWindowOpacity(1.0)
        self.setCursor(Qt.CursorShape.ArrowCursor)
        self.hide_ui_timer.stop()

        if getattr(self.main_window, "immersive_lyrics_window", None) is self:
            self.main_window.immersive_lyrics_window = None

        super().closeEvent(event)

class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()

        self.current_song_path: str | None = None
        self.browsing_song_path: str | None = None
        self.browsing_song_data: dict | None = None

        self.cover_request_id = 0
        self.lyrics_request_id = 0
        self.active_cover_request_id = ""
        self.active_lyrics_request_id = ""
        self.cover_threads: list[QThread] = []
        self.lyrics_threads: list[QThread] = []
        self.cover_workers: list[QObject] = []
        self.lyrics_workers: list[QObject] = []
        self.displayed_lyrics_song_path: str | None = None
        self.immersive_lyrics_window: ImmersiveLyricsWindow | None = None

        self.session_save_timer = QTimer(self)
        self.session_save_timer.timeout.connect(self.save_playback_session)
        self.session_save_timer.start(5000)
        self.current_duration = 0
        self.is_seeking = False
        self.last_musicbrainz_request_time = 0.0

        self.current_lyrics: list[tuple[int, str]] = []
        self.shortcuts: list[QShortcut] = []

        self.project_root = Path(__file__).resolve().parents[2]
        self.library_file = self.project_root / "data" / "library.json"
        self.settings_file = self.project_root / "data" / "settings.json"
        self.playlists_file = self.project_root / "data" / "playlists.json"
        self.stats_file = self.project_root / "data" / "stats.json"
        self.cover_cache_dir = self.project_root / "cache" / "covers"
        self.lyrics_cache_dir = self.project_root / "cache" / "lyrics"
        self.lyrics_bindings_file = self.project_root / "data" / "lyrics_bindings.json"
        self.playback_session_file = self.project_root / "data" / "playback_session.json"
        self.play_queue_file = self.project_root / "data" / "play_queue.json"
        self.metadata_cache_file = self.project_root / "data" / "metadata_cache.json"

        settings = self.load_settings()
        self.current_volume = int(settings.get("volume", 65))
        self.play_mode = settings.get("play_mode", "list_loop")
        self.playlists = self.load_playlists()
        self.song_stats = self.load_song_stats()
        self.lyrics_bindings = self.load_lyrics_bindings()
        self.playback_session = self.load_playback_session()
        self.play_queue = self.load_play_queue()
        self.metadata_cache = self.load_metadata_cache()
        self.restored_playback_session = False

        self.last_recorded_position = 0
        self.pending_listen_ms = 0
        self.current_session_listen_ms = 0
        self.play_count_marked = False

        self.current_library_view = "all"
        self.library_browser_mode = "songs"
        self.active_artist_name = ""
        self.active_album_key: tuple[str, str] | None = None
        self.library_songs: list[dict] = []
        self.view_buttons = {}
        self.browser_mode_buttons = {}
        self.custom_view_buttons = []

        self.http_headers = {
            "User-Agent": "HushPlayer/0.5.4.3 (local music player prototype)",
            "Accept": "application/json, image/*",
        }

        print("椤圭洰鏍圭洰褰曪細", self.project_root)
        print("闊充箰搴撲繚瀛樹綅缃細", self.library_file)
        print("璁剧疆淇濆瓨浣嶇疆锛?, self.settings_file)
        print("姝屽崟淇濆瓨浣嶇疆锛?, self.playlists_file)
        print("鎾斁缁熻淇濆瓨浣嶇疆锛?, self.stats_file)
        print("灏侀潰缂撳瓨浣嶇疆锛?, self.cover_cache_dir)
        print("姝岃瘝缂撳瓨浣嶇疆锛?, self.lyrics_cache_dir)
        print("姝岃瘝缁戝畾淇濆瓨浣嶇疆锛?, self.lyrics_bindings_file)

        print("褰撳墠鍙敤闊抽杈撳嚭璁惧锛?)
        audio_outputs = QMediaDevices.audioOutputs()
        for device in audio_outputs:
            print("-", device.description())

        default_device = QMediaDevices.defaultAudioOutput()
        print("榛樿闊抽杈撳嚭璁惧锛?, default_device.description())

        self.audio_output = QAudioOutput(default_device)
        self.media_player = QMediaPlayer()
        self.media_player.setAudioOutput(self.audio_output)
        self.audio_output.setVolume(self.current_volume / 100)

        self.setWindowTitle("HushPlayer")
        self.resize(1400, 860)
        self.setMinimumSize(1100, 720)
        self.setAcceptDrops(True)

        root = QWidget()
        root.setObjectName("root")
        root.setAcceptDrops(True)

        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(18, 18, 18, 18)

        shell = QFrame()
        shell.setObjectName("shell")
        shell.setAcceptDrops(True)

        shell_layout = QVBoxLayout(shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)

        body_layout = QHBoxLayout()
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)

        sidebar = self._create_sidebar()
        library_panel = self._create_library_panel()
        full_lyrics_page = self._create_full_lyrics_page()
        now_playing_panel = self._create_now_playing_panel()

        self.content_stack = QStackedWidget()
        self.content_stack.setObjectName("contentStack")
        self.content_stack.addWidget(library_panel)
        self.content_stack.addWidget(full_lyrics_page)

        body_layout.addWidget(sidebar)
        body_layout.addWidget(self.content_stack, 1)
        body_layout.addWidget(now_playing_panel)

        player_bar = self._create_player_bar()

        shell_layout.addLayout(body_layout, 1)
        shell_layout.addWidget(player_bar)

        root_layout.addWidget(shell)
        self.setCentralWidget(root)

        self._connect_player_signals()
        self._create_shortcuts()
        self.setStyleSheet(self._style_sheet())
        self.load_music_library()
        self.update_play_mode_button()
        self.update_like_button()
        self.update_side_info_panel()
        self.update_view_buttons()

        QTimer.singleShot(0, self.install_settings_button_hook)
        QTimer.singleShot(0, self.install_playlist_button_hook)
        QTimer.singleShot(0, self.install_floating_lyrics_feature)
        QTimer.singleShot(0, self.install_floating_lyrics_button)

    def _connect_player_signals(self) -> None:
        self.media_player.positionChanged.connect(self.on_position_changed)
        self.media_player.durationChanged.connect(self.on_duration_changed)
        self.media_player.playbackStateChanged.connect(self.on_playback_state_changed)
        self.media_player.mediaStatusChanged.connect(self.on_media_status_changed)
        self.media_player.errorOccurred.connect(self.on_player_error)

    def _create_shortcuts(self) -> None:
        shortcut_configs = [
            ("Ctrl+O", self.import_music_files),
            ("Ctrl+Shift+O", self.import_music_folder),
            ("Ctrl+F", self.focus_search),
            ("Ctrl+L", self.clear_search),
            ("Ctrl+Space", self.toggle_play),
            ("Ctrl+Left", self.play_previous_song),
            ("Ctrl+Right", self.play_next_song),
            ("Ctrl+M", self.clean_missing_songs),
        ]

        for key_sequence, callback in shortcut_configs:
            shortcut = QShortcut(QKeySequence(key_sequence), self)
            shortcut.activated.connect(callback)
            self.shortcuts.append(shortcut)

        delete_shortcut = QShortcut(QKeySequence("Delete"), self.song_list)
        delete_shortcut.activated.connect(self.remove_selected_song)
        self.shortcuts.append(delete_shortcut)

    def focus_search(self) -> None:
        self.search_input.setFocus()
        self.search_input.selectAll()

    def _create_view_button(self, text: str, view_name: str) -> QPushButton:
        button = QPushButton(text)
        button.setObjectName("viewButton")
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setProperty("active", view_name == self.current_library_view)
        button.clicked.connect(lambda checked=False, view=view_name: self.set_library_view(view))

        self.view_buttons[view_name] = button
        return button

    def _create_browser_mode_button(self, text: str, mode: str) -> QPushButton:
        button = QPushButton(text)
        button.setObjectName("viewButton")
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setProperty("active", mode == self.library_browser_mode)
        button.clicked.connect(lambda checked=False, target_mode=mode: self.set_library_browser_mode(target_mode))

        self.browser_mode_buttons[mode] = button
        return button

    def set_library_view(self, view_name: str) -> None:
        if view_name not in {"all", "liked", "recent_played", "frequent", "recent_added"}:
            view_name = "all"

        self.current_library_view = view_name
        self.refresh_library_browser()
        self.update_view_buttons()

        view_titles = {
            "all": "鍏ㄩ儴姝屾洸",
            "liked": "鎴戝枩娆?,
            "recent_played": "鏈€杩戞挱鏀?,
            "frequent": "甯稿惉姝屾洸",
            "recent_added": "鏈€杩戞坊鍔?,
        }

        print("褰撳墠闊充箰搴撹鍥撅細", view_titles.get(view_name, "鍏ㄩ儴姝屾洸"))

    def set_library_browser_mode(self, mode: str) -> None:
        if mode not in {"songs", "artists", "albums"}:
            mode = "songs"

        self.library_browser_mode = mode
        self.active_artist_name = ""
        self.active_album_key = None
        self.refresh_library_browser()
        self.update_browser_mode_buttons()

    def update_browser_mode_buttons(self) -> None:
        if not hasattr(self, "browser_mode_buttons"):
            return

        for mode, button in self.browser_mode_buttons.items():
            button.setProperty("active", mode == self.library_browser_mode)
            button.style().unpolish(button)
            button.style().polish(button)
            button.update()

    def get_library_source_songs(self) -> list[dict]:
        songs = getattr(self, "library_songs", [])

        if songs:
            return [dict(song) for song in songs]

        return self.collect_song_data_from_list()

    def remove_song_from_library_source(self, song_path: str | None) -> None:
        normalized_path = self.normalize_song_path(song_path)

        if not normalized_path:
            return

        kept_songs = []

        for song_data in getattr(self, "library_songs", []):
            current_path = self.normalize_song_path(song_data.get("path", ""))

            if current_path != normalized_path:
                kept_songs.append(song_data)

        self.library_songs = kept_songs

    def remove_missing_songs_from_library_source(self) -> int:
        kept_songs = []
        removed_count = 0

        for song_data in getattr(self, "library_songs", []):
            if song_data.get("demo"):
                kept_songs.append(song_data)
                continue

            path_text = song_data.get("path", "")

            if path_text and Path(path_text).exists():
                kept_songs.append(song_data)
            else:
                removed_count += 1

        self.library_songs = kept_songs
        return removed_count

    def get_songs_for_current_view(self) -> list[dict]:
        songs = []

        for song_data in self.get_library_source_songs():
            if song_data.get("demo"):
                continue

            if self.song_matches_current_view(song_data):
                songs.append(dict(song_data))

        return songs

    def get_clean_artist_name(self, song_data: dict) -> str:
        artist = str(song_data.get("artist", "") or "").strip()
        return artist or "鏈煡鑹烘湳瀹?

    def get_clean_album_name(self, song_data: dict) -> str:
        album = str(song_data.get("album", "") or "").strip()
        return album or "鏈煡涓撹緫"

    def build_artist_groups(self) -> list[tuple[str, list[dict]]]:
        groups: dict[str, list[dict]] = {}

        for song_data in self.get_songs_for_current_view():
            artist = self.get_clean_artist_name(song_data)
            groups.setdefault(artist, []).append(song_data)

        return sorted(groups.items(), key=lambda item: item[0].lower())

    def build_album_groups(self) -> list[tuple[tuple[str, str], list[dict]]]:
        groups: dict[tuple[str, str], list[dict]] = {}

        for song_data in self.get_songs_for_current_view():
            album = self.get_clean_album_name(song_data)
            artist = self.get_clean_artist_name(song_data)
            key = (album, artist)
            groups.setdefault(key, []).append(song_data)

        return sorted(groups.items(), key=lambda item: (item[0][0].lower(), item[0][1].lower()))

    def create_category_item(self, title: str, subtitle: str, payload: dict) -> QListWidgetItem:
        item = QListWidgetItem(f"{title}    璺?   {subtitle}")
        item.setData(Qt.ItemDataRole.UserRole, payload)
        return item

    def refresh_library_browser(self) -> None:
        if not hasattr(self, "library_content_stack"):
            return

        if self.library_browser_mode == "artists":
            if self.active_artist_name:
                songs = [
                    song
                    for song in self.get_songs_for_current_view()
                    if self.get_clean_artist_name(song) == self.active_artist_name
                ]
                self.category_back_btn.show()
                self.category_title_label.setText(f"姝屾墜锛歿self.active_artist_name}")
                self.library_content_stack.setCurrentWidget(self.song_list)
                self.rebuild_song_list_from_data(songs)
            else:
                self.category_back_btn.hide()
                self.category_title_label.setText("鍙屽嚮姝屾墜鏌ョ湅姝屾洸")
                self.library_content_stack.setCurrentWidget(self.category_list)
                self.rebuild_artist_category_list()

            return

        if self.library_browser_mode == "albums":
            if self.active_album_key is not None:
                album_name, artist_name = self.active_album_key
                songs = [
                    song
                    for song in self.get_songs_for_current_view()
                    if (self.get_clean_album_name(song), self.get_clean_artist_name(song)) == self.active_album_key
                ]
                self.category_back_btn.show()
                self.category_title_label.setText(f"涓撹緫锛歿album_name} / {artist_name}")
                self.library_content_stack.setCurrentWidget(self.song_list)
                self.rebuild_song_list_from_data(songs)
            else:
                self.category_back_btn.hide()
                self.category_title_label.setText("鍙屽嚮涓撹緫鏌ョ湅姝屾洸")
                self.library_content_stack.setCurrentWidget(self.category_list)
                self.rebuild_album_category_list()

            return

        self.active_artist_name = ""
        self.active_album_key = None
        self.category_back_btn.hide()
        self.category_title_label.setText("")
        self.library_content_stack.setCurrentWidget(self.song_list)
        self.sort_song_list_for_current_view()

    def rebuild_artist_category_list(self) -> None:
        self.category_list.clear()

        for artist, songs in self.build_artist_groups():
            item = self.create_category_item(
                artist,
                f"{len(songs)} 棣栨瓕",
                {
                    "category_type": "artist",
                    "artist": artist,
                },
            )
            self.category_list.addItem(item)

        self.filter_song_list(self.search_input.text())

    def rebuild_album_category_list(self) -> None:
        self.category_list.clear()

        for (album, artist), songs in self.build_album_groups():
            item = self.create_category_item(
                album,
                f"{artist}    璺?   {len(songs)} 棣栨瓕",
                {
                    "category_type": "album",
                    "album": album,
                    "artist": artist,
                },
            )
            self.category_list.addItem(item)

        self.filter_song_list(self.search_input.text())

    def open_selected_category(self, item: QListWidgetItem | None) -> None:
        if item is None:
            return

        category_data = item.data(Qt.ItemDataRole.UserRole)

        if not isinstance(category_data, dict):
            return

        if category_data.get("category_type") == "artist":
            self.active_artist_name = str(category_data.get("artist", ""))
            self.refresh_library_browser()
        elif category_data.get("category_type") == "album":
            album = str(category_data.get("album", ""))
            artist = str(category_data.get("artist", ""))
            self.active_album_key = (album, artist)
            self.refresh_library_browser()

    def show_category_overview(self) -> None:
        self.active_artist_name = ""
        self.active_album_key = None
        self.refresh_library_browser()

    def update_view_buttons(self) -> None:
        if not hasattr(self, "view_buttons"):
            return

        for view_name, button in self.view_buttons.items():
            button.setProperty("active", view_name == self.current_library_view)
            button.style().unpolish(button)
            button.style().polish(button)
            button.update()

    def song_matches_current_view(self, song_data: dict) -> bool:
        if not isinstance(song_data, dict):
            return True

        if song_data.get("demo"):
            return self.current_library_view == "all"

        path = song_data.get("path", "")
        normalized_path = self.normalize_song_path(path)

        if self.current_library_view == "all":
            return True

        if self.current_library_view == "liked":
            return self.is_song_liked(normalized_path)

        if self.current_library_view == "recent_played":
            stats = self.song_stats.get(normalized_path, {})
            return int(stats.get("last_played", 0)) > 0

        if self.current_library_view == "frequent":
            stats = self.song_stats.get(normalized_path, {})
            play_count = int(stats.get("play_count", 0))
            total_listen_time = int(stats.get("total_listen_time", 0))
            return play_count > 0 or total_listen_time > 0

        if self.current_library_view == "recent_added":
            return bool(normalized_path)

        return True

    def collect_song_data_from_list(self) -> list[dict]:
        songs = []

        for row in range(self.song_list.count()):
            item = self.song_list.item(row)

            if not item:
                continue

            song_data = item.data(Qt.ItemDataRole.UserRole)

            if isinstance(song_data, dict):
                songs.append(dict(song_data))

        return songs

    def create_song_list_item(self, song_data: dict) -> QListWidgetItem:
        title = song_data.get("title", "鏈煡姝屾洸")
        artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
        album = song_data.get("album", "鏈煡涓撹緫")

        item = QListWidgetItem(f"{title}    路    {artist}    路    {album}")
        item.setData(Qt.ItemDataRole.UserRole, song_data)
        return item

    def rebuild_song_list_from_data(self, songs: list[dict]) -> None:
        current_path = self.normalize_song_path(self.current_song_path)
        selected_row = -1

        self.song_list.clear()

        for row, song_data in enumerate(songs):
            item = self.create_song_list_item(song_data)
            self.song_list.addItem(item)

            song_path = self.normalize_song_path(song_data.get("path", ""))

            if current_path and song_path == current_path:
                selected_row = row

        self.filter_song_list(self.search_input.text())

        if selected_row >= 0:
            self.song_list.setCurrentRow(selected_row)

    def sort_song_list_for_current_view(self) -> None:
        songs = self.get_library_source_songs()

        if not songs:
            return

        def normalized_path(song_data: dict) -> str:
            return self.normalize_song_path(song_data.get("path", ""))

        def stats_for(song_data: dict) -> dict:
            return self.song_stats.get(
                normalized_path(song_data),
                {
                    "play_count": 0,
                    "total_listen_time": 0,
                    "last_played": 0,
                },
            )

        if self.current_library_view == "recent_played":
            songs.sort(
                key=lambda song: int(stats_for(song).get("last_played", 0)),
                reverse=True,
            )

        elif self.current_library_view == "frequent":
            songs.sort(
                key=lambda song: (
                    int(stats_for(song).get("play_count", 0)),
                    int(stats_for(song).get("total_listen_time", 0)),
                    int(stats_for(song).get("last_played", 0)),
                ),
                reverse=True,
            )

        elif self.current_library_view == "recent_added":
            songs.sort(
                key=lambda song: int(song.get("added_at", 0) or 0),
                reverse=True,
            )

        else:
            songs.sort(
                key=lambda song: int(song.get("added_at", 0) or 0),
            )

        self.rebuild_song_list_from_data(songs)

    def _create_view_button(self, text: str, view_name: str) -> QPushButton:
        button = QPushButton(text)
        button.setObjectName("viewButton")
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setProperty("active", view_name == self.current_library_view)
        button.clicked.connect(lambda checked=False, view=view_name: self.set_library_view(view))

        self.view_buttons[view_name] = button
        return button

    def get_playlist_name(self, playlist_id: str) -> str:
        playlist = self.playlists.get(playlist_id, {})

        if not isinstance(playlist, dict):
            return "鏈懡鍚嶆瓕鍗?

        name = str(playlist.get("name", "")).strip()
        return name or "鏈懡鍚嶆瓕鍗?

    def get_playlist_song_paths(self, playlist_id: str) -> list[str]:
        if playlist_id not in self.playlists or not isinstance(self.playlists.get(playlist_id), dict):
            self.playlists[playlist_id] = {
                "name": "鏈懡鍚嶆瓕鍗?,
                "songs": [],
                "fixed": False,
            }

        playlist = self.playlists[playlist_id]
        songs = playlist.setdefault("songs", [])

        if not isinstance(songs, list):
            playlist["songs"] = []
            songs = playlist["songs"]

        normalized_songs = []

        for path in songs:
            normalized_path = self.normalize_song_path(str(path))

            if normalized_path and normalized_path not in normalized_songs:
                normalized_songs.append(normalized_path)

        playlist["songs"] = normalized_songs
        return playlist["songs"]

    def get_custom_playlist_ids(self) -> list[str]:
        playlist_ids = []

        for playlist_id, playlist in self.playlists.items():
            if playlist_id == "liked":
                continue

            if not isinstance(playlist, dict):
                continue

            playlist_ids.append(playlist_id)

        playlist_ids.sort(
            key=lambda playlist_id: int(
                self.playlists.get(playlist_id, {}).get("created_at", 0) or 0
            )
        )

        return playlist_ids

    def create_playlist_id(self) -> str:
        base_id = f"playlist_{int(time.time() * 1000)}"
        playlist_id = base_id
        index = 1

        while playlist_id in self.playlists:
            playlist_id = f"{base_id}_{index}"
            index += 1

        return playlist_id

    def refresh_playlist_view_buttons(self) -> None:
        if not hasattr(self, "sidebar_playlist_layout"):
            return

        for button in getattr(self, "custom_view_buttons", []):
            self.sidebar_playlist_layout.removeWidget(button)
            button.deleteLater()

        self.custom_view_buttons = []

        for view_name in list(self.view_buttons.keys()):
            if view_name.startswith("playlist:"):
                self.view_buttons.pop(view_name, None)

        for playlist_id in self.get_custom_playlist_ids():
            playlist_name = self.get_playlist_name(playlist_id)
            view_name = f"playlist:{playlist_id}"

            button = QPushButton(playlist_name)
            button.setObjectName("playlistSidebarButton")
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setProperty("active", view_name == self.current_library_view)
            button.clicked.connect(lambda checked=False, view=view_name: self.set_library_view(view))

            self.sidebar_playlist_layout.addWidget(button)
            self.custom_view_buttons.append(button)
            self.view_buttons[view_name] = button

        self.update_view_buttons()

    def set_library_view(self, view_name: str) -> None:
        fixed_views = {"all", "liked", "recent_played", "frequent", "recent_added"}

        if view_name in fixed_views:
            self.current_library_view = view_name
        elif view_name.startswith("playlist:"):
            playlist_id = view_name.split("playlist:", 1)[1]

            if playlist_id in self.playlists:
                self.current_library_view = view_name
            else:
                self.current_library_view = "all"
        else:
            self.current_library_view = "all"

        self.refresh_library_browser()
        self.update_view_buttons()

        view_titles = {
            "all": "鍏ㄩ儴姝屾洸",
            "liked": "鎴戝枩娆?,
            "recent_played": "鏈€杩戞挱鏀?,
            "frequent": "甯稿惉姝屾洸",
            "recent_added": "鏈€杩戞坊鍔?,
        }

        if self.current_library_view.startswith("playlist:"):
            playlist_id = self.current_library_view.split("playlist:", 1)[1]
            view_title = self.get_playlist_name(playlist_id)
        else:
            view_title = view_titles.get(self.current_library_view, "鍏ㄩ儴姝屾洸")

        print("褰撳墠闊充箰搴撹鍥撅細", view_title)

    def update_view_buttons(self) -> None:
        if not hasattr(self, "view_buttons"):
            return

        for view_name, button in self.view_buttons.items():
            button.setProperty("active", view_name == self.current_library_view)
            button.style().unpolish(button)
            button.style().polish(button)
            button.update()

    def song_matches_current_view(self, song_data: dict) -> bool:
        if not isinstance(song_data, dict):
            return True

        if song_data.get("demo"):
            return self.current_library_view == "all"

        path = song_data.get("path", "")
        normalized_path = self.normalize_song_path(path)

        if self.current_library_view == "all":
            return True

        if self.current_library_view == "liked":
            return self.is_song_liked(normalized_path)

        if self.current_library_view == "recent_played":
            stats = self.song_stats.get(normalized_path, {})
            return int(stats.get("last_played", 0)) > 0

        if self.current_library_view == "frequent":
            stats = self.song_stats.get(normalized_path, {})
            play_count = int(stats.get("play_count", 0))
            total_listen_time = int(stats.get("total_listen_time", 0))
            return play_count > 0 or total_listen_time > 0

        if self.current_library_view == "recent_added":
            return bool(normalized_path)

        if self.current_library_view.startswith("playlist:"):
            playlist_id = self.current_library_view.split("playlist:", 1)[1]
            playlist_songs = self.get_playlist_song_paths(playlist_id)
            return normalized_path in playlist_songs

        return True

    def collect_song_data_from_list(self) -> list[dict]:
        songs = []

        for row in range(self.song_list.count()):
            item = self.song_list.item(row)

            if not item:
                continue

            song_data = item.data(Qt.ItemDataRole.UserRole)

            if isinstance(song_data, dict):
                songs.append(dict(song_data))

        return songs

    def create_song_list_item(self, song_data: dict) -> QListWidgetItem:
        title = song_data.get("title", "鏈煡姝屾洸")
        artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
        album = song_data.get("album", "鏈煡涓撹緫")

        item = QListWidgetItem(f"{title}    路    {artist}    路    {album}")
        item.setData(Qt.ItemDataRole.UserRole, song_data)
        return item

    def rebuild_song_list_from_data(self, songs: list[dict]) -> None:
        current_path = self.normalize_song_path(self.current_song_path)
        selected_row = -1

        self.song_list.clear()

        for row, song_data in enumerate(songs):
            item = self.create_song_list_item(song_data)
            self.song_list.addItem(item)

            song_path = self.normalize_song_path(song_data.get("path", ""))

            if current_path and song_path == current_path:
                selected_row = row

        self.filter_song_list(self.search_input.text())

        if selected_row >= 0:
            self.song_list.setCurrentRow(selected_row)

    def sort_song_list_for_current_view(self) -> None:
        songs = self.get_library_source_songs()

        if not songs:
            return

        def normalized_path(song_data: dict) -> str:
            return self.normalize_song_path(song_data.get("path", ""))

        def stats_for(song_data: dict) -> dict:
            return self.song_stats.get(
                normalized_path(song_data),
                {
                    "play_count": 0,
                    "total_listen_time": 0,
                    "last_played": 0,
                },
            )

        if self.current_library_view == "recent_played":
            songs.sort(
                key=lambda song: int(stats_for(song).get("last_played", 0)),
                reverse=True,
            )

        elif self.current_library_view == "frequent":
            songs.sort(
                key=lambda song: (
                    int(stats_for(song).get("play_count", 0)),
                    int(stats_for(song).get("total_listen_time", 0)),
                    int(stats_for(song).get("last_played", 0)),
                ),
                reverse=True,
            )

        elif self.current_library_view == "recent_added":
            songs.sort(
                key=lambda song: int(song.get("added_at", 0) or 0),
                reverse=True,
            )

        elif self.current_library_view.startswith("playlist:"):
            playlist_id = self.current_library_view.split("playlist:", 1)[1]
            playlist_songs = self.get_playlist_song_paths(playlist_id)
            playlist_order = {
                path: index
                for index, path in enumerate(playlist_songs)
            }

            songs.sort(
                key=lambda song: playlist_order.get(normalized_path(song), 999999),
            )

        else:
            songs.sort(
                key=lambda song: int(song.get("added_at", 0) or 0),
            )

        self.rebuild_song_list_from_data(songs)

    def create_new_playlist(self) -> None:
        name, ok = QInputDialog.getText(
            self,
            "鏂板缓姝屽崟",
            "杈撳叆姝屽崟鍚嶇О锛?,
        )

        if not ok:
            return

        name = name.strip()

        if not name:
            return

        playlist_id = self.create_playlist_id()

        self.playlists[playlist_id] = {
            "name": name,
            "songs": [],
            "fixed": False,
            "created_at": int(time.time()),
        }

        self.save_playlists()
        self.refresh_playlist_view_buttons()
        self.set_library_view(f"playlist:{playlist_id}")

        print("宸叉柊寤烘瓕鍗曪細", name)

    def rename_current_playlist(self) -> None:
        if not self.current_library_view.startswith("playlist:"):
            QMessageBox.information(self, "鎻愮ず", "璇峰厛鍒囨崲鍒颁竴涓嚜瀹氫箟姝屽崟銆?)
            return

        playlist_id = self.current_library_view.split("playlist:", 1)[1]

        if playlist_id not in self.playlists:
            return

        old_name = self.get_playlist_name(playlist_id)

        new_name, ok = QInputDialog.getText(
            self,
            "閲嶅懡鍚嶆瓕鍗?,
            "杈撳叆鏂扮殑姝屽崟鍚嶇О锛?,
            text=old_name,
        )

        if not ok:
            return

        new_name = new_name.strip()

        if not new_name:
            return

        self.playlists[playlist_id]["name"] = new_name
        self.save_playlists()
        self.refresh_playlist_view_buttons()
        self.update_view_buttons()

        print(f"姝屽崟宸查噸鍛藉悕锛歿old_name} -> {new_name}")

    def delete_current_playlist(self) -> None:
        if not self.current_library_view.startswith("playlist:"):
            QMessageBox.information(self, "鎻愮ず", "璇峰厛鍒囨崲鍒颁竴涓嚜瀹氫箟姝屽崟銆?)
            return

        playlist_id = self.current_library_view.split("playlist:", 1)[1]

        if playlist_id not in self.playlists:
            return

        playlist_name = self.get_playlist_name(playlist_id)

        result = QMessageBox.question(
            self,
            "鍒犻櫎姝屽崟",
            f"纭畾鍒犻櫎姝屽崟銆寋playlist_name}銆嶅悧锛焅\n杩欎笉浼氬垹闄ょ湡瀹為煶涔愭枃浠躲€?,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )

        if result != QMessageBox.StandardButton.Yes:
            return

        self.playlists.pop(playlist_id, None)
        self.current_library_view = "all"

        self.save_playlists()
        self.refresh_playlist_view_buttons()
        self.set_library_view("all")

        print("宸插垹闄ゆ瓕鍗曪細", playlist_name)

    def get_current_selected_song_path(self) -> str:
        item = self.song_list.currentItem()

        if not item:
            return self.normalize_song_path(self.current_song_path)

        song_data = item.data(Qt.ItemDataRole.UserRole)

        if not isinstance(song_data, dict):
            return self.normalize_song_path(self.current_song_path)

        return self.normalize_song_path(song_data.get("path", ""))

    def add_current_song_to_playlist(self) -> None:
        song_path = self.get_current_selected_song_path()

        if not song_path:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        custom_playlist_ids = self.get_custom_playlist_ids()

        if not custom_playlist_ids:
            result = QMessageBox.question(
                self,
                "杩樻病鏈夋瓕鍗?,
                "浣犺繕娌℃湁鑷畾涔夋瓕鍗曪紝瑕佺幇鍦ㄦ柊寤轰竴涓悧锛?,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )

            if result == QMessageBox.StandardButton.Yes:
                self.create_new_playlist()

            return

        choices = []
        choice_to_id = {}

        for playlist_id in custom_playlist_ids:
            name = self.get_playlist_name(playlist_id)
            choices.append(name)
            choice_to_id[name] = playlist_id

        selected_name, ok = QInputDialog.getItem(
            self,
            "娣诲姞鍒版瓕鍗?,
            "閫夋嫨瑕佸姞鍏ョ殑姝屽崟锛?,
            choices,
            0,
            False,
        )

        if not ok:
            return

        playlist_id = choice_to_id.get(selected_name)

        if not playlist_id:
            return

        playlist_songs = self.get_playlist_song_paths(playlist_id)

        if song_path not in playlist_songs:
            playlist_songs.append(song_path)

        self.save_playlists()

        if self.current_library_view == f"playlist:{playlist_id}":
            self.filter_song_list(self.search_input.text())

        print(f"宸叉坊鍔犲埌姝屽崟銆寋selected_name}銆嶏細", song_path)

    def remove_current_song_from_current_playlist(self) -> None:
        song_path = self.get_current_selected_song_path()

        if not song_path:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        if self.current_library_view == "liked":
            liked_songs = self.get_liked_song_paths()

            if song_path in liked_songs:
                liked_songs.remove(song_path)
                self.save_playlists()
                self.update_like_button()
                self.update_side_info_panel()
                self.filter_song_list(self.search_input.text())

            return

        if not self.current_library_view.startswith("playlist:"):
            QMessageBox.information(self, "鎻愮ず", "璇峰厛鍒囨崲鍒版煇涓瓕鍗曡鍥俱€?)
            return

        playlist_id = self.current_library_view.split("playlist:", 1)[1]
        playlist_songs = self.get_playlist_song_paths(playlist_id)

        if song_path in playlist_songs:
            playlist_songs.remove(song_path)
            self.save_playlists()
            self.filter_song_list(self.search_input.text())

            print("宸蹭粠褰撳墠姝屽崟绉婚櫎锛?, song_path)

    def _create_side_info_row(self, name: str, value_widget: QWidget) -> QFrame:
        row = QFrame()
        row.setObjectName("sideInfoRow")

        layout = QVBoxLayout(row)
        layout.setContentsMargins(12, 9, 12, 9)
        layout.setSpacing(4)

        name_label = QLabel(name)
        name_label.setObjectName("sideInfoName")

        value_widget.setObjectName("sideInfoValue")

        layout.addWidget(name_label)
        layout.addWidget(value_widget)

        return row

    def set_right_panel_mode(self, mode: str) -> None:
        if not hasattr(self, "lyrics_view"):
            return

        if hasattr(self, "side_info_panel"):
            self.side_info_panel.hide()

        self.lyrics_view.show()

        lyrics_content = self.lyrics_view.widget()

        if mode == "info":
            if lyrics_content:
                lyrics_content.hide()

            self.lyrics_view.setEnabled(False)
            self.lyrics_view.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        else:
            if lyrics_content:
                lyrics_content.show()

            self.lyrics_view.setEnabled(True)
            self.lyrics_view.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def format_last_played_text(self, timestamp: int) -> str:
        timestamp = int(timestamp or 0)

        if timestamp <= 0:
            return "杩樻病鏈夋挱鏀捐褰?

        try:
            return time.strftime("%Y-%m-%d %H:%M", time.localtime(timestamp))
        except Exception:
            return "鏈煡鏃堕棿"

    def get_current_info_song_data(self) -> dict | None:
        if isinstance(getattr(self, "browsing_song_data", None), dict):
            return self.browsing_song_data

        current_item = self.song_list.currentItem()

        if current_item:
            song_data = current_item.data(Qt.ItemDataRole.UserRole)

            if isinstance(song_data, dict) and not song_data.get("demo"):
                return song_data

        if self.current_song_path:
            return self.find_song_data_by_path(self.current_song_path)

        return None

    def update_side_info_panel(self) -> None:
        if not hasattr(self, "side_info_panel"):
            return

        song_data = self.get_current_info_song_data()

        if not song_data:
            self.side_artist_detail.setText("鏈煡鑹烘湳瀹?)
            self.side_album_detail.setText("鏈煡涓撹緫")
            self.side_like_detail.setText("鏈敹钘?)
            self.side_play_count_detail.setText("0 娆?)
            self.side_listen_time_detail.setText("0:00")
            self.side_last_played_detail.setText("杩樻病鏈夋挱鏀捐褰?)
            self.side_lyrics_status_value.setText("绛夊緟閫夋嫨姝屾洸")
            self.side_file_detail.setText("")
            return

        artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
        album = song_data.get("album", "鏈煡涓撹緫")
        song_path = self.normalize_song_path(song_data.get("path", ""))

        stats = self.song_stats.get(
            song_path,
            {
                "play_count": 0,
                "total_listen_time": 0,
                "last_played": 0,
            },
        )

        play_count = int(stats.get("play_count", 0))
        total_listen_time = int(stats.get("total_listen_time", 0))
        last_played = int(stats.get("last_played", 0))

        if hasattr(self, "lyrics_status_label"):
            lyrics_status = self.lyrics_status_label.text().replace("姝岃瘝锛?, "").strip()
        else:
            lyrics_status = "鏈煡"

        self.side_artist_detail.setText(str(artist))
        self.side_album_detail.setText(str(album))
        self.side_like_detail.setText("宸叉敹钘? if self.is_song_liked(song_path) else "鏈敹钘?)
        self.side_play_count_detail.setText(f"{play_count} 娆?)
        self.side_listen_time_detail.setText(self.format_listen_time(total_listen_time))
        self.side_last_played_detail.setText(self.format_last_played_text(last_played))
        self.side_lyrics_status_value.setText(lyrics_status or "鏈煡")
        self.side_file_detail.setText(song_path)

    def open_immersive_lyrics_window(self) -> None:
        if self.immersive_lyrics_window is None:
            self.immersive_lyrics_window = ImmersiveLyricsWindow(self)

        self.sync_immersive_lyrics()
        self.immersive_lyrics_window.show_on_best_screen()

    def get_playing_song_display_data(self) -> tuple[str, str, str]:
        playing_path = self.normalize_song_path(self.current_song_path)

        if not playing_path:
            return "杩樻病鏈夋挱鏀鹃煶涔?, "鍙屽嚮姝屾洸鎴栧彸閿挱鏀惧悗鎵撳紑娌夋蹈姝岃瘝", "绛夊緟鎾斁姝屾洸"

        song_data = self.find_song_data_by_path(playing_path)

        if song_data:
            title = song_data.get("title", "鏈煡姝屾洸")
            artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
            album = song_data.get("album", "鏈煡涓撹緫")
        else:
            title = Path(playing_path).stem
            artist = "鏈煡鑹烘湳瀹?
            album = "鏈煡涓撹緫"

        if hasattr(self, "lyrics_status_label"):
            status = self.lyrics_status_label.text().replace("姝岃瘝锛?, "").strip()
        else:
            status = "姝岃瘝鐘舵€佹湭鐭?

        return str(title), f"{artist} 路 {album}", status or "姝岃瘝鐘舵€佹湭鐭?

    def get_immersive_background_pixmap(self, playing_path: str | None):
        normalized_path = self.normalize_song_path(playing_path)

        if not normalized_path:
            return None

        try:
            browsing_path = self.normalize_song_path(getattr(self, "browsing_song_path", ""))

            if browsing_path == normalized_path and hasattr(self, "cover_label"):
                current_pixmap = self.cover_label.pixmap()

                if current_pixmap and not current_pixmap.isNull():
                    return current_pixmap
        except Exception:
            pass

        try:
            cache_path = self.get_song_cache_path(normalized_path, self.cover_cache_dir, ".jpg")

            if cache_path and cache_path.exists():
                cached_pixmap = QPixmap(str(cache_path))

                if not cached_pixmap.isNull():
                    return cached_pixmap
        except Exception as error:
            print("璇诲彇娌夋蹈灏侀潰缂撳瓨澶辫触锛?, error)

        try:
            song_dir = Path(normalized_path).parent
            cover_names = [
                "cover.jpg",
                "cover.png",
                "cover.jpeg",
                "folder.jpg",
                "folder.png",
                "folder.jpeg",
                "front.jpg",
                "front.png",
                "front.jpeg",
                "album.jpg",
                "album.png",
                "album.jpeg",
            ]

            for cover_name in cover_names:
                cover_path = song_dir / cover_name

                if not cover_path.exists():
                    continue

                folder_pixmap = QPixmap(str(cover_path))

                if not folder_pixmap.isNull():
                    return folder_pixmap
        except Exception as error:
            print("璇诲彇娌夋蹈鏂囦欢澶瑰皝闈㈠け璐ワ細", error)

        return None

    def sync_immersive_lyrics(self) -> None:
        if self.immersive_lyrics_window is None:
            return

        title, artist_album, status = self.get_playing_song_display_data()
        self.immersive_lyrics_window.update_song_info(title, artist_album, status)

        playing_path = self.normalize_song_path(self.current_song_path)
        background_pixmap = self.get_immersive_background_pixmap(playing_path)
        self.immersive_lyrics_window.update_background_cover(background_pixmap)

        displayed_path = self.normalize_song_path(getattr(self, "displayed_lyrics_song_path", ""))

        if playing_path and displayed_path == playing_path and self.current_lyrics:
            self.immersive_lyrics_window.set_lyrics(self.current_lyrics)
            self.immersive_lyrics_window.update_position(
                self.media_player.position(),
                self.current_lyrics,
            )
        else:
            self.immersive_lyrics_window.set_lyrics([])

    def _create_full_lyrics_page(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("fullLyricsPage")

        layout = QVBoxLayout(panel)
        layout.setContentsMargins(44, 34, 44, 34)
        layout.setSpacing(18)

        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(18)

        title_box = QVBoxLayout()
        title_box.setContentsMargins(0, 0, 0, 0)
        title_box.setSpacing(7)

        page_title = QLabel("姝岃瘝")
        page_title.setObjectName("fullLyricsPageTitle")

        page_subtitle = QLabel("杩欓噷鏄剧ず姝ｅ湪鎾斁姝屾洸鐨勬瓕璇嶃€傚崟鍑婚煶涔愬簱閲岀殑鍏朵粬姝屼笉浼氬奖鍝嶈繖涓〉闈€?)
        page_subtitle.setObjectName("fullLyricsPageSubtitle")

        self.full_lyrics_title = ElidedLabel("杩樻病鏈夋挱鏀鹃煶涔?)
        self.full_lyrics_title.setObjectName("fullLyricsSongTitle")
        self.full_lyrics_title.setMinimumWidth(360)

        self.full_lyrics_artist = ElidedLabel("鍙屽嚮姝屾洸鎴栧彸閿挱鏀惧悗锛岃繖閲屼細鏄剧ず姝ｅ湪鎾斁鐨勬瓕璇?)
        self.full_lyrics_artist.setObjectName("fullLyricsArtist")
        self.full_lyrics_artist.setMinimumWidth(360)

        self.full_lyrics_status = QLabel("绛夊緟鎾斁姝屾洸")
        self.full_lyrics_status.setObjectName("fullLyricsStatus")
        self.full_lyrics_status.setAlignment(Qt.AlignmentFlag.AlignLeft)

        title_box.addWidget(page_title)
        title_box.addWidget(page_subtitle)
        title_box.addSpacing(8)
        title_box.addWidget(self.full_lyrics_title)
        title_box.addWidget(self.full_lyrics_artist)
        title_box.addWidget(self.full_lyrics_status)

        immersive_btn = QPushButton("鎵撳紑娌夋蹈姝岃瘝")
        immersive_btn.setObjectName("primaryButton")
        immersive_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        immersive_btn.clicked.connect(self.open_immersive_lyrics_window)

        back_btn = QPushButton("杩斿洖闊充箰搴?)
        back_btn.setObjectName("secondaryButton")
        back_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        back_btn.clicked.connect(self.show_library_page)

        button_box = QVBoxLayout()
        button_box.setContentsMargins(0, 0, 0, 0)
        button_box.setSpacing(10)
        button_box.addWidget(immersive_btn)
        button_box.addWidget(back_btn)

        header_layout.addLayout(title_box, 1)
        header_layout.addLayout(button_box)

        self.full_lyrics_view = LyricsView()
        self.full_lyrics_view.set_placeholder(
            "杩樻病鏈夋鍦ㄦ挱鏀剧殑姝岃瘝",
            "鍙屽嚮涓€棣栨瓕鎾斁锛岀劧鍚庣偣鍑诲乏渚р€滄瓕璇嶁€濇煡鐪嬪ぇ姝岃瘝椤甸潰",
        )

        layout.addLayout(header_layout)
        layout.addWidget(self.full_lyrics_view, 1)

        return panel

    def show_library_page(self) -> None:
        if hasattr(self, "content_stack"):
            self.content_stack.setCurrentIndex(0)

        self.set_right_panel_mode("lyrics")

    def show_liked_playlist_page(self) -> None:
        self.show_library_page()
        self.set_library_view("liked")

    def show_full_lyrics_page(self) -> None:
        if hasattr(self, "content_stack"):
            self.content_stack.setCurrentIndex(1)

        self.set_right_panel_mode("info")
        self.refresh_full_lyrics_page()

    def find_song_data_by_path(self, song_path: str | None) -> dict | None:
        normalized_path = self.normalize_song_path(song_path)

        if not normalized_path:
            return None

        for row in range(self.song_list.count()):
            item = self.song_list.item(row)

            if not item:
                continue

            song_data = item.data(Qt.ItemDataRole.UserRole)

            if not isinstance(song_data, dict):
                continue

            item_path = self.normalize_song_path(song_data.get("path", ""))

            if item_path == normalized_path:
                return song_data

        return None

    def refresh_full_lyrics_page(self) -> None:
        if not hasattr(self, "full_lyrics_view"):
            return

        playing_path = self.normalize_song_path(self.current_song_path)

        if not playing_path:
            self.full_lyrics_title.setText("杩樻病鏈夋挱鏀鹃煶涔?)
            self.full_lyrics_artist.setText("鍙屽嚮姝屾洸鎴栧彸閿挱鏀惧悗锛岃繖閲屼細鏄剧ず姝ｅ湪鎾斁鐨勬瓕璇?)
            self.full_lyrics_status.setText("绛夊緟鎾斁姝屾洸")
            self.full_lyrics_view.set_placeholder(
                "杩樻病鏈夋鍦ㄦ挱鏀剧殑姝岃瘝",
                "鍙屽嚮涓€棣栨瓕鎾斁锛岀劧鍚庣偣鍑诲乏渚р€滄瓕璇嶁€濇煡鐪嬪ぇ姝岃瘝椤甸潰",
            )
            return

        song_data = self.find_song_data_by_path(playing_path)

        if song_data:
            title = song_data.get("title", "鏈煡姝屾洸")
            artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
            album = song_data.get("album", "鏈煡涓撹緫")
        else:
            title = Path(playing_path).stem
            artist = "鏈煡鑹烘湳瀹?
            album = "鏈煡涓撹緫"

        self.full_lyrics_title.setText(title)
        self.full_lyrics_artist.setText(f"{artist} 路 {album}")

        displayed_path = self.normalize_song_path(getattr(self, "displayed_lyrics_song_path", ""))

        if displayed_path == playing_path and self.current_lyrics:
            self.sync_full_lyrics_from_current()
            return

        self.full_lyrics_status.setText("姝ｅ湪鍔犺浇姝ｅ湪鎾斁姝屾洸鐨勬瓕璇?)
        self.full_lyrics_view.set_placeholder(
            "姝ｅ湪鍔犺浇姝岃瘝",
            "浼樺厛鎵嬪姩缁戝畾姝岃瘝銆佹湰鍦版瓕璇嶏紝鍏舵缂撳瓨鍜岃仈缃戞瓕璇?,
        )

        self.load_lyrics_for_song(
            file_path=playing_path,
            title=title,
            artist=artist,
        )

    def sync_full_lyrics_from_current(self) -> None:
        if not hasattr(self, "full_lyrics_view"):
            return

        playing_path = self.normalize_song_path(self.current_song_path)
        displayed_path = self.normalize_song_path(getattr(self, "displayed_lyrics_song_path", ""))

        if not playing_path:
            return

        if displayed_path != playing_path:
            return

        song_data = self.find_song_data_by_path(playing_path)

        if song_data:
            title = song_data.get("title", "鏈煡姝屾洸")
            artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
            album = song_data.get("album", "鏈煡涓撹緫")
            self.full_lyrics_title.setText(title)
            self.full_lyrics_artist.setText(f"{artist} 路 {album}")

        if self.current_lyrics:
            self.full_lyrics_view.set_lyrics(self.current_lyrics)
            self.full_lyrics_view.update_by_position(
                self.media_player.position(),
                self.current_lyrics,
            )
            self.full_lyrics_status.setText("姝ｅ湪鏄剧ず鎾斁涓殑姝岃瘝")
            self.sync_immersive_lyrics()
        else:
            self.full_lyrics_view.set_placeholder(
                "褰撳墠姝屾洸鏆傛棤姝岃瘝",
                "鍙互鍙抽敭姝屾洸鎵嬪姩缁戝畾姝岃瘝锛屾垨鑰呴噸鏂版悳绱㈡瓕璇?,
            )
            self.full_lyrics_status.setText("褰撳墠姝屾洸鏆傛棤姝岃瘝")
            self.sync_immersive_lyrics()

    def _create_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(250)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(18, 22, 18, 18)
        layout.setSpacing(10)

        title = QLabel("HushPlayer")
        title.setObjectName("appTitle")

        subtitle = QLabel("Local Music Player")
        subtitle.setObjectName("appSubtitle")

        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(22)

        music_library_btn = NavButton("闊充箰搴?, active=True)
        music_library_btn.clicked.connect(self.show_library_page)

        playlist_nav_btn = NavButton("鎾斁鍒楄〃")
        playlist_nav_btn.clicked.connect(self.show_liked_playlist_page)

        lyrics_nav_btn = NavButton("姝岃瘝")
        lyrics_nav_btn.clicked.connect(self.show_full_lyrics_page)

        settings_nav_btn = NavButton("璁剧疆")

        layout.addWidget(music_library_btn)
        layout.addWidget(playlist_nav_btn)
        layout.addWidget(lyrics_nav_btn)

        layout.addSpacing(12)

        playlist_title = QLabel("姝屽崟")
        playlist_title.setObjectName("sidebarSectionTitle")
        layout.addWidget(playlist_title)

        liked_btn = QPushButton("鈾?鎴戝枩娆?)
        liked_btn.setObjectName("playlistSidebarButton")
        liked_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        liked_btn.setProperty("active", self.current_library_view == "liked")
        liked_btn.clicked.connect(self.show_liked_playlist_page)

        self.view_buttons["liked"] = liked_btn
        layout.addWidget(liked_btn)

        self.sidebar_playlist_box = QFrame()
        self.sidebar_playlist_box.setObjectName("sidebarPlaylistBox")

        self.sidebar_playlist_layout = QVBoxLayout(self.sidebar_playlist_box)
        self.sidebar_playlist_layout.setContentsMargins(0, 0, 0, 0)
        self.sidebar_playlist_layout.setSpacing(7)

        layout.addWidget(self.sidebar_playlist_box)

        self.refresh_playlist_view_buttons()

        layout.addSpacing(8)

        new_playlist_btn = QPushButton("+ 鏂板缓姝屽崟")
        new_playlist_btn.setObjectName("sidebarWideButton")
        new_playlist_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        new_playlist_btn.clicked.connect(self.create_new_playlist)

        edit_row = QHBoxLayout()
        edit_row.setContentsMargins(0, 0, 0, 0)
        edit_row.setSpacing(8)

        rename_playlist_btn = QPushButton("閲嶅懡鍚?)
        rename_playlist_btn.setObjectName("sidebarMiniButton")
        rename_playlist_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        rename_playlist_btn.clicked.connect(self.rename_current_playlist)

        delete_playlist_btn = QPushButton("鍒犻櫎")
        delete_playlist_btn.setObjectName("sidebarMiniButton")
        delete_playlist_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        delete_playlist_btn.clicked.connect(self.delete_current_playlist)

        edit_row.addWidget(rename_playlist_btn)
        edit_row.addWidget(delete_playlist_btn)

        layout.addWidget(new_playlist_btn)
        layout.addLayout(edit_row)

        help_text = QLabel("鍙抽敭姝屾洸鍙坊鍔犲埌姝屽崟銆佺粦瀹氭瓕璇嶆垨閲嶆柊鎼滅储灏侀潰")
        help_text.setObjectName("sidebarHint")
        help_text.setWordWrap(True)
        layout.addWidget(help_text)

        layout.addStretch()
        layout.addWidget(settings_nav_btn)

        return sidebar

    def _create_library_panel(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("libraryPanel")
        panel.setAcceptDrops(True)

        layout = QVBoxLayout(panel)
        layout.setContentsMargins(28, 26, 28, 24)
        layout.setSpacing(16)

        header_layout = QHBoxLayout()

        title_box = QVBoxLayout()

        page_title = QLabel("闊充箰搴?)
        page_title.setObjectName("pageTitle")

        page_subtitle = QLabel("鍙互瀵煎叆銆佹悳绱紝涔熷彲浠ョ洿鎺ユ嫋鎷介煶涔愭枃浠舵垨鏂囦欢澶瑰埌绐楀彛銆?)
        page_subtitle.setObjectName("pageSubtitle")

        title_box.addWidget(page_title)
        title_box.addWidget(page_subtitle)

        import_btn = QPushButton("瀵煎叆闊充箰")
        import_btn.setObjectName("primaryButton")
        import_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        import_btn.clicked.connect(self.import_music_files)

        import_folder_btn = QPushButton("瀵煎叆鏂囦欢澶?)
        import_folder_btn.setObjectName("secondaryButton")
        import_folder_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        import_folder_btn.clicked.connect(self.import_music_folder)

        remove_selected_btn = QPushButton("绉婚櫎閫変腑")
        remove_selected_btn.setObjectName("dangerButton")
        remove_selected_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        remove_selected_btn.clicked.connect(self.remove_selected_song)

        clean_missing_btn = QPushButton("娓呯悊澶辨晥")
        clean_missing_btn.setObjectName("secondaryButton")
        clean_missing_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        clean_missing_btn.clicked.connect(self.clean_missing_songs)

        header_layout.addLayout(title_box)
        header_layout.addStretch()
        header_layout.addWidget(clean_missing_btn)
        header_layout.addWidget(remove_selected_btn)
        header_layout.addWidget(import_folder_btn)
        header_layout.addWidget(import_btn)

        search_layout = QHBoxLayout()
        search_layout.setContentsMargins(0, 0, 0, 0)
        search_layout.setSpacing(10)

        self.search_input = QLineEdit()
        self.search_input.setObjectName("searchInput")
        self.search_input.setPlaceholderText("鎼滅储姝屾洸銆佹瓕鎵嬫垨涓撹緫")
        self.search_input.textChanged.connect(self.filter_song_list)

        clear_search_btn = QPushButton("娓呯┖")
        clear_search_btn.setObjectName("secondaryButton")
        clear_search_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        clear_search_btn.clicked.connect(self.clear_search)

        search_layout.addWidget(self.search_input, 1)
        search_layout.addWidget(clear_search_btn)

        self.view_layout = QHBoxLayout()
        self.view_layout.setContentsMargins(0, 0, 0, 0)
        self.view_layout.setSpacing(8)

        self.view_layout.addWidget(self._create_view_button("鍏ㄩ儴姝屾洸", "all"))
        self.view_layout.addWidget(self._create_view_button("鏈€杩戞挱鏀?, "recent_played"))
        self.view_layout.addWidget(self._create_view_button("甯稿惉姝屾洸", "frequent"))
        self.view_layout.addWidget(self._create_view_button("鏈€杩戞坊鍔?, "recent_added"))
        self.view_layout.addStretch()

        self.browser_mode_layout = QHBoxLayout()
        self.browser_mode_layout.setContentsMargins(0, 0, 0, 0)
        self.browser_mode_layout.setSpacing(8)
        self.browser_mode_layout.addWidget(self._create_browser_mode_button("姝屾洸", "songs"))
        self.browser_mode_layout.addWidget(self._create_browser_mode_button("姝屾墜", "artists"))
        self.browser_mode_layout.addWidget(self._create_browser_mode_button("涓撹緫", "albums"))
        self.browser_mode_layout.addStretch()

        self.category_back_btn = QPushButton("杩斿洖")
        self.category_back_btn.setObjectName("secondaryButton")
        self.category_back_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.category_back_btn.clicked.connect(self.show_category_overview)
        self.category_back_btn.hide()

        self.category_title_label = QLabel("")
        self.category_title_label.setObjectName("pageSubtitle")

        self.category_header_layout = QHBoxLayout()
        self.category_header_layout.setContentsMargins(0, 0, 0, 0)
        self.category_header_layout.setSpacing(10)
        self.category_header_layout.addWidget(self.category_back_btn)
        self.category_header_layout.addWidget(self.category_title_label)
        self.category_header_layout.addStretch()

        self.library_content_stack = QStackedWidget()
        self.library_content_stack.setObjectName("libraryContentStack")

        self.category_list = QListWidget()
        self.category_list.setObjectName("songList")
        self.category_list.itemDoubleClicked.connect(self.open_selected_category)

        self.song_list = QListWidget()
        self.song_list.setObjectName("songList")
        self.song_list.setAcceptDrops(False)
        self.song_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.song_list.customContextMenuRequested.connect(self.show_song_context_menu)
        self.song_list.itemClicked.connect(self.select_song)
        self.song_list.itemDoubleClicked.connect(self.play_selected_song)

        self.library_content_stack.addWidget(self.song_list)
        self.library_content_stack.addWidget(self.category_list)

        layout.addLayout(header_layout)
        layout.addLayout(search_layout)
        layout.addLayout(self.browser_mode_layout)
        layout.addLayout(self.view_layout)
        layout.addLayout(self.category_header_layout)
        layout.addWidget(self.library_content_stack, 1)

        return panel

    def _create_now_playing_panel(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("nowPlayingPanel")
        panel.setFixedWidth(360)

        layout = QVBoxLayout(panel)
        layout.setContentsMargins(24, 26, 24, 24)
        layout.setSpacing(16)

        title = QLabel("姝ｅ湪鎾斁")
        title.setObjectName("sectionTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft)

        self.cover_label = QLabel("Hush")
        self.cover_label.setObjectName("coverLabel")
        self.cover_label.setFixedSize(248, 248)
        self.cover_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.cover_label.setScaledContents(False)

        now_info_box = QFrame()
        now_info_box.setObjectName("nowInfoBox")

        now_info_layout = QVBoxLayout(now_info_box)
        now_info_layout.setContentsMargins(10, 0, 10, 0)
        now_info_layout.setSpacing(5)

        self.now_song_title = ElidedLabel("杩樻病鏈夋挱鏀鹃煶涔?)
        self.now_song_title.setObjectName("nowSongTitle")
        self.now_song_title.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.now_song_title.setFixedWidth(292)

        self.now_artist = ElidedLabel("瀵煎叆姝屾洸鍚庡紑濮嬫挱鏀?)
        self.now_artist.setObjectName("nowArtist")
        self.now_artist.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.now_artist.setFixedWidth(292)

        self.now_stats = QLabel("鎾斁 0 娆?路 绱 0:00")
        self.now_stats.setObjectName("nowStats")
        self.now_stats.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.now_stats.setFixedWidth(292)

        self.lyrics_status_label = QLabel("姝岃瘝锛氱瓑寰呴€夋嫨姝屾洸")
        self.lyrics_status_label.setObjectName("lyricsStatus")
        self.lyrics_status_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.lyrics_status_label.setFixedWidth(292)

        now_info_layout.addWidget(self.now_song_title)
        now_info_layout.addWidget(self.now_artist)
        now_info_layout.addWidget(self.now_stats)
        now_info_layout.addWidget(self.lyrics_status_label)

        self.lyrics_view = LyricsView()

        self.side_info_panel = QFrame()
        self.side_info_panel.setObjectName("sideInfoPanel")
        self.side_info_panel.hide()

        side_info_layout = QVBoxLayout(self.side_info_panel)
        side_info_layout.setContentsMargins(4, 8, 4, 8)
        side_info_layout.setSpacing(10)

        side_info_title = QLabel("姝屾洸淇℃伅")
        side_info_title.setObjectName("sideInfoTitle")

        side_info_hint = QLabel("姝岃瘝椤垫墦寮€鏃讹紝杩欓噷鏄剧ず褰撳墠娴忚姝屾洸鐨勪俊鎭€?)
        side_info_hint.setObjectName("sideInfoHint")
        side_info_hint.setWordWrap(True)

        self.side_artist_detail = ElidedLabel("鏈煡鑹烘湳瀹?)
        self.side_album_detail = ElidedLabel("鏈煡涓撹緫")
        self.side_like_detail = QLabel("鏈敹钘?)
        self.side_play_count_detail = QLabel("0 娆?)
        self.side_listen_time_detail = QLabel("0:00")
        self.side_last_played_detail = QLabel("杩樻病鏈夋挱鏀捐褰?)
        self.side_lyrics_status_value = QLabel("绛夊緟閫夋嫨姝屾洸")
        self.side_file_detail = QLabel("")
        self.side_file_detail.setWordWrap(True)

        side_info_layout.addWidget(side_info_title)
        side_info_layout.addWidget(side_info_hint)
        side_info_layout.addSpacing(4)
        side_info_layout.addWidget(self._create_side_info_row("姝屾墜", self.side_artist_detail))
        side_info_layout.addWidget(self._create_side_info_row("涓撹緫", self.side_album_detail))
        side_info_layout.addWidget(self._create_side_info_row("鏀惰棌", self.side_like_detail))
        side_info_layout.addWidget(self._create_side_info_row("鎾斁娆℃暟", self.side_play_count_detail))
        side_info_layout.addWidget(self._create_side_info_row("绱鏃堕暱", self.side_listen_time_detail))
        side_info_layout.addWidget(self._create_side_info_row("鏈€杩戞挱鏀?, self.side_last_played_detail))
        side_info_layout.addWidget(self._create_side_info_row("姝岃瘝鐘舵€?, self.side_lyrics_status_value))

        file_box = QFrame()
        file_box.setObjectName("sideInfoRow")
        file_layout = QVBoxLayout(file_box)
        file_layout.setContentsMargins(12, 10, 12, 10)
        file_layout.setSpacing(6)

        file_label = QLabel("鏂囦欢璺緞")
        file_label.setObjectName("sideInfoName")

        self.side_file_detail.setObjectName("sideInfoFileValue")

        file_layout.addWidget(file_label)
        file_layout.addWidget(self.side_file_detail)

        side_info_layout.addWidget(file_box)
        side_info_layout.addStretch()

        layout.addWidget(title)
        layout.addSpacing(8)
        layout.addWidget(self.cover_label, alignment=Qt.AlignmentFlag.AlignHCenter)
        layout.addWidget(now_info_box)
        layout.addSpacing(6)
        layout.addWidget(self.lyrics_view, 1)
        layout.addWidget(self.side_info_panel, 1)

        return panel

    def _create_player_bar(self) -> QFrame:
        bar = QFrame()
        bar.setObjectName("playerBar")
        bar.setFixedHeight(108)

        layout = QHBoxLayout(bar)
        layout.setContentsMargins(24, 14, 24, 14)
        layout.setSpacing(18)

        left_box = QFrame()
        left_box.setObjectName("playerLeft")
        left_box.setFixedWidth(280)

        left_layout = QVBoxLayout(left_box)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(5)

        self.bottom_song_title = ElidedLabel("鏈挱鏀?)
        self.bottom_song_title.setObjectName("bottomSongTitle")
        self.bottom_song_title.setFixedWidth(280)

        self.bottom_song_artist = ElidedLabel("璇烽€夋嫨涓€棣栭煶涔?)
        self.bottom_song_artist.setObjectName("bottomSongArtist")
        self.bottom_song_artist.setFixedWidth(280)

        left_layout.addStretch()
        left_layout.addWidget(self.bottom_song_title)
        left_layout.addWidget(self.bottom_song_artist)
        left_layout.addStretch()

        center_box = QFrame()
        center_box.setObjectName("playerCenter")
        center_box.setMinimumWidth(420)

        center_layout = QVBoxLayout(center_box)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(10)

        controls_layout = QHBoxLayout()
        controls_layout.setContentsMargins(0, 0, 0, 0)
        controls_layout.setSpacing(10)

        self.prev_btn = QPushButton("涓婁竴棣?)
        self.play_btn = QPushButton("鎾斁")
        self.next_btn = QPushButton("涓嬩竴棣?)

        self.prev_btn.setFixedWidth(72)
        self.play_btn.setFixedWidth(76)
        self.next_btn.setFixedWidth(72)

        for btn in (self.prev_btn, self.play_btn, self.next_btn):
            btn.setObjectName("controlButton")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)

        self.prev_btn.clicked.connect(self.play_previous_song)
        self.play_btn.clicked.connect(self.toggle_play)
        self.next_btn.clicked.connect(self.play_next_song)

        controls_layout.addStretch()
        controls_layout.addWidget(self.prev_btn)
        controls_layout.addWidget(self.play_btn)
        controls_layout.addWidget(self.next_btn)
        controls_layout.addStretch()

        self.progress_slider = QSlider(Qt.Orientation.Horizontal)
        self.progress_slider.setObjectName("progressSlider")
        self.progress_slider.setRange(0, 100)
        self.progress_slider.setValue(0)
        self.progress_slider.setMinimumWidth(360)
        self.progress_slider.sliderPressed.connect(self.on_seek_start)
        self.progress_slider.sliderReleased.connect(self.on_seek_end)

        center_layout.addStretch()
        center_layout.addLayout(controls_layout)
        center_layout.addWidget(self.progress_slider)
        center_layout.addStretch()

        right_box = QFrame()
        right_box.setObjectName("playerRight")
        right_box.setFixedWidth(320)

        right_layout = QVBoxLayout(right_box)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(9)

        self.like_btn = QPushButton("鈾?鏀惰棌")
        self.like_btn.setObjectName("likeButton")
        self.like_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.like_btn.setFixedWidth(92)
        self.like_btn.clicked.connect(self.toggle_like_current_song)

        self.play_mode_btn = QPushButton("鍒楄〃寰幆")
        self.play_mode_btn.setObjectName("controlButton")
        self.play_mode_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.play_mode_btn.setFixedWidth(90)
        self.play_mode_btn.clicked.connect(self.toggle_play_mode)

        self.floating_lyrics_button = QPushButton("妗岄潰姝岃瘝")
        self.floating_lyrics_button.setObjectName("floatingLyricsToggleButton")
        self.floating_lyrics_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.floating_lyrics_button.setFixedHeight(34)
        self.floating_lyrics_button.setFixedWidth(92)
        self.floating_lyrics_button.clicked.connect(self.toggle_floating_lyrics)

        top_row = QHBoxLayout()
        top_row.setContentsMargins(0, 0, 0, 0)
        top_row.setSpacing(8)
        top_row.addWidget(self.like_btn)
        top_row.addWidget(self.play_mode_btn)
        top_row.addWidget(self.floating_lyrics_button)
        top_row.addStretch()

        volume_row = QHBoxLayout()
        volume_row.setContentsMargins(0, 0, 0, 0)
        volume_row.setSpacing(8)

        volume_label = QLabel("闊抽噺")
        volume_label.setObjectName("volumeLabel")
        volume_label.setFixedWidth(34)

        self.volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.volume_slider.setObjectName("volumeSlider")
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(self.current_volume)
        self.volume_slider.setFixedWidth(210)
        self.volume_slider.valueChanged.connect(self.change_volume)

        volume_row.addWidget(volume_label)
        volume_row.addWidget(self.volume_slider)
        volume_row.addStretch()

        right_layout.addStretch()
        right_layout.addLayout(top_row)
        right_layout.addLayout(volume_row)
        right_layout.addStretch()

        layout.addWidget(left_box)
        layout.addWidget(center_box, 1)
        layout.addWidget(right_box)

        return bar

    def dragEnterEvent(self, event) -> None:
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event) -> None:
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event) -> None:
        if not event.mimeData().hasUrls():
            event.ignore()
            return

        paths_to_import: list[Path] = []

        for url in event.mimeData().urls():
            local_path = url.toLocalFile()

            if not local_path:
                continue

            path = Path(local_path)

            if path.is_dir():
                scanned_paths = self.scan_music_folder(path)
                paths_to_import.extend(scanned_paths)
                print(f"鎷栨嫿瀵煎叆鏂囦欢澶癸細{path}")
                print(f"鎵弿鍒伴煶涔愭枃浠舵暟閲忥細{len(scanned_paths)}")
            elif path.is_file():
                paths_to_import.append(path)
                print(f"鎷栨嫿瀵煎叆鏂囦欢锛歿path}")

        if paths_to_import:
            self.add_music_paths(paths_to_import)

        event.acceptProposedAction()

    def clear_search(self) -> None:
        self.search_input.clear()

    def filter_song_list(self, keyword: str) -> None:
        keyword = keyword.strip().lower()
        visible_count = 0

        if (
            hasattr(self, "category_list")
            and self.library_browser_mode in {"artists", "albums"}
            and not self.active_artist_name
            and self.active_album_key is None
        ):
            for index in range(self.category_list.count()):
                item = self.category_list.item(index)
                category_data = item.data(Qt.ItemDataRole.UserRole)
                search_text = item.text().lower()

                if isinstance(category_data, dict):
                    search_text = (
                        f"{search_text} "
                        f"{category_data.get('artist', '')} "
                        f"{category_data.get('album', '')}"
                    ).lower()

                should_show = not keyword or keyword in search_text
                item.setHidden(not should_show)

                if should_show:
                    visible_count += 1

            print(f"鍒嗙被鎼滅储鍏抽敭璇嶏細{keyword or '鏃?}锛屾樉绀烘暟閲忥細{visible_count}")
            return

        for index in range(self.song_list.count()):
            item = self.song_list.item(index)
            song_data = item.data(Qt.ItemDataRole.UserRole)

            if not isinstance(song_data, dict):
                item.setHidden(False)
                visible_count += 1
                continue

            title = str(song_data.get("title", ""))
            artist = str(song_data.get("artist", ""))
            album = str(song_data.get("album", ""))
            path = str(song_data.get("path", ""))

            search_text = f"{title} {artist} {album} {path}".lower()
            matches_keyword = not keyword or keyword in search_text
            matches_view = self.song_matches_current_view(song_data)
            should_show = matches_keyword and matches_view

            item.setHidden(not should_show)

            if should_show:
                visible_count += 1

        print(f"鎼滅储鍏抽敭璇嶏細{keyword or '鏃?}锛屾樉绀烘瓕鏇叉暟閲忥細{visible_count}")

    def get_visible_rows(self) -> list[int]:
        visible_rows = []

        for row in range(self.song_list.count()):
            item = self.song_list.item(row)

            if item and not item.isHidden():
                visible_rows.append(row)

        return visible_rows

    def add_demo_songs(self) -> None:
        self.song_list.clear()

        demo_songs = [
            ("涓冮噷棣?, "鍛ㄦ澃浼?, "鍙舵儬缇?),
            ("鏅村ぉ", "鍛ㄦ澃浼?, "鍙舵儬缇?),
            ("澶滄洸", "鍛ㄦ澃浼?, "鍗佷竴鏈堢殑钀ч偊"),
            ("绋婚", "鍛ㄦ澃浼?, "榄旀澃搴?),
            ("涓€璺悜鍖?, "鍛ㄦ澃浼?, "J III"),
        ]

        for title, artist, album in demo_songs:
            item = QListWidgetItem(f"{title}    路    {artist}    路    {album}")
            item.setData(
                Qt.ItemDataRole.UserRole,
                {
                    "title": title,
                    "artist": artist,
                    "album": album,
                    "path": "",
                    "demo": True,
                },
            )
            item.setData(Qt.ItemDataRole.UserRole, song_data)
            self.song_list.addItem(item)

        self.filter_song_list(self.search_input.text())

    def has_demo_songs(self) -> bool:
        if self.song_list.count() == 0:
            return False

        for index in range(self.song_list.count()):
            item = self.song_list.item(index)
            song_data = item.data(Qt.ItemDataRole.UserRole)

            if isinstance(song_data, dict) and song_data.get("demo"):
                return True

        return False

    def get_existing_song_paths(self) -> set[str]:
        paths = set()

        for song_data in getattr(self, "library_songs", []):
            if not isinstance(song_data, dict) or song_data.get("demo"):
                continue

            path = song_data.get("path", "")

            if path:
                paths.add(str(Path(path).resolve()))

        if paths:
            return paths

        for index in range(self.song_list.count()):
            item = self.song_list.item(index)
            song_data = item.data(Qt.ItemDataRole.UserRole)

            if not isinstance(song_data, dict):
                continue

            if song_data.get("demo"):
                continue

            path = song_data.get("path", "")

            if path:
                paths.add(str(Path(path).resolve()))

        return paths

    def save_music_library(self) -> None:
        self.library_file.parent.mkdir(parents=True, exist_ok=True)

        source_songs = getattr(self, "library_songs", [])

        if not source_songs:
            source_songs = self.collect_song_data_from_list()

        songs = []

        for song_data in source_songs:
            if not isinstance(song_data, dict):
                continue

            if song_data.get("demo"):
                continue

            path = song_data.get("path", "")

            if not path:
                continue

            songs.append(
                {
                    "title": song_data.get("title", "鏈煡姝屾洸"),
                    "artist": song_data.get("artist", "鏈煡鑹烘湳瀹?),
                    "album": song_data.get("album", "鏈煡涓撹緫"),
                    "path": str(Path(path).resolve()),
                    "added_at": int(song_data.get("added_at", 0) or 0),
                }
            )
            extra_fields = {
                key: value
                for key, value in song_data.items()
                if key not in {"title", "artist", "album", "path", "added_at", "demo"}
            }
            songs[-1].update(extra_fields)

        self.library_songs = [dict(song) for song in songs]

        with self.library_file.open("w", encoding="utf-8") as file:
            json.dump(songs, file, ensure_ascii=False, indent=2)

        print(f"闊充箰搴撳凡淇濆瓨锛歿self.library_file}")
        print(f"宸蹭繚瀛樻瓕鏇叉暟閲忥細{len(songs)}")

    def load_music_library(self) -> None:
        print("姝ｅ湪璇诲彇闊充箰搴擄細", self.library_file)

        if not self.library_file.exists():
            print("娌℃湁鎵惧埌宸蹭繚瀛樼殑闊充箰搴擄紝鏄剧ず婕旂ず姝屾洸銆?)
            self.add_demo_songs()
            return

        try:
            with self.library_file.open("r", encoding="utf-8") as file:
                songs = json.load(file)

        except Exception as error:
            print("璇诲彇闊充箰搴撳け璐ワ細", error)
            self.add_demo_songs()
            return

        if not songs:
            print("闊充箰搴撲负绌猴紝鏄剧ず婕旂ず姝屾洸銆?)
            self.add_demo_songs()
            return

        self.song_list.clear()

        valid_count = 0
        loaded_songs = []

        for song in songs:
            path = song.get("path", "")

            if not path:
                continue

            if not Path(path).exists():
                print("姝屾洸鏂囦欢涓嶅瓨鍦紝宸茶烦杩囷細", path)
                continue

            title = song.get("title", "鏈煡姝屾洸")
            artist = song.get("artist", "鏈煡鑹烘湳瀹?)
            album = song.get("album", "鏈煡涓撹緫")
            added_at = int(song.get("added_at", 0) or 0)
            song_data = {
                "title": title,
                "artist": artist,
                "album": album,
                "path": str(Path(path).resolve()),
                "added_at": added_at,
                "demo": False,
            }
            song_data.update(
                {
                    key: value
                    for key, value in song.items()
                    if key not in {"title", "artist", "album", "path", "added_at", "demo"}
                }
            )

            item = QListWidgetItem(f"{title}    路    {artist}    路    {album}")
            item.setData(
                Qt.ItemDataRole.UserRole,
                {
                    "title": title,
                    "artist": artist,
                    "album": album,
                    "path": str(Path(path).resolve()),
                    "added_at": added_at,
                    "demo": False,
                },
            )
            self.song_list.addItem(item)
            loaded_songs.append(song_data)
            valid_count += 1

        self.library_songs = loaded_songs
        self.refresh_library_browser()

        if valid_count > 0:
            visible_rows = self.get_visible_rows()

            if visible_rows:
                first_row = visible_rows[0]
                self.song_list.setCurrentRow(first_row)
                first_item = self.song_list.item(first_row)

                if first_item:
                    self.select_song(first_item)

            print(f"宸插姞杞介煶涔愬簱锛屽叡 {valid_count} 棣栨瓕銆?)
        else:
            self.add_demo_songs()
            print("淇濆瓨鐨勯煶涔愭枃浠惰矾寰勫叏閮ㄥけ鏁堬紝閲嶆柊鏄剧ず婕旂ず姝屾洸銆?)






















    def get_hush_settings(self) -> dict:
        settings = {}

        try:
            if hasattr(self, "settings_file") and self.settings_file.exists():
                with self.settings_file.open("r", encoding="utf-8") as file:
                    file_settings = json.load(file)

                if isinstance(file_settings, dict):
                    settings.update(file_settings)
        except Exception as error:
            print("璇诲彇璁剧疆鏂囦欢澶辫触锛?, error)

        if hasattr(self, "settings") and isinstance(self.settings, dict):
            settings.update(self.settings)

        return settings

    def get_user_setting(self, key: str, default=None):
        return self.get_hush_settings().get(key, default)

    def save_hush_settings(self, updates: dict) -> None:
        settings = self.get_hush_settings()
        settings.update(updates)

        self.settings = settings

        try:
            self.settings_file.parent.mkdir(parents=True, exist_ok=True)

            with self.settings_file.open("w", encoding="utf-8") as file:
                json.dump(settings, file, ensure_ascii=False, indent=2)

            print("璁剧疆宸蹭繚瀛橈細", self.settings_file)

        except Exception as error:
            print("淇濆瓨璁剧疆澶辫触锛?, error)
            QMessageBox.warning(self, "璁剧疆", f"淇濆瓨璁剧疆澶辫触锛歿error}")

    def apply_runtime_settings(self) -> None:
        immersive_window = getattr(self, "immersive_lyrics_window", None)

        if immersive_window is None:
            return

        immersive_window.cover_background_enabled = bool(
            self.get_user_setting("immersive_cover_background_enabled", True)
        )
        immersive_window.auto_hide_enabled = bool(
            self.get_user_setting("immersive_auto_hide_ui", True)
        )
        immersive_window.background_alpha = int(
            self.get_user_setting("immersive_background_alpha", 68)
        )

        if hasattr(immersive_window, "alpha_slider"):
            immersive_window.alpha_slider.blockSignals(True)
            immersive_window.alpha_slider.setValue(immersive_window.background_alpha)
            immersive_window.alpha_slider.blockSignals(False)

        if immersive_window.auto_hide_enabled:
            immersive_window.show_controls_temporarily()
        else:
            if hasattr(immersive_window, "hide_ui_timer"):
                immersive_window.hide_ui_timer.stop()

            if hasattr(immersive_window, "control_header"):
                immersive_window.control_header.show()

            if hasattr(immersive_window, "footer"):
                immersive_window.footer.show()

            immersive_window.ui_visible = True
            immersive_window.setCursor(Qt.CursorShape.ArrowCursor)

        immersive_window.apply_immersive_style()

    def open_settings_dialog(self) -> None:
        dialog = SettingsDialog(self)
        dialog.exec()

    def install_floating_lyrics_button(self) -> None:
        if not hasattr(self, "floating_lyrics_button"):
            self.floating_lyrics_button = QPushButton("妗岄潰姝岃瘝")
            self.floating_lyrics_button.setObjectName("floatingLyricsToggleButton")
            self.floating_lyrics_button.setCursor(Qt.CursorShape.PointingHandCursor)
            self.floating_lyrics_button.setFixedHeight(34)
            self.floating_lyrics_button.setFixedWidth(92)
            self.floating_lyrics_button.clicked.connect(self.toggle_floating_lyrics)

        self.update_floating_lyrics_button_state()
        return

        existing_button = getattr(self, "floating_lyrics_button", None)

        if existing_button is None:
            self.floating_lyrics_button = QPushButton("妗岄潰姝岃瘝")
            self.floating_lyrics_button.setObjectName("floatingLyricsToggleButton")
            self.floating_lyrics_button.setCursor(Qt.CursorShape.PointingHandCursor)
            self.floating_lyrics_button.setFixedHeight(34)
            self.floating_lyrics_button.setMinimumWidth(92)
            self.floating_lyrics_button.clicked.connect(self.toggle_floating_lyrics)
        else:
            old_parent = existing_button.parentWidget()

            if old_parent is not None:
                old_layout = old_parent.layout()

                if old_layout is not None:
                    old_layout.removeWidget(existing_button)

                existing_button.setParent(None)

        button = self.floating_lyrics_button

        def layout_contains_widget(layout, target_widget) -> bool:
            if layout is None or target_widget is None:
                return False

            for index in range(layout.count()):
                item = layout.itemAt(index)

                if item is None:
                    continue

                widget = item.widget()

                if widget is target_widget:
                    return True

                child_layout = item.layout()

                if child_layout is not None and layout_contains_widget(child_layout, target_widget):
                    return True

            return False

        def direct_widget_index(layout, target_widget) -> int:
            if layout is None or target_widget is None:
                return -1

            for index in range(layout.count()):
                item = layout.itemAt(index)

                if item is not None and item.widget() is target_widget:
                    return index

            return -1

        def find_button_by_text(text_candidates):
            for candidate_button in self.findChildren(QPushButton):
                text = candidate_button.text().strip()

                for candidate in text_candidates:
                    if candidate in text:
                        return candidate_button

            return None

        play_mode_button = getattr(self, "play_mode_button", None)

        if play_mode_button is None:
            play_mode_button = find_button_by_text(["鍒楄〃寰幆", "鍗曟洸寰幆", "闅忔満鎾斁"])

        like_button = getattr(self, "like_button", None)

        if like_button is None:
            like_button = find_button_by_text(["鏀惰棌", "宸叉敹钘?])

        target_layout = None
        anchor_widget = None

        for anchor in (play_mode_button, like_button):
            widget = anchor

            while widget is not None:
                parent = widget.parentWidget()

                if parent is None:
                    break

                layout = parent.layout()

                if layout is not None and layout_contains_widget(layout, anchor):
                    layout_name = layout.__class__.__name__.lower()

                    if "box" in layout_name and "vbox" not in layout_name:
                        target_layout = layout
                        anchor_widget = anchor
                        break

                    if target_layout is None:
                        target_layout = layout
                        anchor_widget = anchor

                widget = parent

            if target_layout is not None and "vbox" not in target_layout.__class__.__name__.lower():
                break

        if target_layout is None:
            print("娌℃湁鎵惧埌閫傚悎鏀炬闈㈡瓕璇嶆寜閽殑搴曢儴妯悜甯冨眬锛屼粛鍙敤 Ctrl+Shift+D 鎵撳紑銆?)
            return

        insert_index = direct_widget_index(target_layout, anchor_widget)

        if insert_index >= 0 and hasattr(target_layout, "insertWidget"):
            target_layout.insertWidget(insert_index + 1, button)
        else:
            target_layout.addWidget(button)

        self.update_floating_lyrics_button_state()

    def update_floating_lyrics_button_state(self) -> None:
        button = getattr(self, "floating_lyrics_button", None)

        if button is None:
            return

        window = getattr(self, "floating_lyrics_window", None)
        is_active = window is not None and window.isVisible()

        if is_active:
            button.setText("妗岄潰姝岃瘝寮€")
            button.setStyleSheet(
                "QPushButton#floatingLyricsToggleButton { background: #2f68d8; color: #ffffff; border: none; border-radius: 12px; padding: 8px 12px; font-size: 13px; font-weight: 700; }"
                "QPushButton#floatingLyricsToggleButton:hover { background: #3d7af0; }"
            )
        else:
            button.setText("妗岄潰姝岃瘝")
            button.setStyleSheet(
                "QPushButton#floatingLyricsToggleButton { background: #232833; color: #dfe4ee; border: none; border-radius: 12px; padding: 8px 12px; font-size: 13px; }"
                "QPushButton#floatingLyricsToggleButton:hover { background: #303747; }"
            )

    def install_floating_lyrics_feature(self) -> None:
        if not hasattr(self, "floating_lyrics_window"):
            self.floating_lyrics_window = None

        if not hasattr(self, "floating_lyrics_shortcut"):
            self.floating_lyrics_shortcut = QShortcut(QKeySequence("Ctrl+Shift+D"), self)
            self.floating_lyrics_shortcut.activated.connect(self.toggle_floating_lyrics)

        if not hasattr(self, "floating_lyrics_timer"):
            self.floating_lyrics_timer = QTimer(self)
            self.floating_lyrics_timer.timeout.connect(self.sync_floating_lyrics)
            self.floating_lyrics_timer.start(220)

    def toggle_floating_lyrics(self) -> None:
        if self.floating_lyrics_window is not None and self.floating_lyrics_window.isVisible():
            self.floating_lyrics_window.close()
            self.floating_lyrics_window = None
            return

        self.show_floating_lyrics()

    def show_floating_lyrics(self) -> None:
        if self.floating_lyrics_window is None:
            self.floating_lyrics_window = FloatingLyricsWindow(self)

        self.sync_floating_lyrics()

        screen = QApplication.primaryScreen()

        if screen:
            geometry = screen.availableGeometry()
            width = self.floating_lyrics_window.width()
            height = self.floating_lyrics_window.height()
            x = geometry.x() + (geometry.width() - width) // 2
            y = geometry.y() + geometry.height() - height - 80
            self.floating_lyrics_window.move(x, y)

        self.floating_lyrics_window.show()
        self.floating_lyrics_window.raise_()

    def get_lyric_context_by_position(self, position: int, lyrics: list[tuple[int, str]]) -> tuple[str, str, str]:
        if not lyrics:
            return "", "鏆傛棤姝岃瘝", ""

        current_index = 0

        for index, (start_time, line_text) in enumerate(lyrics):
            if position >= start_time:
                current_index = index
            else:
                break

        previous_line = ""
        current_line = lyrics[current_index][1]
        next_line = ""

        if current_index > 0:
            previous_line = lyrics[current_index - 1][1]

        if current_index + 1 < len(lyrics):
            next_line = lyrics[current_index + 1][1]

        return previous_line, current_line, next_line

    def sync_floating_lyrics(self) -> None:
        window = getattr(self, "floating_lyrics_window", None)

        if window is None or not window.isVisible():
            return

        current_song_path = self.normalize_song_path(getattr(self, "current_song_path", ""))
        displayed_lyrics_path = self.normalize_song_path(getattr(self, "displayed_lyrics_song_path", ""))

        if not current_song_path:
            window.set_lines("", "杩樻病鏈夋挱鏀鹃煶涔?, "鎾斁涓€棣栨瓕鍚庯紝杩欓噷浼氭樉绀烘闈㈡瓕璇?)
            return

        if displayed_lyrics_path != current_song_path or not getattr(self, "current_lyrics", None):
            title, artist_album, status = self.get_playing_song_display_data()
            window.set_lines("", title, "褰撳墠姝屾洸鏆傛棤鍚屾姝岃瘝")
            return

        position = self.media_player.position()
        previous_line, current_line, next_line = self.get_lyric_context_by_position(
            position,
            self.current_lyrics,
        )
        window.set_lines(previous_line, current_line, next_line)

    def install_playlist_button_hook(self) -> None:
        self.playlist_nav_button = None

        for button in self.findChildren(QPushButton):
            button_text = button.text().strip()

            if not button_text.startswith("鎾斁鍒楄〃"):
                continue

            if button.property("hushPlaylistHooked"):
                self.playlist_nav_button = button
                continue

            try:
                button.clicked.disconnect()
            except Exception:
                pass

            button.clicked.connect(self.show_play_queue)
            button.setProperty("hushPlaylistHooked", True)
            button.setCursor(Qt.CursorShape.PointingHandCursor)

            self.playlist_nav_button = button

        self.update_play_queue_nav_badge()

    def update_play_queue_nav_badge(self) -> None:
        button = getattr(self, "playlist_nav_button", None)

        if button is None:
            return

        queue = getattr(self, "play_queue", [])
        count = len(queue) if isinstance(queue, list) else 0

        if count > 0:
            button.setText(f"鎾斁鍒楄〃 ({count})")
        else:
            button.setText("鎾斁鍒楄〃")

    def install_settings_button_hook(self) -> None:
        for button in self.findChildren(QPushButton):
            button_text = button.text().strip()

            if button_text != "璁剧疆":
                continue

            if button.property("hushSettingsHooked"):
                continue

            try:
                button.clicked.disconnect()
            except Exception:
                pass

            button.clicked.connect(self.open_settings_dialog)
            button.setProperty("hushSettingsHooked", True)
            button.setCursor(Qt.CursorShape.PointingHandCursor)

    def clear_missing_cache_files(self) -> int:
        removed_count = 0
        cache_dirs = []

        for attr_name in ("cover_cache_dir", "lyrics_cache_dir"):
            cache_dir = getattr(self, attr_name, None)

            if cache_dir:
                cache_dirs.append(Path(cache_dir))

        for cache_dir in cache_dirs:
            if not cache_dir.exists():
                continue

            for missing_file in cache_dir.glob("*.missing"):
                try:
                    missing_file.unlink()
                    removed_count += 1
                except Exception as error:
                    print("鍒犻櫎澶辫触缂撳瓨澶辫触锛?, missing_file, error)

        return removed_count

    def load_play_queue(self) -> list[str]:
        if not self.play_queue_file.exists():
            return []

        try:
            with self.play_queue_file.open("r", encoding="utf-8") as file:
                data = json.load(file)

            if not isinstance(data, list):
                return []

            queue = []

            for song_path in data:
                normalized_path = self.normalize_song_path(str(song_path))

                if normalized_path and Path(normalized_path).exists():
                    queue.append(normalized_path)

            return queue

        except Exception as error:
            print("璇诲彇鎾斁闃熷垪澶辫触锛?, error)
            return []

    def save_play_queue(self) -> None:
        try:
            self.play_queue_file.parent.mkdir(parents=True, exist_ok=True)

            with self.play_queue_file.open("w", encoding="utf-8") as file:
                json.dump(self.play_queue, file, ensure_ascii=False, indent=2)

            print("鎾斁闃熷垪宸蹭繚瀛橈細", self.play_queue_file)

        except Exception as error:
            print("淇濆瓨鎾斁闃熷垪澶辫触锛?, error)

        try:
            self.update_play_queue_nav_badge()
        except Exception:
            pass

    def get_song_title_for_queue(self, song_path: str) -> str:
        song_data = self.find_song_data_by_path(song_path) if hasattr(self, "find_song_data_by_path") else None

        if song_data:
            title = song_data.get("title", "鏈煡姝屾洸")
            artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
            return f"{title} - {artist}"

        return Path(song_path).stem

    def queue_song_path(self, song_path: str | None, insert_next: bool = False) -> None:
        normalized_path = self.normalize_song_path(song_path)

        if not normalized_path:
            QMessageBox.information(self, "鎻愮ず", "杩欓姝屾病鏈夋湁鏁堟枃浠惰矾寰勩€?)
            return

        if not Path(normalized_path).exists():
            QMessageBox.information(self, "鎻愮ず", "杩欎釜闊充箰鏂囦欢宸茬粡涓嶅瓨鍦ㄣ€?)
            return

        if not hasattr(self, "play_queue"):
            self.play_queue = []

        if insert_next:
            self.play_queue.insert(0, normalized_path)
            action_text = "宸茶涓轰笅涓€棣栨挱鏀?
        else:
            self.play_queue.append(normalized_path)
            action_text = "宸插姞鍏ユ挱鏀鹃槦鍒?

        self.save_play_queue()

        song_text = self.get_song_title_for_queue(normalized_path)
        print(f"{action_text}锛歿song_text}")
        QMessageBox.information(self, "鎾斁闃熷垪", f"{action_text}\\n\\n{song_text}")

    def queue_selected_song_next(self, selected_item=None) -> None:
        item = selected_item or self.song_list.currentItem()

        if not item:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栨瓕銆?)
            return

        song_data = self.get_song_data_from_item(item)

        if not song_data:
            QMessageBox.information(self, "鎻愮ず", "璇烽€夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        self.queue_song_path(song_data.get("path", ""), insert_next=True)

    def queue_selected_song_last(self, selected_item=None) -> None:
        item = selected_item or self.song_list.currentItem()

        if not item:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栨瓕銆?)
            return

        song_data = self.get_song_data_from_item(item)

        if not song_data:
            QMessageBox.information(self, "鎻愮ず", "璇烽€夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        self.queue_song_path(song_data.get("path", ""), insert_next=False)

    def get_main_stack_widget(self):
        possible_names = [
            "content_stack",
            "main_stack",
            "page_stack",
            "stacked_widget",
            "stack",
            "center_stack",
        ]

        for name in possible_names:
            stack = getattr(self, name, None)

            if isinstance(stack, QStackedWidget):
                return stack

        stacks = self.findChildren(QStackedWidget)

        if not stacks:
            return None

        stacks.sort(key=lambda item: item.count(), reverse=True)
        return stacks[0]

    def ensure_play_queue_page(self) -> None:
        if hasattr(self, "play_queue_page") and self.play_queue_page is not None:
            return

        stack = self.get_main_stack_widget()

        if stack is None:
            QMessageBox.information(self, "鎾斁鍒楄〃", "娌℃湁鎵惧埌涓婚〉闈㈠鍣紝鏆傛椂鏃犳硶鍒囨崲鍒版挱鏀惧垪琛ㄩ〉闈€?)
            return

        self.play_queue_page = QFrame()
        self.play_queue_page.setObjectName("playQueuePage")

        layout = QVBoxLayout(self.play_queue_page)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(12)

        title_box = QVBoxLayout()
        title_box.setContentsMargins(0, 0, 0, 0)
        title_box.setSpacing(6)

        title = QLabel("鎾斁鍒楄〃")
        title.setObjectName("playQueuePageTitle")

        subtitle = QLabel("杩欓噷鏄剧ず鎺ヤ笅鏉ヤ細浼樺厛鎾斁鐨勬瓕鏇层€傚彸閿煶涔愬簱閲岀殑姝屾洸锛屽彲浠ラ€夋嫨鈥滀笅涓€棣栨挱鏀锯€濇垨鈥滃姞鍏ユ挱鏀鹃槦鍒椻€濄€?)
        subtitle.setObjectName("playQueuePageSubtitle")
        subtitle.setWordWrap(True)

        title_box.addWidget(title)
        title_box.addWidget(subtitle)

        self.play_queue_back_btn = QPushButton("杩斿洖闊充箰搴?)
        self.play_queue_back_btn.setObjectName("playQueuePageSecondaryButton")
        self.play_queue_back_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.play_queue_back_btn.clicked.connect(self.return_from_play_queue_page)

        header.addLayout(title_box, 1)
        header.addWidget(self.play_queue_back_btn)

        self.play_queue_page_list = QListWidget()
        self.play_queue_page_list.setObjectName("playQueuePageList")
        self.play_queue_page_list.itemDoubleClicked.connect(self.play_selected_queue_page_song)

        button_row = QHBoxLayout()
        button_row.setContentsMargins(0, 0, 0, 0)
        button_row.setSpacing(10)

        self.queue_page_play_btn = QPushButton("绔嬪嵆鎾斁")
        self.queue_page_play_btn.setObjectName("playQueuePagePrimaryButton")
        self.queue_page_play_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.queue_page_play_btn.clicked.connect(self.play_selected_queue_page_song)

        self.queue_page_remove_btn = QPushButton("绉婚櫎")
        self.queue_page_remove_btn.setObjectName("playQueuePageSecondaryButton")
        self.queue_page_remove_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.queue_page_remove_btn.clicked.connect(self.remove_selected_queue_page_song)

        self.queue_page_up_btn = QPushButton("涓婄Щ")
        self.queue_page_up_btn.setObjectName("playQueuePageSecondaryButton")
        self.queue_page_up_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.queue_page_up_btn.clicked.connect(self.move_selected_queue_page_song_up)

        self.queue_page_down_btn = QPushButton("涓嬬Щ")
        self.queue_page_down_btn.setObjectName("playQueuePageSecondaryButton")
        self.queue_page_down_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.queue_page_down_btn.clicked.connect(self.move_selected_queue_page_song_down)

        self.queue_page_clear_btn = QPushButton("娓呯┖闃熷垪")
        self.queue_page_clear_btn.setObjectName("playQueuePageDangerButton")
        self.queue_page_clear_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.queue_page_clear_btn.clicked.connect(self.clear_queue_from_page)

        button_row.addWidget(self.queue_page_play_btn)
        button_row.addWidget(self.queue_page_remove_btn)
        button_row.addWidget(self.queue_page_up_btn)
        button_row.addWidget(self.queue_page_down_btn)
        button_row.addStretch(1)
        button_row.addWidget(self.queue_page_clear_btn)

        self.play_queue_page_hint = QLabel("鎾斁闃熷垪涓虹┖銆?)
        self.play_queue_page_hint.setObjectName("playQueuePageHint")
        self.play_queue_page_hint.setWordWrap(True)

        layout.addLayout(header)
        layout.addWidget(self.play_queue_page_list, 1)
        layout.addLayout(button_row)
        layout.addWidget(self.play_queue_page_hint)

        self.play_queue_page.setStyleSheet(
            "QFrame#playQueuePage { background: transparent; color: #e8ecf5; }"
            "QLabel#playQueuePageTitle { color: #ffffff; font-size: 28px; font-weight: 900; }"
            "QLabel#playQueuePageSubtitle { color: #9ca5b5; font-size: 13px; }"
            "QLabel#playQueuePageHint { color: #8f98a8; font-size: 12px; }"
            "QListWidget#playQueuePageList { background: #171a22; color: #e8ecf5; border: 1px solid #252a35; border-radius: 16px; padding: 8px; outline: none; }"
            "QListWidget#playQueuePageList::item { padding: 13px 12px; border-radius: 10px; }"
            "QListWidget#playQueuePageList::item:hover { background: #232936; }"
            "QListWidget#playQueuePageList::item:selected { background: #2f68d8; color: #ffffff; }"
            "QPushButton#playQueuePagePrimaryButton { background: #2f68d8; color: #ffffff; border: none; border-radius: 12px; padding: 10px 16px; font-size: 13px; font-weight: 700; }"
            "QPushButton#playQueuePagePrimaryButton:hover { background: #3d7af0; }"
            "QPushButton#playQueuePageSecondaryButton { background: #232833; color: #dfe4ee; border: none; border-radius: 12px; padding: 10px 16px; font-size: 13px; }"
            "QPushButton#playQueuePageSecondaryButton:hover { background: #303747; }"
            "QPushButton#playQueuePageDangerButton { background: #3a2024; color: #ffd7dd; border: none; border-radius: 12px; padding: 10px 16px; font-size: 13px; }"
            "QPushButton#playQueuePageDangerButton:hover { background: #71303a; color: #ffffff; }"
        )

        stack.addWidget(self.play_queue_page)

    def show_play_queue_page(self) -> None:
        self.ensure_play_queue_page()

        if not hasattr(self, "play_queue_page") or self.play_queue_page is None:
            return

        stack = self.get_main_stack_widget()

        if stack is None:
            return

        self.play_queue_previous_stack_index = stack.currentIndex()

        if hasattr(self, "set_right_panel_mode"):
            self.set_right_panel_mode("normal")

        self.refresh_play_queue_page()
        stack.setCurrentWidget(self.play_queue_page)

    def return_from_play_queue_page(self) -> None:
        if hasattr(self, "show_library_page"):
            self.show_library_page()
            return

        stack = self.get_main_stack_widget()

        if stack is None:
            return

        previous_index = getattr(self, "play_queue_previous_stack_index", 0)

        if previous_index < 0 or previous_index >= stack.count():
            previous_index = 0

        stack.setCurrentIndex(previous_index)

    def refresh_play_queue_page(self) -> None:
        if not hasattr(self, "play_queue_page_list"):
            return

        if not hasattr(self, "play_queue"):
            self.play_queue = []

        valid_queue = []

        for song_path in self.play_queue:
            normalized_path = self.normalize_song_path(song_path)

            if normalized_path and Path(normalized_path).exists():
                valid_queue.append(normalized_path)

        if valid_queue != self.play_queue:
            self.play_queue = valid_queue
            self.save_play_queue()

        self.play_queue_page_list.clear()

        for index, song_path in enumerate(self.play_queue, start=1):
            song_title = self.get_song_title_for_queue(song_path)
            item = QListWidgetItem(f"{index}. {song_title}")
            item.setData(Qt.ItemDataRole.UserRole, song_path)
            self.play_queue_page_list.addItem(item)

        if self.play_queue_page_list.count() > 0 and self.play_queue_page_list.currentRow() < 0:
            self.play_queue_page_list.setCurrentRow(0)

        count = self.play_queue_page_list.count()

        if count == 0:
            self.play_queue_page_hint.setText("鎾斁闃熷垪鏄┖鐨勩€傚彲浠ュ湪闊充箰搴撻噷鍙抽敭姝屾洸锛岄€夋嫨鈥滀笅涓€棣栨挱鏀锯€濇垨鈥滃姞鍏ユ挱鏀鹃槦鍒椻€濄€?)
        else:
            self.play_queue_page_hint.setText(f"闃熷垪閲屾湁 {count} 棣栨瓕銆傚弻鍑绘瓕鏇插彲浠ョ珛鍗虫挱鏀俱€?)

        try:
            self.update_play_queue_nav_badge()
        except Exception:
            pass

    def get_selected_queue_page_index(self) -> int:
        if not hasattr(self, "play_queue_page_list"):
            return -1

        row = self.play_queue_page_list.currentRow()

        if row < 0 or row >= len(self.play_queue):
            QMessageBox.information(self, "鎾斁鍒楄〃", "璇峰厛閫夋嫨鎾斁鍒楄〃閲岀殑涓€棣栨瓕銆?)
            return -1

        return row

    def play_selected_queue_page_song(self) -> None:
        row = self.get_selected_queue_page_index()

        if row < 0:
            return

        song_path = self.play_queue.pop(row)
        self.save_play_queue()

        if self.play_song_from_queue_path(song_path):
            self.refresh_play_queue_page()
        else:
            QMessageBox.information(self, "鎾斁鍒楄〃", "杩欓姝屾棤娉曟挱鏀撅紝鍙兘鏂囦欢宸茬粡涓嶅瓨鍦ㄣ€?)
            self.refresh_play_queue_page()

    def remove_selected_queue_page_song(self) -> None:
        row = self.get_selected_queue_page_index()

        if row < 0:
            return

        self.play_queue.pop(row)
        self.save_play_queue()
        self.refresh_play_queue_page()

        if self.play_queue_page_list.count() > 0:
            self.play_queue_page_list.setCurrentRow(min(row, self.play_queue_page_list.count() - 1))

    def move_selected_queue_page_song_up(self) -> None:
        row = self.get_selected_queue_page_index()

        if row <= 0:
            return

        self.play_queue[row - 1], self.play_queue[row] = self.play_queue[row], self.play_queue[row - 1]
        self.save_play_queue()
        self.refresh_play_queue_page()
        self.play_queue_page_list.setCurrentRow(row - 1)

    def move_selected_queue_page_song_down(self) -> None:
        row = self.get_selected_queue_page_index()

        if row < 0 or row >= len(self.play_queue) - 1:
            return

        self.play_queue[row + 1], self.play_queue[row] = self.play_queue[row], self.play_queue[row + 1]
        self.save_play_queue()
        self.refresh_play_queue_page()
        self.play_queue_page_list.setCurrentRow(row + 1)

    def clear_queue_from_page(self) -> None:
        if not self.play_queue:
            QMessageBox.information(self, "鎾斁鍒楄〃", "鎾斁鍒楄〃宸茬粡鏄┖鐨勩€?)
            return

        reply = QMessageBox.question(
            self,
            "娓呯┖鎾斁鍒楄〃",
            "纭畾瑕佹竻绌哄綋鍓嶆挱鏀惧垪琛ㄥ悧锛?,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )

        if reply != QMessageBox.StandardButton.Yes:
            return

        self.play_queue.clear()
        self.save_play_queue()
        self.refresh_play_queue_page()

    def show_play_queue(self) -> None:
        self.show_play_queue_page()

    def clear_play_queue(self) -> None:
        if not hasattr(self, "play_queue"):
            self.play_queue = []

        if not self.play_queue:
            QMessageBox.information(self, "鎾斁闃熷垪", "鎾斁闃熷垪宸茬粡鏄┖鐨勩€?)
            self.save_play_queue()
            return

        self.play_queue.clear()
        self.save_play_queue()
        QMessageBox.information(self, "鎾斁闃熷垪", "鎾斁闃熷垪宸叉竻绌恒€?)
        print("鎾斁闃熷垪宸叉竻绌?)

    def play_song_from_queue_path(self, song_path: str) -> bool:
        normalized_path = self.normalize_song_path(song_path)

        if not normalized_path or not Path(normalized_path).exists():
            return False

        item = self.find_song_item_by_path(normalized_path) if hasattr(self, "find_song_item_by_path") else None
        song_data = self.find_song_data_by_path(normalized_path) if hasattr(self, "find_song_data_by_path") else None

        if song_data is None and item is not None:
            item_data = item.data(Qt.ItemDataRole.UserRole)

            if isinstance(item_data, dict):
                song_data = item_data

        if not song_data:
            return False

        if item is not None:
            self.song_list.setCurrentItem(item)

        self.browsing_song_path = normalized_path
        self.browsing_song_data = song_data

        self.load_song_for_playback(song_data)
        self.media_player.play()

        if hasattr(self, "play_button"):
            self.play_button.setText("鏆傚仠")

        try:
            self.save_play_queue()

            if hasattr(self, "save_playback_session"):
                self.save_playback_session()
        except Exception as error:
            print("鎾斁闃熷垪姝屾洸鍚庝繚瀛樼姸鎬佸け璐ワ細", error)

        title = song_data.get("title", "鏈煡姝屾洸")
        artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
        print(f"姝ｅ湪鎾斁闃熷垪姝屾洸锛歿title} - {artist}")

        return True

    def play_next_queued_song(self) -> bool:
        if not hasattr(self, "play_queue"):
            self.play_queue = []

        while self.play_queue:
            song_path = self.play_queue.pop(0)

            if self.play_song_from_queue_path(song_path):
                self.save_play_queue()
                return True

        self.save_play_queue()
        return False

    def load_playback_session(self) -> dict:
        if not self.playback_session_file.exists():
            return {}

        try:
            with self.playback_session_file.open("r", encoding="utf-8") as file:
                data = json.load(file)

            if isinstance(data, dict):
                return data

            return {}

        except Exception as error:
            print("璇诲彇涓婃鎾斁鐘舵€佸け璐ワ細", error)
            return {}

    def save_playback_session(self) -> None:
        if not hasattr(self, "media_player"):
            return

        current_path = self.normalize_song_path(getattr(self, "current_song_path", ""))

        if not current_path:
            return

        try:
            position = int(self.media_player.position())
        except Exception:
            position = 0

        session = {
            "path": current_path,
            "position": position,
            "saved_at": int(time.time()),
            "library_view": getattr(self, "current_library_view", "all"),
        }

        self.playback_session_file.parent.mkdir(parents=True, exist_ok=True)

        with self.playback_session_file.open("w", encoding="utf-8") as file:
            json.dump(session, file, ensure_ascii=False, indent=2)

    def find_song_item_by_path(self, song_path: str | None):
        normalized_path = self.normalize_song_path(song_path)

        if not normalized_path:
            return None

        for row in range(self.song_list.count()):
            item = self.song_list.item(row)

            if not item:
                continue

            song_data = item.data(Qt.ItemDataRole.UserRole)

            if not isinstance(song_data, dict):
                continue

            item_path = self.normalize_song_path(song_data.get("path", ""))

            if item_path == normalized_path:
                return item

        return None

    def restore_playback_session(self) -> None:
        if getattr(self, "restored_playback_session", False):
            return

        self.restored_playback_session = True

        session = getattr(self, "playback_session", {})

        if not isinstance(session, dict):
            return

        song_path = self.normalize_song_path(session.get("path", ""))
        position = int(session.get("position", 0) or 0)

        if not song_path:
            return

        if not Path(song_path).exists():
            print("涓婃鎾斁鐨勬枃浠跺凡缁忎笉瀛樺湪锛?, song_path)
            return

        try:
            if hasattr(self, "set_library_view"):
                self.set_library_view("all")
        except Exception as error:
            print("鍒囨崲鍒板叏閮ㄦ瓕鏇茶鍥惧け璐ワ細", error)

        item = self.find_song_item_by_path(song_path)

        if item is None:
            print("闊充箰搴撻噷娌℃湁鎵惧埌涓婃鎾斁姝屾洸锛?, song_path)
            return

        song_data = item.data(Qt.ItemDataRole.UserRole)

        if not isinstance(song_data, dict):
            return

        self.song_list.setCurrentItem(item)
        self.browsing_song_path = song_path
        self.browsing_song_data = song_data

        try:
            self.load_song_for_playback(song_data)
        except Exception as error:
            print("鎭㈠涓婃鎾斁姝屾洸澶辫触锛?, error)
            return

        if position > 0:
            QTimer.singleShot(650, lambda position=position: self.media_player.setPosition(position))

        title = song_data.get("title", "鏈煡姝屾洸")
        artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)

        print(f"宸叉仮澶嶄笂娆℃挱鏀撅細{title} - {artist} @ {position // 1000}s")

    def load_settings(self) -> dict:
        default_settings = {
            "volume": 65,
            "play_mode": "list_loop",
        }

        if not self.settings_file.exists():
            return default_settings

        try:
            with self.settings_file.open("r", encoding="utf-8") as file:
                settings = json.load(file)

            volume = int(settings.get("volume", default_settings["volume"]))
            volume = max(0, min(100, volume))

            play_mode = settings.get("play_mode", default_settings["play_mode"])
            if play_mode not in {"list_loop", "single_loop", "shuffle"}:
                play_mode = "list_loop"

            return {
                "volume": volume,
                "play_mode": play_mode,
            }

        except Exception as error:
            print("璇诲彇璁剧疆澶辫触锛?, error)
            return default_settings

    def load_playlists(self) -> dict:
        default_playlists = {
            "liked": {
                "name": "鎴戝枩娆?,
                "songs": [],
                "fixed": True,
            }
        }

        if not self.playlists_file.exists():
            return default_playlists

        try:
            with self.playlists_file.open("r", encoding="utf-8") as file:
                playlists = json.load(file)

            if not isinstance(playlists, dict):
                return default_playlists

            if "liked" not in playlists:
                playlists["liked"] = default_playlists["liked"]

            if not isinstance(playlists["liked"], dict):
                playlists["liked"] = default_playlists["liked"]

            playlists["liked"].setdefault("name", "鎴戝枩娆?)
            playlists["liked"].setdefault("songs", [])
            playlists["liked"]["fixed"] = True

            if not isinstance(playlists["liked"]["songs"], list):
                playlists["liked"]["songs"] = []

            return playlists

        except Exception as error:
            print("璇诲彇姝屽崟澶辫触锛?, error)
            return default_playlists

    def save_playlists(self) -> None:
        self.playlists_file.parent.mkdir(parents=True, exist_ok=True)

        if "liked" not in self.playlists:
            self.playlists["liked"] = {
                "name": "鎴戝枩娆?,
                "songs": [],
                "fixed": True,
            }

        with self.playlists_file.open("w", encoding="utf-8") as file:
            json.dump(self.playlists, file, ensure_ascii=False, indent=2)

        print("姝屽崟宸蹭繚瀛橈細", self.playlists_file)

    def normalize_song_path(self, path: str | None) -> str:
        if not path:
            return ""

        try:
            return str(Path(path).resolve())
        except Exception:
            return str(path)

    def get_liked_song_paths(self) -> list[str]:
        liked_playlist = self.playlists.setdefault(
            "liked",
            {
                "name": "鎴戝枩娆?,
                "songs": [],
                "fixed": True,
            },
        )

        songs = liked_playlist.setdefault("songs", [])

        if not isinstance(songs, list):
            liked_playlist["songs"] = []
            songs = liked_playlist["songs"]

        return songs

    def is_song_liked(self, path: str | None) -> bool:
        normalized_path = self.normalize_song_path(path)

        if not normalized_path:
            return False

        liked_songs = self.get_liked_song_paths()
        return normalized_path in liked_songs

    def update_like_button(self) -> None:
        if not hasattr(self, "like_btn"):
            return

        target_path = self.get_active_info_song_path()

        if not target_path:
            self.like_btn.setText("鈾?鏀惰棌")
            self.like_btn.setProperty("liked", False)
            self.like_btn.setEnabled(False)
        elif self.is_song_liked(target_path):
            self.like_btn.setText("鈾?宸叉敹钘?)
            self.like_btn.setProperty("liked", True)
            self.like_btn.setEnabled(True)
        else:
            self.like_btn.setText("鈾?鏀惰棌")
            self.like_btn.setProperty("liked", False)
            self.like_btn.setEnabled(True)

        self.like_btn.style().unpolish(self.like_btn)
        self.like_btn.style().polish(self.like_btn)
        self.like_btn.update()

    def toggle_like_current_song(self) -> None:
        target_path = self.get_active_info_song_path()

        if not target_path:
            print("褰撳墠娌℃湁鍙敹钘忕殑鐪熷疄姝屾洸銆?)
            return

        liked_songs = self.get_liked_song_paths()

        if target_path in liked_songs:
            liked_songs.remove(target_path)
            print("宸插彇娑堟敹钘忥細", target_path)
        else:
            liked_songs.append(target_path)
            print("宸插姞鍏ユ垜鍠滄锛?, target_path)

        self.save_playlists()
        self.update_like_button()
        self.update_side_info_panel()

        if self.current_library_view == "liked":
            self.filter_song_list(self.search_input.text())

    def load_song_stats(self) -> dict:
        if not self.stats_file.exists():
            return {}

        try:
            with self.stats_file.open("r", encoding="utf-8") as file:
                raw_stats = json.load(file)

            if not isinstance(raw_stats, dict):
                return {}

            cleaned_stats = {}

            for path, stats in raw_stats.items():
                if not isinstance(stats, dict):
                    continue

                normalized_path = self.normalize_song_path(path)

                if not normalized_path:
                    continue

                cleaned_stats[normalized_path] = {
                    "play_count": max(0, int(stats.get("play_count", 0))),
                    "total_listen_time": max(0, int(stats.get("total_listen_time", 0))),
                    "last_played": max(0, int(stats.get("last_played", 0))),
                }

            return cleaned_stats

        except Exception as error:
            print("璇诲彇鎾斁缁熻澶辫触锛?, error)
            return {}

    def save_song_stats(self) -> None:
        self.stats_file.parent.mkdir(parents=True, exist_ok=True)

        with self.stats_file.open("w", encoding="utf-8") as file:
            json.dump(self.song_stats, file, ensure_ascii=False, indent=2)

        print("鎾斁缁熻宸蹭繚瀛橈細", self.stats_file)

    def get_song_stats(self, path: str | None) -> dict | None:
        normalized_path = self.normalize_song_path(path)

        if not normalized_path:
            return None

        if normalized_path not in self.song_stats:
            self.song_stats[normalized_path] = {
                "play_count": 0,
                "total_listen_time": 0,
                "last_played": 0,
            }

        return self.song_stats[normalized_path]

    def format_listen_time(self, seconds: int) -> str:
        seconds = max(0, int(seconds))

        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        remaining_seconds = seconds % 60

        if hours > 0:
            return f"{hours}:{minutes:02d}:{remaining_seconds:02d}"

        return f"{minutes}:{remaining_seconds:02d}"

    def update_current_song_stats_label(self) -> None:
        if not hasattr(self, "now_stats"):
            return

        target_path = self.get_active_info_song_path()

        if not target_path:
            self.now_stats.setText("鎾斁 0 娆?路 绱 0:00")
            return

        stats = self.get_song_stats(target_path)

        if not stats:
            self.now_stats.setText("鎾斁 0 娆?路 绱 0:00")
            return

        play_count = int(stats.get("play_count", 0))
        total_listen_time = int(stats.get("total_listen_time", 0))
        formatted_time = self.format_listen_time(total_listen_time)

        self.now_stats.setText(f"鎾斁 {play_count} 娆?路 绱 {formatted_time}")

    def reset_playback_stats_session(self) -> None:
        self.last_recorded_position = 0
        self.pending_listen_ms = 0
        self.current_session_listen_ms = 0
        self.play_count_marked = False

    def record_listen_progress(self, position: int) -> None:
        if not self.current_song_path:
            self.last_recorded_position = position
            return

        if self.media_player.playbackState() != QMediaPlayer.PlaybackState.PlayingState:
            self.last_recorded_position = position
            return

        if self.last_recorded_position <= 0:
            self.last_recorded_position = position
            return

        delta = position - self.last_recorded_position
        self.last_recorded_position = position

        if delta <= 0:
            return

        if delta > 5000:
            return

        self.pending_listen_ms += delta
        self.current_session_listen_ms += delta

        self.mark_current_song_played_if_needed()

        if self.pending_listen_ms >= 10000:
            self.flush_current_listen_time()

    def mark_current_song_played_if_needed(self) -> None:
        if self.play_count_marked:
            return

        if not self.current_song_path:
            return

        threshold = 30000

        if self.current_duration > 0:
            threshold = min(30000, max(8000, int(self.current_duration * 0.3)))

        if self.current_session_listen_ms < threshold:
            return

        stats = self.get_song_stats(self.current_song_path)

        if not stats:
            return

        stats["play_count"] = int(stats.get("play_count", 0)) + 1
        stats["last_played"] = int(time.time())

        self.play_count_marked = True
        self.save_song_stats()
        self.save_playback_session()
        self.update_current_song_stats_label()
        self.update_side_info_panel()

        print("鏈鎾斁宸茶鍏ユ挱鏀炬鏁帮細", self.current_song_path)

    def flush_current_listen_time(self) -> None:
        if not self.current_song_path:
            self.pending_listen_ms = 0
            return

        saved_seconds = self.pending_listen_ms // 1000
        self.pending_listen_ms = self.pending_listen_ms % 1000

        if saved_seconds <= 0:
            return

        stats = self.get_song_stats(self.current_song_path)

        if not stats:
            return

        stats["total_listen_time"] = int(stats.get("total_listen_time", 0)) + int(saved_seconds)
        stats["last_played"] = int(time.time())

        self.save_song_stats()
        self.update_current_song_stats_label()
        self.update_side_info_panel()

        print(f"宸茬疮璁″惉姝屾椂闀匡細{saved_seconds} 绉?)

    def load_lyrics_bindings(self) -> dict:
        if not self.lyrics_bindings_file.exists():
            return {}

        try:
            with self.lyrics_bindings_file.open("r", encoding="utf-8") as file:
                raw_bindings = json.load(file)

            if not isinstance(raw_bindings, dict):
                return {}

            bindings = {}

            for song_path, lyric_path in raw_bindings.items():
                normalized_song_path = self.normalize_song_path(str(song_path))
                normalized_lyric_path = self.normalize_song_path(str(lyric_path))

                if not normalized_song_path or not normalized_lyric_path:
                    continue

                if not Path(normalized_lyric_path).exists():
                    continue

                bindings[normalized_song_path] = normalized_lyric_path

            return bindings

        except Exception as error:
            print("璇诲彇姝岃瘝缁戝畾澶辫触锛?, error)
            return {}

    def save_lyrics_bindings(self) -> None:
        self.lyrics_bindings_file.parent.mkdir(parents=True, exist_ok=True)

        with self.lyrics_bindings_file.open("w", encoding="utf-8") as file:
            json.dump(self.lyrics_bindings, file, ensure_ascii=False, indent=2)

        print("姝岃瘝缁戝畾宸蹭繚瀛橈細", self.lyrics_bindings_file)

    def get_bound_lyrics_path(self, song_path: str | None) -> str:
        normalized_song_path = self.normalize_song_path(song_path)

        if not normalized_song_path:
            return ""

        lyric_path = self.lyrics_bindings.get(normalized_song_path, "")

        if not lyric_path:
            return ""

        normalized_lyric_path = self.normalize_song_path(lyric_path)

        if not Path(normalized_lyric_path).exists():
            self.lyrics_bindings.pop(normalized_song_path, None)
            self.save_lyrics_bindings()
            return ""

        return normalized_lyric_path

    def get_song_cache_path(self, song_path: str | None, cache_dir: Path, suffix: str) -> Path | None:
        normalized_song_path = self.normalize_song_path(song_path)

        if not normalized_song_path:
            return None

        digest = hashlib.sha1(normalized_song_path.lower().encode("utf-8")).hexdigest()
        return cache_dir / f"{digest}{suffix}"

    def clear_lyrics_cache_for_song(self, song_path: str | None) -> None:
        cache_path = self.get_song_cache_path(song_path, self.lyrics_cache_dir, ".lrc")

        if not cache_path:
            return

        missing_path = cache_path.with_suffix(".missing")

        for path in (cache_path, missing_path):
            try:
                if path.exists():
                    path.unlink()
                    print("宸插垹闄ゆ瓕璇嶇紦瀛橈細", path)
            except Exception as error:
                print("鍒犻櫎姝岃瘝缂撳瓨澶辫触锛?, error)

    def clear_cover_cache_for_song(self, song_path: str | None) -> None:
        cache_path = self.get_song_cache_path(song_path, self.cover_cache_dir, ".jpg")

        if not cache_path:
            return

        missing_path = cache_path.with_suffix(".missing")

        for path in (cache_path, missing_path):
            try:
                if path.exists():
                    path.unlink()
                    print("宸插垹闄ゅ皝闈㈢紦瀛橈細", path)
            except Exception as error:
                print("鍒犻櫎灏侀潰缂撳瓨澶辫触锛?, error)

    def get_selected_real_song_data(self) -> dict | None:
        item = self.song_list.currentItem()
        return self.get_song_data_from_item(item)

    def reload_selected_song_lyrics(self, ignore_binding: bool = False) -> None:
        song_data = self.get_selected_real_song_data()

        if not song_data:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        song_path = self.normalize_song_path(song_data.get("path", ""))
        title = song_data.get("title", "鏈煡姝屾洸")
        artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)

        self.load_lyrics_for_song(
            file_path=song_path,
            title=title,
            artist=artist,
            ignore_binding=ignore_binding,
        )

    def bind_selected_song_lyrics(self) -> None:
        song_data = self.get_selected_real_song_data()

        if not song_data:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        song_path = self.normalize_song_path(song_data.get("path", ""))

        if not song_path:
            QMessageBox.information(self, "鎻愮ず", "杩欓姝屾病鏈夋湁鏁堟枃浠惰矾寰勩€?)
            return

        lyric_file, _ = QFileDialog.getOpenFileName(
            self,
            "閫夋嫨 LRC 姝岃瘝鏂囦欢",
            str(Path(song_path).parent),
            "LRC Lyrics (*.lrc);;All Files (*)",
        )

        if not lyric_file:
            return

        lyric_path = self.normalize_song_path(lyric_file)
        lyrics = self.parse_lrc_file(Path(lyric_path))

        if not lyrics:
            QMessageBox.warning(
                self,
                "姝岃瘝涓嶅彲鐢?,
                "杩欎釜 .lrc 鏂囦欢娌℃湁瑙ｆ瀽鍑烘湁鏁堟椂闂磋酱锛岃鎹竴涓甫鏃堕棿杞寸殑 LRC 鏂囦欢銆?,
            )
            return

        self.lyrics_bindings[song_path] = lyric_path
        self.save_lyrics_bindings()
        self.clear_lyrics_cache_for_song(song_path)

        self.current_lyrics = lyrics
        self.displayed_lyrics_song_path = song_path
        self.lyrics_view.set_lyrics(self.current_lyrics)
        self.sync_full_lyrics_from_current()
        self.set_lyrics_status("宸叉墜鍔ㄧ粦瀹氭瓕璇?)
        self.update_side_info_panel()

        QMessageBox.information(self, "缁戝畾鎴愬姛", "宸蹭负褰撳墠姝屾洸缁戝畾杩欎釜 LRC 姝岃瘝鏂囦欢銆?)
        print("宸叉墜鍔ㄧ粦瀹氭瓕璇嶏細", song_path, "->", lyric_path)

    def unbind_selected_song_lyrics(self) -> None:
        song_data = self.get_selected_real_song_data()

        if not song_data:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        song_path = self.normalize_song_path(song_data.get("path", ""))

        if not song_path:
            return

        if song_path not in self.lyrics_bindings:
            QMessageBox.information(self, "鎻愮ず", "杩欓姝屽綋鍓嶆病鏈夋墜鍔ㄧ粦瀹氭瓕璇嶃€?)
            return

        self.lyrics_bindings.pop(song_path, None)
        self.save_lyrics_bindings()

        self.set_lyrics_status("宸插彇娑堟墜鍔ㄦ瓕璇嶇粦瀹?)
        self.reload_selected_song_lyrics(ignore_binding=True)

        print("宸插彇娑堟瓕璇嶇粦瀹氾細", song_path)

    def force_search_selected_lyrics(self) -> None:
        song_data = self.get_selected_real_song_data()

        if not song_data:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        song_path = self.normalize_song_path(song_data.get("path", ""))

        self.clear_lyrics_cache_for_song(song_path)
        self.reload_selected_song_lyrics(ignore_binding=True)

        print("宸叉竻闄ゆ瓕璇嶇紦瀛樺苟閲嶆柊鎼滅储锛?, song_path)

    def force_search_selected_cover(self) -> None:
        song_data = self.get_selected_real_song_data()

        if not song_data:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        song_path = self.normalize_song_path(song_data.get("path", ""))
        title = song_data.get("title", "鏈煡姝屾洸")
        artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
        album = song_data.get("album", "鏈煡涓撹緫")

        self.clear_cover_cache_for_song(song_path)

        self.update_cover(
            file_path=song_path,
            title=title,
            artist=artist,
            album=album,
        )

        print("宸叉竻闄ゅ皝闈㈢紦瀛樺苟閲嶆柊鎼滅储锛?, song_path)

    def save_settings(self) -> None:
        self.settings_file.parent.mkdir(parents=True, exist_ok=True)

        settings = {
            "volume": max(0, min(100, int(self.current_volume))),
            "play_mode": self.play_mode,
        }

        with self.settings_file.open("w", encoding="utf-8") as file:
            json.dump(settings, file, ensure_ascii=False, indent=2)

        print("璁剧疆宸蹭繚瀛橈細", settings)

    def get_active_info_song_path(self) -> str:
        if self.browsing_song_path:
            return self.normalize_song_path(self.browsing_song_path)

        return self.normalize_song_path(self.current_song_path)

    def set_lyrics_status(self, message: str) -> None:
        print("姝岃瘝鐘舵€侊細", message)

        if hasattr(self, "lyrics_status_label"):
            self.lyrics_status_label.setText(f"姝岃瘝锛歿message}")

        if hasattr(self, "full_lyrics_status"):
            self.full_lyrics_status.setText(message)

        if hasattr(self, "side_lyrics_status_value"):
            self.side_lyrics_status_value.setText(message)

        self.sync_immersive_lyrics()

        QApplication.processEvents()

    def load_song_for_playback(self, song_data: dict | None) -> None:
        if not isinstance(song_data, dict):
            return

        if song_data.get("demo"):
            return

        title = song_data.get("title", "鏈煡姝屾洸")
        artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
        file_path = song_data.get("path", "")

        if not file_path:
            return

        normalized_path = self.normalize_song_path(file_path)

        if not normalized_path:
            return

        current_normalized_path = self.normalize_song_path(self.current_song_path)

        if current_normalized_path == normalized_path and self.media_player.source().toString():
            return

        self.flush_current_listen_time()

        self.current_song_path = normalized_path
        self.current_duration = 0
        self.reset_playback_stats_session()

        self.bottom_song_title.setText(title)
        self.bottom_song_artist.setText(artist)

        self.media_player.stop()
        self.media_player.setSource(QUrl.fromLocalFile(self.current_song_path))
        self.progress_slider.setValue(0)

        print("宸插垏鎹㈡挱鏀惧櫒褰撳墠姝屾洸锛?, title, "-", artist)
        self.sync_immersive_lyrics()
        print("鏂囦欢璺緞锛?, self.current_song_path)
        print("宸茶缃?source锛?, self.media_player.source().toString())

    def select_song(self, item: QListWidgetItem) -> None:
        song_data = item.data(Qt.ItemDataRole.UserRole)

        if isinstance(song_data, dict):
            title = song_data.get("title", "鏈煡姝屾洸")
            artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
            album = song_data.get("album", "鏈煡涓撹緫")
            file_path = song_data.get("path", "")
        else:
            text = item.text()
            parts = [part.strip() for part in text.split("路")]

            title = parts[0] if len(parts) > 0 else "鏈煡姝屾洸"
            artist = parts[1] if len(parts) > 1 else "鏈煡鑹烘湳瀹?
            album = parts[2] if len(parts) > 2 else "鏈煡涓撹緫"
            file_path = ""

        print(f"浣犳鍦ㄦ祻瑙堬細{title} - {artist}")

        if file_path:
            self.browsing_song_path = self.normalize_song_path(file_path)
            self.browsing_song_data = song_data if isinstance(song_data, dict) else None
        else:
            self.browsing_song_path = None
            self.browsing_song_data = None

        self.now_song_title.setText(title)
        self.now_artist.setText(f"{artist} 路 {album}")

        self.update_cover(
            file_path=self.browsing_song_path,
            title=title,
            artist=artist,
            album=album,
        )

        self.load_lyrics_for_song(
            file_path=self.browsing_song_path,
            title=title,
            artist=artist,
        )

        self.setWindowTitle(f"娴忚锛歿title} - HushPlayer")
        self.update_like_button()
        self.update_side_info_panel()
        self.update_current_song_stats_label()
        self.update_side_info_panel()

        if self.browsing_song_path:
            print(f"娴忚鏂囦欢璺緞锛歿self.browsing_song_path}")
            print("鍗曞嚮鍙祻瑙堬紝涓嶄細鎵撴柇褰撳墠鎾斁銆傚弻鍑绘墠浼氭挱鏀捐繖棣栨瓕銆?)
        else:
            print("杩欐槸婕旂ず姝屾洸锛屾病鏈夌湡瀹為煶涔愭枃浠躲€?)

    def reset_now_playing_info(self) -> None:
        self.flush_current_listen_time()

        self.current_song_path = None
        self.browsing_song_path = None
        self.browsing_song_data = None

        self.current_duration = 0
        self.current_lyrics = []

        self.reset_playback_stats_session()

        self.media_player.stop()
        self.media_player.setSource(QUrl())
        self.progress_slider.setValue(0)

        self.now_song_title.setText("杩樻病鏈夋挱鏀鹃煶涔?)
        self.now_artist.setText("璇烽€夋嫨涓€棣栨瓕鏇?)

        if hasattr(self, "now_stats"):
            self.now_stats.setText("鎾斁 0 娆?路 绱 0:00")

        if hasattr(self, "lyrics_status_label"):
            self.lyrics_status_label.setText("姝岃瘝锛氱瓑寰呴€夋嫨姝屾洸")

        self.bottom_song_title.setText("鏈挱鏀?)
        self.bottom_song_artist.setText("璇烽€夋嫨涓€棣栭煶涔?)
        self.lyrics_view.set_placeholder("杩欓噷浼氭樉绀烘瓕璇?, "鏀寔鏈湴 .lrc 鍜岃仈缃戝悓姝ユ瓕璇?)
        self.reset_cover()
        self.setWindowTitle("HushPlayer")
        self.update_like_button()
        self.update_side_info_panel()

    def select_first_available_song(self) -> None:
        visible_rows = self.get_visible_rows()

        if not visible_rows:
            self.reset_now_playing_info()
            return

        first_row = visible_rows[0]
        self.song_list.setCurrentRow(first_row)
        first_item = self.song_list.item(first_row)

        if first_item:
            self.select_song(first_item)

    def remove_selected_song(self) -> None:
        if (
            hasattr(self, "library_content_stack")
            and hasattr(self, "category_list")
            and self.library_content_stack.currentWidget() is self.category_list
        ):
            print("褰撳墠鏄垎绫诲垪琛紝璇疯繘鍏ユ瓕鎵嬫垨涓撹緫鐨勬瓕鏇插垪琛ㄥ悗鍐嶇Щ闄ゆ瓕鏇层€?)
            return

        current_item = self.song_list.currentItem()

        if current_item is None:
            print("娌℃湁閫変腑鐨勬瓕鏇诧紝鏃犳硶绉婚櫎銆?)
            return

        song_data = current_item.data(Qt.ItemDataRole.UserRole)

        if isinstance(song_data, dict) and song_data.get("demo"):
            print("婕旂ず姝屾洸涓嶉渶瑕佺Щ闄ゃ€?)
            return

        removed_path = ""

        if isinstance(song_data, dict):
            removed_path = song_data.get("path", "")

        removed_row = self.song_list.row(current_item)
        removed_title = current_item.text()

        print("鍑嗗浠庨煶涔愬簱绉婚櫎锛?, removed_title)
        print("娉ㄦ剰锛氬彧绉婚櫎闊充箰搴撹褰曪紝涓嶅垹闄ょ湡瀹炴枃浠躲€?)

        taken_item = self.song_list.takeItem(removed_row)

        if taken_item:
            del taken_item

        self.remove_song_from_library_source(removed_path)
        self.refresh_library_browser()
        self.filter_song_list(self.search_input.text())
        self.save_music_library()

        if removed_path and self.current_song_path:
            try:
                same_song = Path(removed_path).resolve() == Path(self.current_song_path).resolve()
            except Exception:
                same_song = removed_path == self.current_song_path

            if same_song:
                self.reset_now_playing_info()

        if self.song_list.count() == 0:
            self.add_demo_songs()
            self.save_music_library()
            self.reset_now_playing_info()
            return

        self.select_first_available_song()

        print("宸蹭粠闊充箰搴撶Щ闄わ細", removed_title)

    def clean_missing_songs(self) -> None:
        removed_count = 0
        removed_current_song = False

        for row in range(self.song_list.count() - 1, -1, -1):
            item = self.song_list.item(row)
            song_data = item.data(Qt.ItemDataRole.UserRole)

            if not isinstance(song_data, dict):
                continue

            if song_data.get("demo"):
                continue

            path_text = song_data.get("path", "")

            if not path_text:
                continue

            path = Path(path_text)

            if path.exists():
                continue

            print("娓呯悊澶辨晥姝屾洸锛?, item.text())
            print("澶辨晥璺緞锛?, path_text)

            if self.current_song_path:
                try:
                    if Path(self.current_song_path).resolve() == path.resolve():
                        removed_current_song = True
                except Exception:
                    if self.current_song_path == path_text:
                        removed_current_song = True

            taken_item = self.song_list.takeItem(row)

            if taken_item:
                del taken_item

            removed_count += 1

        source_removed_count = self.remove_missing_songs_from_library_source()
        removed_count = max(removed_count, source_removed_count)
        self.refresh_library_browser()
        self.filter_song_list(self.search_input.text())
        self.save_music_library()

        if removed_current_song:
            self.reset_now_playing_info()

        if self.song_list.count() == 0:
            self.add_demo_songs()
            self.save_music_library()
            self.reset_now_playing_info()
        else:
            current_item = self.song_list.currentItem()

            if current_item is None or current_item.isHidden():
                self.select_first_available_song()

        print(f"娓呯悊瀹屾垚锛岀Щ闄ゅけ鏁堟瓕鏇叉暟閲忥細{removed_count}")

    def reset_cover(self) -> None:
        self.cover_label.clear()
        self.cover_label.setPixmap(QPixmap())
        self.cover_label.setText("Hush")

    def cleanup_thread_reference(self, thread: QThread, kind: str) -> None:
        try:
            if kind == "cover" and thread in self.cover_threads:
                self.cover_threads.remove(thread)
            elif kind == "lyrics" and thread in self.lyrics_threads:
                self.lyrics_threads.remove(thread)
        except Exception:
            pass

    def cleanup_worker_reference(self, worker: QObject, kind: str) -> None:
        try:
            if kind == "cover" and worker in self.cover_workers:
                self.cover_workers.remove(worker)
            elif kind == "lyrics" and worker in self.lyrics_workers:
                self.lyrics_workers.remove(worker)
        except Exception:
            pass

    def start_cover_worker(
        self,
        file_path: str,
        title: str,
        artist: str,
        album: str,
    ) -> None:
        self.cover_request_id += 1
        request_id = str(self.cover_request_id)
        self.active_cover_request_id = request_id

        worker = CoverSearchWorker(
            request_id=request_id,
            file_path=file_path,
            title=title,
            artist=artist,
            album=album,
            cover_cache_dir=str(self.cover_cache_dir),
            http_headers=self.http_headers,
        )

        self.cover_workers.append(worker)

        self.lyrics_workers.append(worker)

        thread = QThread(self)
        worker.moveToThread(thread)

        thread.started.connect(worker.run)
        worker.status_changed.connect(self.on_cover_worker_status)
        worker.finished.connect(self.on_cover_worker_finished)
        worker.finished.connect(thread.quit)
        worker.finished.connect(lambda request_id, result, worker=worker: self.cleanup_worker_reference(worker, "cover"))
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(lambda thread=thread: self.cleanup_thread_reference(thread, "cover"))

        self.cover_threads.append(thread)
        thread.start()

    def on_cover_worker_status(self, request_id: str, message: str) -> None:
        if request_id != self.active_cover_request_id:
            return

        print("灏侀潰鐘舵€侊細", message)
        self.cover_label.setText(message)

    def on_cover_worker_finished(self, request_id: str, result: object) -> None:
        if request_id != self.active_cover_request_id:
            print("宸插拷鐣ヨ繃鏈熷皝闈㈢粨鏋滐細", request_id)
            return

        if not isinstance(result, dict):
            self.cover_label.setText("灏侀潰鍔犺浇澶辫触")
            return

        if result.get("ok"):
            cover_path = result.get("cover_path", "")

            if cover_path and self.show_cover_from_file(Path(cover_path)):
                print("宸插姞杞藉悗鍙板皝闈細", cover_path)
                return

        message = result.get("message", "鏈壘鍒板皝闈?)
        print("灏侀潰鎼滅储缁撴潫锛?, message)
        self.cover_label.clear()
        self.cover_label.setPixmap(QPixmap())
        self.cover_label.setText("鏃犲皝闈?)

    def start_lyrics_worker(
        self,
        file_path: str,
        title: str,
        artist: str,
        album: str,
    ) -> None:
        self.lyrics_request_id += 1
        request_id = str(self.lyrics_request_id)
        self.active_lyrics_request_id = request_id

        worker = LyricsSearchWorker(
            request_id=request_id,
            file_path=file_path,
            title=title,
            artist=artist,
            album=album,
            lyrics_cache_dir=str(self.lyrics_cache_dir),
            http_headers=self.http_headers,
        )

        thread = QThread(self)
        worker.moveToThread(thread)

        thread.started.connect(worker.run)
        worker.status_changed.connect(self.on_lyrics_worker_status)
        worker.finished.connect(self.on_lyrics_worker_finished)
        worker.finished.connect(thread.quit)
        worker.finished.connect(lambda request_id, result, worker=worker: self.cleanup_worker_reference(worker, "lyrics"))
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(lambda thread=thread: self.cleanup_thread_reference(thread, "lyrics"))

        self.lyrics_threads.append(thread)
        thread.start()

    def on_lyrics_worker_status(self, request_id: str, message: str) -> None:
        if request_id != self.active_lyrics_request_id:
            return

        self.set_lyrics_status(message)

    def on_lyrics_worker_finished(self, request_id: str, result: object) -> None:
        if request_id != self.active_lyrics_request_id:
            print("宸插拷鐣ヨ繃鏈熸瓕璇嶇粨鏋滐細", request_id)
            return

        if not isinstance(result, dict):
            self.lyrics_view.set_placeholder("姝岃瘝鍔犺浇澶辫触", "")
            self.set_lyrics_status("姝岃瘝鍔犺浇澶辫触")
            return

        if result.get("ok"):
            lyrics_path = result.get("lyrics_path", "")
            song_path = result.get("song_path", "")

            if not lyrics_path:
                self.lyrics_view.set_placeholder("姝岃瘝璺緞涓虹┖", "")
                self.set_lyrics_status("姝岃瘝鍔犺浇澶辫触")
                return

            lyrics = self.parse_lrc_file(Path(lyrics_path))

            if not lyrics:
                self.lyrics_view.set_placeholder("姝岃瘝鏍煎紡鏃犳硶瑙ｆ瀽", "鍙互鎹㈡垚鏈湴 .lrc 姝岃瘝")
                self.set_lyrics_status("姝岃瘝瑙ｆ瀽澶辫触")
                return

            self.current_lyrics = lyrics
            self.displayed_lyrics_song_path = self.normalize_song_path(song_path)
            self.lyrics_view.set_lyrics(self.current_lyrics)
            self.sync_full_lyrics_from_current()

            source = result.get("source", "")

            if source == "local":
                self.set_lyrics_status("宸插姞杞芥湰鍦版瓕璇?)
            elif source == "cache":
                self.set_lyrics_status("宸插姞杞界紦瀛樻瓕璇?)
            elif source == "online":
                self.set_lyrics_status("宸插姞杞借仈缃戞瓕璇?)
            else:
                self.set_lyrics_status("宸插姞杞芥瓕璇?)

            print("宸插姞杞藉悗鍙版瓕璇嶏細", lyrics_path)
            print("姝岃瘝琛屾暟锛?, len(self.current_lyrics))
            return

        message = result.get("message", "鏈壘鍒板悓姝ユ瓕璇?)
        source = result.get("source", "")

        if source == "missing_cache":
            self.lyrics_view.set_placeholder("杩戞湡宸叉悳绱㈣繃锛屾湭鎵惧埌鍚屾姝岃瘝", "涔嬪悗浼氳嚜鍔ㄩ殧鍑犲ぉ鍐嶈瘯")
            self.set_lyrics_status("杩戞湡宸叉悳绱㈣繃锛屾湭鎵惧埌姝岃瘝")
        else:
            self.lyrics_view.set_placeholder("鏈壘鍒板悓姝ユ瓕璇?, "鍙互鎵嬪姩鏀句竴涓悓鍚?.lrc 鏂囦欢鍒版瓕鏇叉梺杈?)
            self.set_lyrics_status(str(message))

        self.current_lyrics = []

    def update_cover(
        self,
        file_path: str | None,
        title: str,
        artist: str,
        album: str,
    ) -> None:
        self.reset_cover()

        if not file_path:
            return

        self.cover_label.setText("姝ｅ湪鏌ユ壘灏侀潰")
        self.start_cover_worker(
            file_path=self.normalize_song_path(file_path),
            title=title,
            artist=artist,
            album=album,
        )

    def get_cover_cache_path(self, path: Path) -> Path:
        normalized_path = str(path.resolve()).lower()
        digest = hashlib.sha1(normalized_path.encode("utf-8")).hexdigest()
        return self.cover_cache_dir / f"{digest}.jpg"

    def show_cover_from_file(self, path: Path) -> bool:
        pixmap = QPixmap(str(path))

        if pixmap.isNull():
            return False

        self.show_cover_pixmap(pixmap)
        return True

    def show_cover_from_bytes(self, data: bytes) -> bool:
        pixmap = QPixmap()
        loaded = pixmap.loadFromData(data)

        if not loaded or pixmap.isNull():
            return False

        self.show_cover_pixmap(pixmap)
        return True

    def show_cover_pixmap(self, pixmap: QPixmap) -> None:
        scaled_pixmap = pixmap.scaled(
            248,
            248,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )

        self.cover_label.setText("")
        self.cover_label.setPixmap(scaled_pixmap)

    def extract_album_cover(self, path: Path) -> bytes | None:
        try:
            audio = MutagenFile(path)

            if audio is None:
                return None

            if hasattr(audio, "pictures") and audio.pictures:
                return audio.pictures[0].data

            if audio.tags is None:
                return None

            for key in audio.tags.keys():
                if str(key).startswith("APIC"):
                    tag = audio.tags[key]

                    if hasattr(tag, "data"):
                        return tag.data

            mp4_cover = audio.tags.get("covr")
            if mp4_cover:
                return bytes(mp4_cover[0])

        except Exception as error:
            print("璇诲彇鍐呭祵灏侀潰澶辫触锛?, path)
            print(error)

        return None

    def find_folder_cover(self, music_path: Path) -> Path | None:
        folder = music_path.parent

        possible_names = [
            "cover.jpg",
            "cover.jpeg",
            "cover.png",
            "folder.jpg",
            "folder.jpeg",
            "folder.png",
            "front.jpg",
            "front.jpeg",
            "front.png",
            "album.jpg",
            "album.jpeg",
            "album.png",
        ]

        for name in possible_names:
            candidate = folder / name

            if candidate.exists():
                return candidate

        return None

    def fetch_online_cover(self, title: str, artist: str, album: str) -> bytes | None:
        cleaned_title = self.clean_search_text(title)
        cleaned_artist = self.clean_search_text(artist)
        cleaned_album = self.clean_search_text(album)

        if not cleaned_artist:
            print("缂哄皯姝屾墜淇℃伅锛岃烦杩囪仈缃戝皝闈㈡煡璇€?)
            return None

        if cleaned_album and cleaned_album not in {"鏈煡涓撹緫", "unknown album"}:
            queries = [
                f'release:"{cleaned_album}" AND artist:"{cleaned_artist}"',
                f'{cleaned_album} {cleaned_artist}',
            ]
        else:
            queries = [
                f'recording:"{cleaned_title}" AND artist:"{cleaned_artist}"',
                f'{cleaned_title} {cleaned_artist}',
            ]

        for query in queries:
            release_ids = self.search_musicbrainz_release_ids(query)

            for release_id in release_ids:
                cover_data = self.fetch_cover_art_archive(release_id)

                if cover_data:
                    return cover_data

        return None

    def clean_search_text(self, text: str) -> str:
        text = text.strip()

        if text in {"鏈煡姝屾洸", "鏈煡鑹烘湳瀹?, "鏈煡涓撹緫"}:
            return ""

        return text

    def load_metadata_cache(self) -> dict:
        if not self.metadata_cache_file.exists():
            return {}

        try:
            with self.metadata_cache_file.open("r", encoding="utf-8") as file:
                data = json.load(file)

            if isinstance(data, dict):
                return data

        except Exception as error:
            print("璇诲彇姝屾洸淇℃伅鍖归厤缂撳瓨澶辫触锛?, error)

        return {}

    def save_metadata_cache(self) -> None:
        try:
            self.metadata_cache_file.parent.mkdir(parents=True, exist_ok=True)

            with self.metadata_cache_file.open("w", encoding="utf-8") as file:
                json.dump(self.metadata_cache, file, ensure_ascii=False, indent=2)

        except Exception as error:
            print("淇濆瓨姝屾洸淇℃伅鍖归厤缂撳瓨澶辫触锛?, error)

    def get_metadata_cache_key(self, song_data: dict) -> str:
        song_path = self.normalize_song_path(song_data.get("path", ""))

        if song_path:
            return hashlib.sha1(song_path.encode("utf-8")).hexdigest()

        fallback = f"{song_data.get('title', '')}|{song_data.get('artist', '')}|{song_data.get('album', '')}"
        return hashlib.sha1(fallback.encode("utf-8")).hexdigest()

    def build_metadata_search_query(self, song_data: dict) -> str:
        title = self.clean_search_text(str(song_data.get("title", "") or ""))
        artist = self.clean_search_text(str(song_data.get("artist", "") or ""))
        album = self.clean_search_text(str(song_data.get("album", "") or ""))
        path_text = str(song_data.get("path", "") or "")

        if not title and path_text:
            title = Path(path_text).stem

        if title and artist:
            return f'recording:"{title}" AND artist:"{artist}"'

        if title:
            return f'recording:"{title}"'

        if album and artist:
            return f'{album} {artist}'

        if path_text:
            return Path(path_text).stem

        return " ".join(part for part in [title, artist, album] if part).strip()

    def search_musicbrainz_metadata(self, song_data: dict) -> list[dict]:
        query = self.build_metadata_search_query(song_data)

        if not query:
            return []

        cache_key = self.get_metadata_cache_key(song_data)
        cached = self.metadata_cache.get(cache_key)

        if isinstance(cached, dict) and cached.get("query") == query:
            candidates = cached.get("candidates", [])

            if isinstance(candidates, list):
                print("浣跨敤姝屾洸淇℃伅鍖归厤缂撳瓨锛?, query)
                return candidates

        self.wait_for_musicbrainz_rate_limit()

        response = requests.get(
            "https://musicbrainz.org/ws/2/recording/",
            params={
                "query": query,
                "fmt": "json",
                "limit": 10,
            },
            headers={
                "User-Agent": "HushPlayer/0.5 metadata matcher (local personal music player)",
                "Accept": "application/json",
            },
            timeout=8,
        )
        response.raise_for_status()
        candidates = self.parse_musicbrainz_candidates(response.json())

        self.metadata_cache[cache_key] = {
            "query": query,
            "candidates": candidates,
            "queried_at": int(time.time()),
        }
        self.save_metadata_cache()

        return candidates

    def parse_musicbrainz_candidates(self, response_json: dict) -> list[dict]:
        recordings = response_json.get("recordings", [])

        if not isinstance(recordings, list):
            return []

        candidates = []

        for recording in recordings[:10]:
            if not isinstance(recording, dict):
                continue

            title = str(recording.get("title", "") or "").strip()
            recording_id = str(recording.get("id", "") or "").strip()

            if not title or not recording_id:
                continue

            artist = ""
            artist_credit = recording.get("artist-credit", [])

            if isinstance(artist_credit, list):
                artist_names = []

                for credit in artist_credit:
                    if not isinstance(credit, dict):
                        continue

                    artist_data = credit.get("artist", {})

                    if isinstance(artist_data, dict):
                        artist_name = str(artist_data.get("name", "") or "").strip()

                        if artist_name:
                            artist_names.append(artist_name)

                artist = " / ".join(artist_names)

            album = ""
            release_date = ""
            release_id = ""
            releases = recording.get("releases", recording.get("release-list", []))

            if isinstance(releases, list) and releases:
                first_release = releases[0]

                if isinstance(first_release, dict):
                    album = str(first_release.get("title", "") or "").strip()
                    release_date = str(first_release.get("date", "") or "").strip()
                    release_id = str(first_release.get("id", "") or "").strip()

            candidates.append(
                {
                    "title": title,
                    "artist": artist or "鏈煡鑹烘湳瀹?,
                    "album": album or "鏈煡涓撹緫",
                    "release_date": release_date,
                    "score": recording.get("score", ""),
                    "musicbrainz_recording_id": recording_id,
                    "musicbrainz_release_id": release_id,
                }
            )

        return candidates

    def show_metadata_candidates_dialog(self, song_data: dict, candidates: list[dict]) -> dict | None:
        dialog = MetadataMatchDialog(song_data, candidates, self)

        if dialog.exec() != QDialog.DialogCode.Accepted:
            return None

        return dialog.selected_candidate

    def apply_metadata_candidate(self, song_data: dict, candidate: dict) -> None:
        song_path = self.normalize_song_path(song_data.get("path", ""))

        if not song_path:
            return

        updates = {
            "title": candidate.get("title", song_data.get("title", "")),
            "artist": candidate.get("artist", song_data.get("artist", "")),
            "album": candidate.get("album", song_data.get("album", "")),
            "musicbrainz_recording_id": candidate.get("musicbrainz_recording_id", ""),
            "musicbrainz_release_id": candidate.get("musicbrainz_release_id", ""),
        }

        if candidate.get("release_date"):
            updates["release_date"] = candidate.get("release_date", "")

        for library_song in getattr(self, "library_songs", []):
            if self.normalize_song_path(library_song.get("path", "")) == song_path:
                library_song.update(updates)
                break

        for row in range(self.song_list.count()):
            item = self.song_list.item(row)

            if item is None:
                continue

            item_data = item.data(Qt.ItemDataRole.UserRole)

            if not isinstance(item_data, dict):
                continue

            if self.normalize_song_path(item_data.get("path", "")) != song_path:
                continue

            item_data.update(updates)
            item.setData(Qt.ItemDataRole.UserRole, item_data)
            item.setText(
                f"{item_data.get('title', '')}    璺?   {item_data.get('artist', '')}    璺?   {item_data.get('album', '')}"
            )
            break

        self.save_music_library()
        self.refresh_library_browser()

        refreshed_item = self.find_song_item_by_path(song_path)

        if refreshed_item is not None:
            self.song_list.setCurrentItem(refreshed_item)
            self.select_song(refreshed_item)

        if self.normalize_song_path(self.current_song_path) == song_path:
            self.bottom_song_title.setText(str(updates.get("title", "")))
            self.bottom_song_artist.setText(str(updates.get("artist", "")))

        self.update_side_info_panel()
        self.update_like_button()

    def match_selected_song_metadata(self, item: QListWidgetItem | None = None) -> None:
        song_data = self.get_song_data_from_item(item or self.song_list.currentItem())

        if not song_data or song_data.get("demo"):
            QMessageBox.information(self, "鑱旂綉鍖归厤姝屾洸淇℃伅", "璇峰厛閫夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        progress = QProgressDialog("姝ｅ湪鑱旂綉鍖归厤姝屾洸淇℃伅...", None, 0, 0, self)
        progress.setWindowTitle("鑱旂綉鍖归厤姝屾洸淇℃伅")
        progress.setWindowModality(Qt.WindowModality.ApplicationModal)
        progress.setCancelButton(None)
        progress.setMinimumDuration(0)
        progress.show()
        QApplication.processEvents()

        try:
            candidates = self.search_musicbrainz_metadata(song_data)
        except requests.RequestException as error:
            progress.close()
            QMessageBox.warning(self, "鑱旂綉鍖归厤澶辫触", f"鑱旂綉鍖归厤澶辫触锛岃妫€鏌ョ綉缁溿€俓n\n{error}")
            return
        except Exception as error:
            progress.close()
            QMessageBox.warning(self, "鑱旂綉鍖归厤澶辫触", f"鑱旂綉鍖归厤姝屾洸淇℃伅澶辫触锛歕n\n{error}")
            return
        finally:
            progress.close()

        if not candidates:
            QMessageBox.information(self, "鑱旂綉鍖归厤姝屾洸淇℃伅", "娌℃湁鎵惧埌鍙潬鍖归厤缁撴灉銆?)
            return

        selected_candidate = self.show_metadata_candidates_dialog(song_data, candidates)

        if selected_candidate is None:
            return

        self.apply_metadata_candidate(song_data, selected_candidate)

    def wait_for_musicbrainz_rate_limit(self) -> None:
        now = time.time()
        elapsed = now - self.last_musicbrainz_request_time

        if elapsed < 1.1:
            time.sleep(1.1 - elapsed)

        self.last_musicbrainz_request_time = time.time()

    def search_musicbrainz_release_ids(self, query: str) -> list[str]:
        print("姝ｅ湪鎼滅储 MusicBrainz锛?, query)

        try:
            self.wait_for_musicbrainz_rate_limit()

            response = requests.get(
                "https://musicbrainz.org/ws/2/release/",
                params={
                    "query": query,
                    "fmt": "json",
                    "limit": 5,
                },
                headers=self.http_headers,
                timeout=10,
            )

            response.raise_for_status()
            data = response.json()

        except Exception as error:
            print("MusicBrainz 鎼滅储澶辫触锛?, error)
            return []

        releases = data.get("releases", [])
        release_ids = []

        for release in releases:
            release_id = release.get("id")
            title = release.get("title", "")
            score = release.get("score", "")

            if release_id:
                print(f"鎵惧埌鍊欓€変笓杈戯細{title} / score={score} / id={release_id}")
                release_ids.append(release_id)

        return release_ids

    def fetch_cover_art_archive(self, release_id: str) -> bytes | None:
        url = f"https://coverartarchive.org/release/{release_id}/front-500"
        print("姝ｅ湪鑾峰彇灏侀潰锛?, release_id)

        try:
            response = requests.get(
                url,
                headers={
                    "User-Agent": self.http_headers["User-Agent"],
                    "Accept": "image/*",
                },
                timeout=15,
                allow_redirects=True,
            )

            if response.status_code != 200:
                print("杩欎釜 release 娌℃湁鍙敤灏侀潰锛?, response.status_code)
                return None

            content_type = response.headers.get("Content-Type", "")

            if "image" not in content_type.lower():
                print("杩斿洖鍐呭涓嶆槸鍥剧墖锛?, content_type)
                return None

            return response.content

        except Exception as error:
            print("Cover Art Archive 鑾峰彇澶辫触锛?, error)
            return None

    def get_lyrics_cache_path(self, path: Path) -> Path:
        normalized_path = str(path.resolve()).lower()
        digest = hashlib.sha1(normalized_path.encode("utf-8")).hexdigest()
        return self.lyrics_cache_dir / f"{digest}.lrc"

    def get_audio_duration_seconds(self, path: Path) -> int:
        try:
            audio = MutagenFile(path)

            if audio is None:
                return 0

            info = getattr(audio, "info", None)

            if info is None:
                return 0

            length = getattr(info, "length", 0)

            if not length:
                return 0

            return int(round(float(length)))

        except Exception as error:
            print("璇诲彇姝屾洸鏃堕暱澶辫触锛?, path)
            print(error)
            return 0

    def normalize_match_text(self, text: str) -> str:
        text = self.clean_search_text(text).lower()
        text = re.sub(r"[\s\\-_.,锛屻€?锛?锛?锛?锛?\"鈥溾€濃€樷€?)\[\]{}銆愩€?>銆娿€?\\\\]+", "", text)
        return text

    def calculate_lyrics_result_score(
        self,
        result: dict,
        title: str,
        artist: str,
        album: str,
        duration_seconds: int,
    ) -> int:
        score = 0

        synced_lyrics = result.get("syncedLyrics")

        if not synced_lyrics:
            return -9999

        result_title = str(result.get("trackName", ""))
        result_artist = str(result.get("artistName", ""))
        result_album = str(result.get("albumName", ""))

        target_title = self.normalize_match_text(title)
        target_artist = self.normalize_match_text(artist)
        target_album = self.normalize_match_text(album)

        matched_title = self.normalize_match_text(result_title)
        matched_artist = self.normalize_match_text(result_artist)
        matched_album = self.normalize_match_text(result_album)

        if target_title and matched_title:
            if target_title == matched_title:
                score += 80
            elif target_title in matched_title or matched_title in target_title:
                score += 45

        if target_artist and matched_artist:
            if target_artist == matched_artist:
                score += 60
            elif target_artist in matched_artist or matched_artist in target_artist:
                score += 30

        if target_album and matched_album:
            if target_album == matched_album:
                score += 20
            elif target_album in matched_album or matched_album in target_album:
                score += 8

        result_duration = int(result.get("duration", 0) or 0)

        if duration_seconds > 0 and result_duration > 0:
            diff = abs(duration_seconds - result_duration)

            if diff <= 2:
                score += 30
            elif diff <= 5:
                score += 18
            elif diff <= 10:
                score += 8

        if synced_lyrics:
            score += 40

        return score

    def search_lrclib_synced_lyrics(
        self,
        title: str,
        artist: str,
        album: str,
        duration_seconds: int,
    ) -> str | None:
        cleaned_title = self.clean_search_text(title)
        cleaned_artist = self.clean_search_text(artist)
        cleaned_album = self.clean_search_text(album)

        if not cleaned_title:
            print("缂哄皯姝屾洸鍚嶏紝璺宠繃鑱旂綉姝岃瘝鎼滅储銆?)
            return None

        search_requests = []

        first_params = {
            "track_name": cleaned_title,
        }

        if cleaned_artist:
            first_params["artist_name"] = cleaned_artist

        if cleaned_album:
            first_params["album_name"] = cleaned_album

        search_requests.append(first_params)

        if cleaned_artist:
            search_requests.append(
                {
                    "q": f"{cleaned_title} {cleaned_artist}",
                }
            )

        search_requests.append(
            {
                "q": cleaned_title,
            }
        )

        best_result = None
        best_score = -9999

        for params in search_requests:
            try:
                print("姝ｅ湪鎼滅储 LRCLIB 姝岃瘝锛?, params)

                response = requests.get(
                    "https://lrclib.net/api/search",
                    params=params,
                    headers=self.http_headers,
                    timeout=12,
                )

                response.raise_for_status()
                results = response.json()

                if not isinstance(results, list):
                    continue

            except Exception as error:
                print("LRCLIB 鎼滅储澶辫触锛?, error)
                continue

            for result in results:
                if not isinstance(result, dict):
                    continue

                score = self.calculate_lyrics_result_score(
                    result=result,
                    title=title,
                    artist=artist,
                    album=album,
                    duration_seconds=duration_seconds,
                )

                result_title = result.get("trackName", "")
                result_artist = result.get("artistName", "")
                result_duration = result.get("duration", "")

                print(
                    "姝岃瘝鍊欓€夛細",
                    result_title,
                    "-",
                    result_artist,
                    "duration=",
                    result_duration,
                    "score=",
                    score,
                )

                if score > best_score:
                    best_score = score
                    best_result = result

            if best_result and best_score >= 110:
                break

        if not best_result:
            print("娌℃湁鎵惧埌鍚堥€傜殑鑱旂綉姝岃瘝銆?)
            return None

        synced_lyrics = best_result.get("syncedLyrics")

        if not synced_lyrics:
            print("鏈€浣崇粨鏋滄病鏈夊悓姝ユ瓕璇嶃€?)
            return None

        if best_score < 80:
            print("鑱旂綉姝岃瘝鍖归厤鍒嗘暟杩囦綆锛屽凡鏀惧純锛?, best_score)
            return None

        print(
            "宸插尮閰嶈仈缃戞瓕璇嶏細",
            best_result.get("trackName", ""),
            "-",
            best_result.get("artistName", ""),
            "score=",
            best_score,
        )

        return str(synced_lyrics).strip()

    def write_lyrics_cache(self, cache_path: Path, lyrics_text: str) -> bool:
        try:
            self.lyrics_cache_dir.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(lyrics_text, encoding="utf-8")
            print("姝岃瘝宸茬紦瀛橈細", cache_path)
            return True

        except Exception as error:
            print("鍐欏叆姝岃瘝缂撳瓨澶辫触锛?, error)
            return False

    def load_lyrics_for_song(
        self,
        file_path: str | None,
        title: str,
        artist: str,
        ignore_binding: bool = False,
    ) -> None:
        self.current_lyrics = []
        self.displayed_lyrics_song_path = self.normalize_song_path(file_path)
        self.lyrics_view.set_placeholder("姝ｅ湪鏌ユ壘姝岃瘝", "浼樺厛鎵嬪姩缁戝畾锛屽叾娆℃湰鍦版瓕璇嶏紝鐒跺悗缂撳瓨鍜岃仈缃?)
        self.set_lyrics_status("姝ｅ湪鏌ユ壘姝岃瘝")

        if not file_path:
            self.lyrics_view.set_placeholder("姝岃瘝鍔熻兘杩樻病鏈夋帴鍏ユ紨绀烘瓕鏇?, "")
            self.set_lyrics_status("婕旂ず姝屾洸鏃犳瓕璇?)
            return

        normalized_file_path = self.normalize_song_path(file_path)

        if not ignore_binding:
            bound_lyrics_path = self.get_bound_lyrics_path(normalized_file_path)

            if bound_lyrics_path:
                self.set_lyrics_status("姝ｅ湪璇诲彇鎵嬪姩缁戝畾姝岃瘝")
                lyrics = self.parse_lrc_file(Path(bound_lyrics_path))

                if lyrics:
                    self.current_lyrics = lyrics
                    self.displayed_lyrics_song_path = normalized_file_path
                    self.lyrics_view.set_lyrics(self.current_lyrics)
                    self.sync_full_lyrics_from_current()
                    self.set_lyrics_status("宸插姞杞芥墜鍔ㄧ粦瀹氭瓕璇?)

                    print("宸插姞杞芥墜鍔ㄧ粦瀹氭瓕璇嶏細", bound_lyrics_path)
                    print("姝岃瘝琛屾暟锛?, len(self.current_lyrics))
                    return

                self.set_lyrics_status("鎵嬪姩缁戝畾姝岃瘝瑙ｆ瀽澶辫触锛岀户缁嚜鍔ㄦ煡鎵?)
                print("鎵嬪姩缁戝畾姝岃瘝瑙ｆ瀽澶辫触锛?, bound_lyrics_path)

        album = "鏈煡涓撹緫"
        current_item = self.song_list.currentItem()

        if current_item:
            song_data = current_item.data(Qt.ItemDataRole.UserRole)

            if isinstance(song_data, dict):
                album = song_data.get("album", "鏈煡涓撹緫")

        self.start_lyrics_worker(
            file_path=normalized_file_path,
            title=title,
            artist=artist,
            album=album,
        )

    def find_lrc_file(self, music_path: Path, title: str, artist: str) -> Path | None:
        folder = music_path.parent

        candidates = [
            music_path.with_suffix(".lrc"),
            folder / f"{music_path.stem}.lrc",
            folder / f"{title}.lrc",
            folder / f"{artist} - {title}.lrc",
            folder / f"{title} - {artist}.lrc",
        ]

        seen = set()

        for candidate in candidates:
            normalized = str(candidate).lower()

            if normalized in seen:
                continue

            seen.add(normalized)

            if candidate.exists():
                return candidate

        for candidate in folder.glob("*.lrc"):
            if candidate.stem.lower() == music_path.stem.lower():
                return candidate

        return None

    def parse_lrc_file(self, lrc_path: Path) -> list[tuple[int, str]]:
        content = None

        for encoding in ("utf-8", "utf-8-sig", "gbk", "gb18030"):
            try:
                content = lrc_path.read_text(encoding=encoding)
                break
            except UnicodeDecodeError:
                continue
            except Exception as error:
                print("璇诲彇姝岃瘝鏂囦欢澶辫触锛?, error)
                return []

        if content is None:
            return []

        lyrics: list[tuple[int, str]] = []
        time_pattern = re.compile(r"\[(\d{1,2}):(\d{1,2})(?:\.(\d{1,3}))?\]")

        for raw_line in content.splitlines():
            line = raw_line.strip()

            if not line:
                continue

            matches = list(time_pattern.finditer(line))

            if not matches:
                continue

            lyric_text = time_pattern.sub("", line).strip()

            if not lyric_text:
                lyric_text = "鈾?

            for match in matches:
                minute = int(match.group(1))
                second = int(match.group(2))
                millisecond_text = match.group(3) or "0"

                if len(millisecond_text) == 1:
                    millisecond = int(millisecond_text) * 100
                elif len(millisecond_text) == 2:
                    millisecond = int(millisecond_text) * 10
                else:
                    millisecond = int(millisecond_text[:3])

                timestamp = minute * 60 * 1000 + second * 1000 + millisecond
                lyrics.append((timestamp, lyric_text))

        lyrics.sort(key=lambda item: item[0])
        return lyrics

    def play_selected_song(self, item: QListWidgetItem) -> None:
        self.select_song(item)

        song_data = item.data(Qt.ItemDataRole.UserRole)

        if not isinstance(song_data, dict):
            return

        self.load_song_for_playback(song_data)
        self.play_current_song()

    def play_current_song(self) -> None:
        if not self.current_song_path:
            current_item = self.song_list.currentItem()

            if current_item:
                song_data = current_item.data(Qt.ItemDataRole.UserRole)

                if isinstance(song_data, dict):
                    self.load_song_for_playback(song_data)

        if not self.current_song_path:
            self.lyrics_view.set_placeholder(
                "璇峰厛瀵煎叆骞堕€夋嫨涓€棣栫湡瀹炵殑鏈湴闊充箰",
                "鍗曞嚮娴忚锛屽弻鍑绘挱鏀?,
            )
            return

        print("鍑嗗鎾斁锛?, self.current_song_path)
        print("褰撳墠闊抽噺锛?, self.audio_output.volume())
        print("褰撳墠 source锛?, self.media_player.source().toString())

        self.last_recorded_position = self.media_player.position()
        self.media_player.play()
        self.play_btn.setText("鏆傚仠")

    def toggle_play(self) -> None:
        state = self.media_player.playbackState()
        print("褰撳墠鎾斁鐘舵€侊細", state)

        if state == QMediaPlayer.PlaybackState.PlayingState:
            self.media_player.pause()
            self.play_btn.setText("鎾斁")
        else:
            self.play_current_song()

    def toggle_play_mode(self) -> None:
        if self.play_mode == "list_loop":
            self.play_mode = "single_loop"
        elif self.play_mode == "single_loop":
            self.play_mode = "shuffle"
        else:
            self.play_mode = "list_loop"

        self.update_play_mode_button()
        self.save_settings()

    def update_play_mode_button(self) -> None:
        if not hasattr(self, "play_mode_btn"):
            return

        mode_text = {
            "list_loop": "鍒楄〃寰幆",
            "single_loop": "鍗曟洸寰幆",
            "shuffle": "闅忔満鎾斁",
        }

        self.play_mode_btn.setText(mode_text.get(self.play_mode, "鍒楄〃寰幆"))

    def get_next_row(self) -> int:
        count = self.song_list.count()

        if count == 0:
            return -1

        visible_rows = self.get_visible_rows()

        if not visible_rows:
            return -1

        current_row = self.song_list.currentRow()

        if self.play_mode == "single_loop":
            if current_row in visible_rows:
                return current_row

            return visible_rows[0]

        if self.play_mode == "shuffle":
            if len(visible_rows) == 1:
                return visible_rows[0]

            available_rows = [row for row in visible_rows if row != current_row]
            return random.choice(available_rows)

        if current_row not in visible_rows:
            return visible_rows[0]

        current_index = visible_rows.index(current_row)

        if current_index >= len(visible_rows) - 1:
            return visible_rows[0]

        return visible_rows[current_index + 1]

    def get_previous_row(self) -> int:
        count = self.song_list.count()

        if count == 0:
            return -1

        visible_rows = self.get_visible_rows()

        if not visible_rows:
            return -1

        current_row = self.song_list.currentRow()

        if self.play_mode == "shuffle":
            if len(visible_rows) == 1:
                return visible_rows[0]

            available_rows = [row for row in visible_rows if row != current_row]
            return random.choice(available_rows)

        if current_row not in visible_rows:
            return visible_rows[0]

        current_index = visible_rows.index(current_row)

        if current_index <= 0:
            return visible_rows[-1]

        return visible_rows[current_index - 1]

    def play_song_by_row(self, row: int) -> None:
        if row < 0 or row >= self.song_list.count():
            return

        self.song_list.setCurrentRow(row)
        item = self.song_list.item(row)

        if item:
            self.play_selected_song(item)

    def play_previous_song(self) -> None:
        self.play_song_by_row(self.get_previous_row())

    def play_next_song(self) -> None:
        if self.play_next_queued_song():
            return

        self.play_song_by_row(self.get_next_row())

    def handle_song_finished(self) -> None:
        print("姝屾洸鎾斁缁撴潫锛屽噯澶囨牴鎹挱鏀炬ā寮忓垏姝岋細", self.play_mode)

        if self.song_list.count() <= 0:
            return

        next_row = self.get_next_row()
        self.play_song_by_row(next_row)

    def import_music_files(self) -> None:
        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "閫夋嫨闊充箰鏂囦欢",
            str(Path.home()),
            "Audio Files (*.mp3 *.flac *.wav *.m4a *.aac *.ogg);;All Files (*)",
        )

        if not file_paths:
            return

        self.add_music_paths([Path(file_path) for file_path in file_paths])

    def import_music_folder(self) -> None:
        folder_path = QFileDialog.getExistingDirectory(
            self,
            "閫夋嫨闊充箰鏂囦欢澶?,
            str(Path.home()),
        )

        if not folder_path:
            return

        folder = Path(folder_path)
        music_paths = self.scan_music_folder(folder)

        print(f"閫夋嫨鐨勬枃浠跺す锛歿folder}")
        print(f"鎵弿鍒伴煶涔愭枃浠舵暟閲忥細{len(music_paths)}")

        if not music_paths:
            return

        self.add_music_paths(music_paths)

    def scan_music_folder(self, folder: Path) -> list[Path]:
        music_paths = []

        try:
            for path in folder.rglob("*"):
                if not path.is_file():
                    continue

                if path.suffix.lower() in AUDIO_EXTENSIONS:
                    music_paths.append(path)

        except Exception as error:
            print("鎵弿鏂囦欢澶瑰け璐ワ細", error)

        music_paths.sort(key=lambda item: str(item).lower())
        return music_paths

    def add_music_paths(self, paths: list[Path]) -> None:
        if not paths:
            return

        if self.has_demo_songs():
            self.song_list.clear()
            self.library_songs = []

        existing_paths = self.get_existing_song_paths()
        added_items: list[QListWidgetItem] = []
        added_paths: list[str] = []
        skipped_count = 0
        failed_count = 0

        for raw_path in paths:
            try:
                path = Path(raw_path).resolve()
            except Exception:
                failed_count += 1
                continue

            normalized_path = str(path)

            if normalized_path in existing_paths:
                skipped_count += 1
                continue

            if not path.exists() or not path.is_file():
                failed_count += 1
                continue

            if path.suffix.lower() not in AUDIO_EXTENSIONS:
                skipped_count += 1
                continue

            title, artist, album = self._read_audio_metadata(path)
            added_at = int(time.time()) + len(added_items)

            item = QListWidgetItem(f"{title}    路    {artist}    路    {album}")
            item.setData(
                Qt.ItemDataRole.UserRole,
                {
                    "title": title,
                    "artist": artist,
                    "album": album,
                    "path": normalized_path,
                    "added_at": added_at,
                    "demo": False,
                },
            )

            self.song_list.addItem(item)
            added_items.append(item)
            added_paths.append(normalized_path)
            added_song_data = item.data(Qt.ItemDataRole.UserRole)

            if isinstance(added_song_data, dict):
                self.library_songs.append(dict(added_song_data))

            existing_paths.add(normalized_path)

        self.refresh_library_browser()

        if added_paths:
            first_added_item = self.find_song_item_by_path(added_paths[0])

            if first_added_item is not None:
                self.song_list.setCurrentItem(first_added_item)
                self.select_song(first_added_item)

        self.save_music_library()

        print(f"鏈鏂板姝屾洸鏁伴噺锛歿len(added_items)}")
        print(f"鏈璺宠繃閲嶅鎴栭潪闊抽鏁伴噺锛歿skipped_count}")
        print(f"鏈瀵煎叆澶辫触鏁伴噺锛歿failed_count}")

    def _read_audio_metadata(self, path: Path) -> tuple[str, str, str]:
        title = path.stem
        artist = "鏈煡鑹烘湳瀹?
        album = "鏈煡涓撹緫"

        try:
            audio = MutagenFile(path, easy=True)

            if audio is None or audio.tags is None:
                return title, artist, album

            title = audio.tags.get("title", [title])[0]
            artist = audio.tags.get("artist", [artist])[0]
            album = audio.tags.get("album", [album])[0]

        except Exception as error:
            print(f"璇诲彇姝屾洸淇℃伅澶辫触锛歿path}")
            print(error)
            return title, artist, album

        return title, artist, album

    def change_volume(self, value: int) -> None:
        self.current_volume = value
        self.audio_output.setVolume(value / 100)
        self.save_settings()
        print("闊抽噺鏀逛负锛?, value)

    def on_seek_start(self) -> None:
        self.is_seeking = True

    def on_seek_end(self) -> None:
        self.is_seeking = False

        if self.current_duration <= 0:
            return

        slider_value = self.progress_slider.value()
        target_position = int(self.current_duration * slider_value / 100)
        self.media_player.setPosition(target_position)
        self.last_recorded_position = target_position

    def on_position_changed(self, position: int) -> None:
        if self.is_seeking or self.current_duration <= 0:
            return

        progress = int(position * 100 / self.current_duration)
        self.progress_slider.setValue(progress)

        self.record_listen_progress(position)

        current_playing_path = self.normalize_song_path(self.current_song_path)
        displayed_lyrics_path = self.normalize_song_path(self.displayed_lyrics_song_path)

        if current_playing_path and displayed_lyrics_path == current_playing_path:
            self.lyrics_view.update_by_position(position, self.current_lyrics)
            if hasattr(self, "full_lyrics_view"):
                self.full_lyrics_view.update_by_position(position, self.current_lyrics)
                if self.immersive_lyrics_window is not None:
                    self.immersive_lyrics_window.update_position(position, self.current_lyrics)

    def on_duration_changed(self, duration: int) -> None:
        self.current_duration = duration
        print("姝屾洸鏃堕暱锛?, duration, "ms")

    def on_playback_state_changed(self, state: QMediaPlayer.PlaybackState) -> None:
        print("鎾斁鐘舵€佸彉鍖栵細", state)

        if state == QMediaPlayer.PlaybackState.PlayingState:
            self.play_btn.setText("鏆傚仠")
        else:
            self.play_btn.setText("鎾斁")
            self.flush_current_listen_time()

    def on_media_status_changed(self, status) -> None:
        print("濯掍綋鐘舵€侊細", status)

        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self.flush_current_listen_time()
            self.handle_song_finished()

    def on_player_error(self, error=None, error_string: str = "") -> None:
        real_error_text = error_string or self.media_player.errorString()

        print("鎾斁閿欒锛?, error)
        print("閿欒淇℃伅锛?, real_error_text)

        if real_error_text:
            self.lyrics_view.set_placeholder("鎾斁澶辫触", real_error_text)

    def get_song_data_from_item(self, item: QListWidgetItem | None) -> dict | None:
        if item is None:
            return None

        song_data = item.data(Qt.ItemDataRole.UserRole)

        if not isinstance(song_data, dict):
            return None

        if song_data.get("demo"):
            return None

        path = self.normalize_song_path(song_data.get("path", ""))

        if not path:
            return None

        return song_data

    def show_song_context_menu(self, position) -> None:
        item = self.song_list.itemAt(position)

        if item is None:
            return

        self.song_list.setCurrentItem(item)

        song_data = self.get_song_data_from_item(item)

        if not song_data:
            return

        song_path = self.normalize_song_path(song_data.get("path", ""))

        menu = QMenu(self)
        menu.setObjectName("songContextMenu")

        play_action = menu.addAction("鎾斁")
        play_action.triggered.connect(lambda checked=False, selected_item=item: self.play_selected_song(selected_item))

        floating_lyrics_action = menu.addAction("鎵撳紑/鍏抽棴妗岄潰姝岃瘝")
        floating_lyrics_action.triggered.connect(self.toggle_floating_lyrics)

        next_queue_action = menu.addAction("涓嬩竴棣栨挱鏀?)
        next_queue_action.triggered.connect(lambda checked=False, selected_item=item: self.queue_selected_song_next(selected_item))

        add_queue_action = menu.addAction("鍔犲叆鎾斁闃熷垪")
        add_queue_action.triggered.connect(lambda checked=False, selected_item=item: self.queue_selected_song_last(selected_item))

        show_queue_action = menu.addAction("鏌ョ湅鎾斁闃熷垪")
        show_queue_action.triggered.connect(self.show_play_queue)

        clear_queue_action = menu.addAction("娓呯┖鎾斁闃熷垪")
        clear_queue_action.triggered.connect(self.clear_play_queue)

        menu.addSeparator()

        if self.is_song_liked(song_path):
            like_action = menu.addAction("鍙栨秷鏀惰棌")
        else:
            like_action = menu.addAction("娣诲姞鍒版垜鍠滄")

        like_action.triggered.connect(lambda checked=False, selected_item=item: self.toggle_like_selected_song(selected_item))

        add_to_playlist_action = menu.addAction("娣诲姞鍒版瓕鍗?)
        add_to_playlist_action.triggered.connect(self.add_current_song_to_playlist)

        if self.current_library_view == "liked":
            remove_from_playlist_action = menu.addAction("浠庢垜鍠滄绉婚櫎")
            remove_from_playlist_action.triggered.connect(self.remove_current_song_from_current_playlist)
        elif self.current_library_view.startswith("playlist:"):
            remove_from_playlist_action = menu.addAction("浠庡綋鍓嶆瓕鍗曠Щ闄?)
            remove_from_playlist_action.triggered.connect(self.remove_current_song_from_current_playlist)

        menu.addSeparator()

        bind_lyrics_action = menu.addAction("鎵嬪姩缁戝畾姝岃瘝")
        bind_lyrics_action.triggered.connect(self.bind_selected_song_lyrics)

        if self.get_bound_lyrics_path(song_path):
            unbind_lyrics_action = menu.addAction("鍙栨秷姝岃瘝缁戝畾")
            unbind_lyrics_action.triggered.connect(self.unbind_selected_song_lyrics)

        retry_lyrics_action = menu.addAction("閲嶆柊鎼滅储姝岃瘝")
        retry_lyrics_action.triggered.connect(self.force_search_selected_lyrics)

        retry_cover_action = menu.addAction("閲嶆柊鎼滅储灏侀潰")
        retry_cover_action.triggered.connect(self.force_search_selected_cover)

        menu.addSeparator()

        open_folder_action = menu.addAction("鎵撳紑鏂囦欢澶?)
        open_folder_action.triggered.connect(self.open_selected_song_folder)

        song_info_action = menu.addAction("鏌ョ湅姝屾洸淇℃伅")
        song_info_action.triggered.connect(self.show_selected_song_info)

        match_metadata_action = menu.addAction("鑱旂綉鍖归厤姝屾洸淇℃伅")
        match_metadata_action.triggered.connect(lambda checked=False, selected_item=item: self.match_selected_song_metadata(selected_item))

        menu.addSeparator()

        remove_from_library_action = menu.addAction("浠庨煶涔愬簱绉婚櫎")
        remove_from_library_action.triggered.connect(self.remove_selected_song)

        menu.exec(self.song_list.mapToGlobal(position))

    def toggle_like_selected_song(self, item: QListWidgetItem | None) -> None:
        song_data = self.get_song_data_from_item(item)

        if not song_data:
            return

        song_path = self.normalize_song_path(song_data.get("path", ""))

        if not song_path:
            return

        liked_songs = self.get_liked_song_paths()

        if song_path in liked_songs:
            liked_songs.remove(song_path)
            print("宸插彇娑堟敹钘忥細", song_path)
        else:
            liked_songs.append(song_path)
            print("宸插姞鍏ユ垜鍠滄锛?, song_path)

        self.save_playlists()

        if self.current_song_path and self.normalize_song_path(self.current_song_path) == song_path:
            self.update_like_button()
            self.update_side_info_panel()

        if self.current_library_view == "liked":
            self.filter_song_list(self.search_input.text())

    def open_selected_song_folder(self) -> None:
        song_path = self.get_current_selected_song_path()

        if not song_path:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        path = Path(song_path)

        if not path.exists():
            QMessageBox.warning(self, "鏂囦欢涓嶅瓨鍦?, "杩欎釜闊充箰鏂囦欢宸茬粡涓嶅瓨鍦ㄣ€?)
            return

        try:
            os.startfile(str(path.parent))
        except Exception as error:
            QMessageBox.warning(self, "鎵撳紑澶辫触", str(error))

    def show_selected_song_info(self) -> None:
        item = self.song_list.currentItem()
        song_data = self.get_song_data_from_item(item)

        if not song_data:
            QMessageBox.information(self, "鎻愮ず", "璇峰厛閫夋嫨涓€棣栫湡瀹炴瓕鏇层€?)
            return

        title = song_data.get("title", "鏈煡姝屾洸")
        artist = song_data.get("artist", "鏈煡鑹烘湳瀹?)
        album = song_data.get("album", "鏈煡涓撹緫")
        path = self.normalize_song_path(song_data.get("path", ""))

        stats = self.song_stats.get(
            path,
            {
                "play_count": 0,
                "total_listen_time": 0,
                "last_played": 0,
            },
        )

        play_count = int(stats.get("play_count", 0))
        total_time = self.format_listen_time(int(stats.get("total_listen_time", 0)))
        liked_text = "鏄? if self.is_song_liked(path) else "鍚?

        info = (
            f"姝屾洸锛歿title}\\n"
            f"姝屾墜锛歿artist}\\n"
            f"涓撹緫锛歿album}\\n"
            f"宸叉敹钘忥細{liked_text}\\n"
            f"鎾斁娆℃暟锛歿play_count}\\n"
            f"绱鏃堕暱锛歿total_time}\\n\\n"
            f"鏂囦欢璺緞锛歕\n{path}"
        )

        QMessageBox.information(self, "姝屾洸淇℃伅", info)

    def closeEvent(self, event) -> None:
        self.flush_current_listen_time()
        self.save_song_stats()

        if self.immersive_lyrics_window is not None:
            self.immersive_lyrics_window.close()
            self.immersive_lyrics_window = None

        super().closeEvent(event)

    def _style_sheet(self) -> str:
        return """
        QWidget#root {
            background: #0f1014;
            color: #f5f5f5;
            font-family: "Microsoft YaHei UI";
        }

        QFrame#shell {
            background: #181a20;
            border: 1px solid #2a2d35;
            border-radius: 22px;
        }

        QFrame#sidebar {
            background: #14161b;
            border-top-left-radius: 22px;
            border-bottom-left-radius: 22px;
            border-right: 1px solid #252832;
        }

        QLabel#appTitle {
            color: #ffffff;
            font-size: 24px;
            font-weight: 700;
        }

        QLabel#appSubtitle {
            color: #8d93a1;
            font-size: 12px;
        }

        QPushButton {
            border: none;
            outline: none;
        }

        QPushButton[active="true"] {
            background: #2a2f3a;
            color: #ffffff;
            font-weight: 600;
        }

        QPushButton[active="false"] {
            background: transparent;
            color: #a7acb8;
        }

        QPushButton[active="false"]:hover {
            background: #20242d;
            color: #ffffff;
        }

        QPushButton[active="true"],
        QPushButton[active="false"] {
            text-align: left;
            padding: 12px 16px;
            border-radius: 12px;
            font-size: 14px;
        }

        QFrame#libraryPanel {
            background: #181a20;
        }

        QFrame#fullLyricsPage {
            background: #181a20;
        }

        QLabel#fullLyricsPageTitle {
            color: #ffffff;
            font-size: 30px;
            font-weight: 800;
        }

        QLabel#fullLyricsPageSubtitle {
            color: #8d93a1;
            font-size: 13px;
        }

        QLabel#fullLyricsSongTitle {
            color: #ffffff;
            font-size: 26px;
            font-weight: 800;
        }

        QLabel#fullLyricsArtist {
            color: #aab1bf;
            font-size: 14px;
        }

        QLabel#fullLyricsStatus {
            color: #6f7786;
            font-size: 12px;
        }

        QFrame#fullLyricsPage QLabel#lyricLine {
            font-size: 20px;
        }

        QFrame#fullLyricsPage QLabel#lyricLine[lyricState="near"] {
            font-size: 24px;
        }

        QFrame#fullLyricsPage QLabel#lyricLine[lyricState="current"] {
            font-size: 34px;
            font-weight: 900;
        }

        QLabel#pageTitle {
            color: #ffffff;
            font-size: 30px;
            font-weight: 700;
        }

        QLabel#pageSubtitle {
            color: #8d93a1;
            font-size: 13px;
        }

        QPushButton#primaryButton {
            background: #3d7eff;
            color: #ffffff;
            border-radius: 12px;
            padding: 10px 18px;
            font-size: 14px;
            font-weight: 600;
        }

        QPushButton#primaryButton:hover {
            background: #5a91ff;
        }

        QPushButton#secondaryButton {
            background: #242833;
            color: #dfe3ec;
            border-radius: 12px;
            padding: 10px 16px;
            font-size: 13px;
        }

        QPushButton#secondaryButton:hover {
            background: #303746;
        }

        QPushButton#viewButton {
            background: #20242d;
            color: #a7acb8;
            border-radius: 12px;
            padding: 8px 13px;
            font-size: 13px;
        }

        QPushButton#viewButton:hover {
            background: #2a303c;
            color: #ffffff;
        }

        QPushButton#viewButton[active="true"] {
            background: #2f68d8;
            color: #ffffff;
            font-weight: 700;
        }

        QLabel#sidebarSectionTitle {
            color: #6f7786;
            font-size: 12px;
            font-weight: 700;
            padding: 8px 4px 2px 4px;
        }

        QFrame#sidebarPlaylistBox {
            background: transparent;
        }

        QPushButton#playlistSidebarButton {
            background: transparent;
            color: #a7acb8;
            text-align: left;
            border-radius: 10px;
            padding: 9px 12px;
            font-size: 13px;
        }

        QPushButton#playlistSidebarButton:hover {
            background: #20242d;
            color: #ffffff;
        }

        QPushButton#playlistSidebarButton[active="true"] {
            background: #2f68d8;
            color: #ffffff;
            font-weight: 700;
        }

        QPushButton#sidebarWideButton {
            background: #1f232c;
            color: #cbd1dc;
            border-radius: 10px;
            padding: 9px 12px;
            font-size: 12px;
            text-align: left;
        }

        QPushButton#sidebarWideButton:hover {
            background: #2a303c;
            color: #ffffff;
        }

        QPushButton#sidebarMiniButton {
            background: #1f232c;
            color: #cbd1dc;
            border-radius: 10px;
            padding: 8px 10px;
            font-size: 12px;
        }

        QPushButton#sidebarMiniButton:hover {
            background: #2a303c;
            color: #ffffff;
        }

        QLabel#sidebarHint {
            color: #68707f;
            font-size: 11px;
            padding: 2px 4px;
        }

        QMenu#songContextMenu {
            background: #181a20;
            color: #dfe3ec;
            border: 1px solid #303541;
            border-radius: 10px;
            padding: 6px;
        }

        QMenu#songContextMenu::item {
            padding: 8px 24px;
            border-radius: 7px;
        }

        QMenu#songContextMenu::item:selected {
            background: #2f68d8;
            color: #ffffff;
        }

        QMenu#songContextMenu::separator {
            height: 1px;
            background: #303541;
            margin: 6px 8px;
        }

        QPushButton#playlistActionButton {
            background: #1f232c;
            color: #cbd1dc;
            border-radius: 10px;
            padding: 8px 12px;
            font-size: 12px;
        }

        QPushButton#playlistActionButton:hover {
            background: #2a303c;
            color: #ffffff;
        }

        QPushButton#dangerButton {
            background: #3a2428;
            color: #ffd7dc;
            border-radius: 12px;
            padding: 10px 16px;
            font-size: 13px;
        }

        QPushButton#dangerButton:hover {
            background: #583039;
            color: #ffffff;
        }

        QLineEdit#searchInput {
            background: #14161b;
            color: #ffffff;
            border: 1px solid #292d36;
            border-radius: 14px;
            padding: 11px 14px;
            font-size: 14px;
        }

        QLineEdit#searchInput:focus {
            border: 1px solid #3d7eff;
        }

        QListWidget#songList {
            background: #14161b;
            border: 1px solid #292d36;
            border-radius: 16px;
            padding: 10px;
            color: #dfe3ec;
            font-size: 14px;
        }

        QListWidget#songList::item {
            padding: 16px 14px;
            border-radius: 10px;
            margin: 3px;
        }

        QListWidget#songList::item:hover {
            background: #222631;
        }

        QListWidget#songList::item:selected {
            background: #2f68d8;
            color: #ffffff;
        }

        QFrame#nowPlayingPanel {
            background: #15171d;
            border-left: 1px solid #252832;
            border-top-right-radius: 22px;
        }

        QFrame#nowInfoBox {
            background: transparent;
        }

        QLabel#sectionTitle {
            color: #ffffff;
            font-size: 18px;
            font-weight: 700;
        }

        QLabel#coverLabel {
            background: qlineargradient(
                x1: 0, y1: 0,
                x2: 1, y2: 1,
                stop: 0 #2a2f3a,
                stop: 1 #121318
            );
            color: #ffffff;
            font-size: 36px;
            font-weight: 700;
            border: 1px solid #333846;
            border-radius: 24px;
        }

        QLabel#nowSongTitle {
            color: #ffffff;
            font-size: 19px;
            font-weight: 700;
        }

        QLabel#nowArtist {
            color: #9096a3;
            font-size: 13px;
        }

        QLabel#nowStats {
            color: #6f7786;
            font-size: 12px;
        }

        QLabel#lyricsStatus {
            color: #7c8595;
            font-size: 12px;
        }

        QFrame#sideInfoPanel {
            background: transparent;
            border: none;
        }

        QLabel#sideInfoTitle {
            color: #ffffff;
            font-size: 18px;
            font-weight: 800;
        }

        QLabel#sideInfoHint {
            color: #747c8b;
            font-size: 12px;
        }

        QFrame#sideInfoRow {
            background: #111319;
            border: 1px solid #252a35;
            border-radius: 12px;
        }

        QLabel#sideInfoName {
            color: #6f7786;
            font-size: 11px;
            font-weight: 700;
        }

        QLabel#sideInfoValue {
            color: #dfe3ec;
            font-size: 13px;
        }

        QLabel#sideInfoFileValue {
            color: #8d93a1;
            font-size: 11px;
        }

        QScrollArea#lyricsView {
            background: transparent;
            border: none;
        }

        QWidget#lyricsContent {
            background: transparent;
        }

        QLabel#lyricPlaceholderTitle {
            color: #ffffff;
            font-size: 18px;
            font-weight: 700;
        }

        QLabel#lyricPlaceholderSubtitle {
            color: #777e8d;
            font-size: 13px;
        }

        QLabel#lyricLine {
            color: #626a78;
            font-size: 15px;
            font-weight: 500;
            padding: 2px 4px;
        }

        QLabel#lyricLine[lyricState="near"] {
            color: #aab1bf;
            font-size: 17px;
            font-weight: 600;
        }

        QLabel#lyricLine[lyricState="current"] {
            color: #ffffff;
            font-size: 22px;
            font-weight: 800;
        }

        QFrame#playerBar {
            background: #111319;
            border-top: 1px solid #292d36;
            border-bottom-left-radius: 22px;
            border-bottom-right-radius: 22px;
        }

        QFrame#playerLeft,
        QFrame#playerCenter,
        QFrame#playerRight {
            background: transparent;
        }

        QLabel#bottomSongTitle {
            color: #ffffff;
            font-size: 14px;
            font-weight: 700;
        }

        QLabel#bottomSongArtist {
            color: #8d93a1;
            font-size: 12px;
        }

        QLabel#volumeLabel {
            color: #8d93a1;
            font-size: 12px;
        }

        QPushButton#controlButton {
            background: #242833;
            color: #ffffff;
            border-radius: 12px;
            padding: 10px 10px;
            font-size: 13px;
        }

        QPushButton#controlButton:hover {
            background: #303746;
        }

        QPushButton#likeButton {
            background: #242833;
            color: #ffffff;
            border-radius: 12px;
            padding: 10px 10px;
            font-size: 13px;
        }

        QPushButton#likeButton:hover {
            background: #303746;
        }

        QPushButton#likeButton[liked="true"] {
            background: #4a2634;
            color: #ff8fb3;
            font-weight: 700;
        }

        QPushButton#likeButton[liked="true"]:hover {
            background: #633044;
            color: #ffffff;
        }

        QPushButton#likeButton:disabled {
            background: #1d2028;
            color: #5f6674;
        }

        QSlider#progressSlider::groove:horizontal,
        QSlider#volumeSlider::groove:horizontal {
            height: 5px;
            background: #303541;
            border-radius: 3px;
        }

        QSlider#progressSlider::handle:horizontal,
        QSlider#volumeSlider::handle:horizontal {
            width: 14px;
            height: 14px;
            margin: -5px 0;
            background: #ffffff;
            border-radius: 7px;
        }

        QSlider#progressSlider::sub-page:horizontal,
        QSlider#volumeSlider::sub-page:horizontal {
            background: #3d7eff;
            border-radius: 3px;
        }
        """
